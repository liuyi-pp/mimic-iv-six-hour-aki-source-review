"""Artificial filesystem/header tests only; no clinical input permitted."""
from pathlib import Path
import hashlib
import contextlib
import io
import importlib.util
import json
import os
import tempfile
import unittest
from unittest.mock import patch
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).absolute().parents[1]
spec = importlib.util.spec_from_file_location("offline_review", ROOT / "review.py")
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)


class OfflineReviewTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=os.environ.get("C30_TEST_TEMP"))
        self.root = Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup)
        (self.root / "invented.txt").write_text("artificial fixture only", encoding="utf-8")
        self.manifest = {
            "version": "0.3.1", "clinical_execution_authorized": False,
            "clinical_execution_supported": False,
            "full_pipeline_execution_verified": False,
            "files": [{"relative_path": "invented.txt", "sha256": hashlib.sha256(
                (self.root / "invented.txt").read_bytes()).hexdigest()}]}
        self.save()

    def save(self):
        (self.root / "CANDIDATE_MANIFEST.json").write_text(json.dumps(self.manifest), encoding="utf-8")

    def test_artificial_manifest(self):
        self.assertEqual(review.verify(self.root), self.manifest)

    def test_modified_member(self):
        (self.root / "invented.txt").write_text("changed artificial fixture", encoding="utf-8")
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_extra_member(self):
        (self.root / "unexpected.txt").write_text("not permitted", encoding="utf-8")
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_missing_member(self):
        # No deletion: add an expected but nonexistent member to an invented manifest.
        self.manifest["files"].append({"relative_path": "absent.txt", "sha256": "a" * 64})
        self.save()
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_traversal_rejected(self):
        for name in ("../x", "/x", "C:/x", "a\\b", "a//b", "./x", "a/../x"):
            with self.assertRaises(review.ReviewError): review.safe_name(name)

    def test_duplicate_rejected(self):
        self.manifest["files"].append(dict(self.manifest["files"][0]))
        self.save()
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_casefold_duplicate_rejected(self):
        self.manifest["files"].append({"relative_path": "INVENTED.TXT", "sha256": "a" * 64})
        self.save()
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_invalid_manifest_shape_and_safe_cli(self):
        for obj in (None, [], "invented", {**self.manifest, "files": {}},
                    {**self.manifest, "files": [None]}):
            (self.root / "CANDIDATE_MANIFEST.json").write_text(json.dumps(obj), encoding="utf-8")
            with self.assertRaises(review.ReviewError): review.verify(self.root)
            output, error = io.StringIO(), io.StringIO()
            with patch.object(review, "__file__", str(self.root / "review.py")), \
                    contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
                self.assertEqual(review.main(["check"]), 2)
            self.assertEqual(output.getvalue(), "")
            self.assertEqual(error.getvalue(), "FAIL_OFFLINE_REVIEW\n")

    def test_hardlink_rejected(self):
        target = self.root / "invented.txt"
        alias = self.root / "hardlink.txt"
        try:
            os.link(target, alias)
        except (OSError, NotImplementedError):
            self.skipTest("Artificial hardlink creation unsupported")
        with self.assertRaises(review.ReviewError): review.no_link(alias)

    def test_symlink_rejected(self):
        alias = self.root / "symlink.txt"
        try:
            alias.symlink_to(self.root / "invented.txt")
        except (OSError, NotImplementedError):
            self.skipTest("Artificial symlink creation unsupported")
        with self.assertRaises(review.ReviewError): review.no_link(alias)

    def test_clinical_authorization_status_rejected(self):
        self.manifest["clinical_execution_authorized"] = True
        self.save()
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_execution_status_rejected(self):
        self.manifest["clinical_execution_supported"] = True
        self.save()
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_pipeline_verification_status_rejected(self):
        self.manifest["full_pipeline_execution_verified"] = True
        self.save()
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_historical_version_rejected(self):
        self.manifest["version"] = "0.3.0"
        self.save()
        with self.assertRaises(review.ReviewError): review.verify(self.root)

    def test_header_shape(self):
        schema = json.loads((ROOT / "docs" / "mapping_schema.json").read_text(encoding="utf-8"))
        header = schema["ordered_columns"]
        self.assertEqual(len(header), len(set(header)))
        self.assertTrue(review.validate_mapping_header(header.copy(), schema))
        for other in (list(reversed(header)), header[:-1], header + [header[0]]):
            with self.assertRaises(review.ReviewError): review.validate_mapping_header(other, schema)

    def test_source_order_not_numeric_sort(self):
        value = review.plan(ROOT)
        self.assertEqual(value["clinical_order"], ["15b", "19", "16a", "16b", "16c", "16d", "17"])
        self.assertFalse(value["execution_supported"])


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(OfflineReviewTests)
    result = unittest.TestResult()
    suite.run(result)
    # Suppress tracebacks/fixture values; report only outcome and mechanism-test count.
    print(json.dumps({"status": "PASS_ARTIFICIAL_PYTHON_TESTS" if result.wasSuccessful() else
                      "FAIL_ARTIFICIAL_PYTHON_TESTS", "tests": result.testsRun,
                      "failures": len(result.failures), "errors": len(result.errors),
                      "skipped": len(result.skipped)}))
    sys.exit(0 if result.wasSuccessful() else 1)
