# Offline, artificial-only mechanism checks. Base R and stats only.
# Usage: Rscript tests/artificial_mechanisms.R <candidate-root>
# This file reads only the two named packaged source files below. It never
# sources a legacy entrypoint, fits a model, generates predictions, or reads
# clinical data, mapping files, results, checkpoints, credentials or a database.
# Invented numeric inputs stay in memory. Console output is status/check count only.

test_state <- new.env(parent = emptyenv())
test_state$checks <- 0L

run_checks <- function() {
  check <- function(value) {
    test_state$checks <- test_state$checks + 1L
    if (!isTRUE(value)) stop("ARTIFICIAL_CHECK_FAILED", call. = FALSE)
    invisible(NULL)
  }
  near <- function(actual, expected, tolerance = 1e-12) {
    isTRUE(all.equal(actual, expected, tolerance = tolerance,
                     check.attributes = FALSE))
  }
  expect_error <- function(expression, prefix) {
    observed <- tryCatch({ force(expression); NA_character_ },
                         error = function(e) conditionMessage(e))
    check(length(observed) == 1L && !is.na(observed) &&
            startsWith(observed, prefix))
  }
  forbidden <- function(...) stop("ARTIFICIAL_FORBIDDEN_FIT", call. = FALSE)

  args <- commandArgs(trailingOnly = TRUE)
  check(length(args) == 1L && nzchar(args[[1L]]) && dir.exists(args[[1L]]))
  root <- normalizePath(args[[1L]], winslash = "/", mustWork = TRUE)

  load_definition <- function(filename, name, expected_formals) {
    path <- file.path(root, "source", "src", "analysis", "v1_3", filename)
    check(file.exists(path))
    parsed <- parse(file = path, keep.source = FALSE)
    is_expected_definition <- function(node) {
      is.call(node) && length(node) == 3L &&
        identical(node[[1L]], as.name("<-")) &&
        is.symbol(node[[2L]]) && identical(as.character(node[[2L]]), name) &&
        is.call(node[[3L]]) &&
        identical(node[[3L]][[1L]], as.name("function"))
    }
    selected <- which(vapply(as.list(parsed), is_expected_definition, logical(1)))
    check(length(selected) == 1L)
    isolated <- new.env(parent = baseenv())
    isolated$quantile <- stats::quantile
    isolated$sd <- stats::sd
    # The fractional function's unused calibration branch cannot silently fit.
    isolated$glm <- forbidden
    isolated$glm.control <- forbidden
    isolated$binomial <- forbidden
    isolated$qlogis <- forbidden
    # Evaluate the selected function expression, never the parsed source file.
    fun <- eval(parsed[[selected]][[3L]], envir = isolated)
    check(is.function(fun) && identical(names(formals(fun)), expected_formals))
    lockEnvironment(isolated, bindings = TRUE)
    fun
  }

  fractional <- load_definition(
    "fractional_weight_metrics.R", "v13_fractional_metrics",
    c("y", "probability", "weight", "calibration"))
  shifted_ci <- load_definition(
    "location_shifted_ci.R", "v13_location_shifted_ci",
    c("apparent", "train", "original", "expected_iterations", "min_valid"))

  # Every call, including invalid-input calls, disables the fitting branch.
  metrics <- function(y, probability, weight) {
    fractional(y, probability, weight, calibration = FALSE)
  }
  score_names <- c("auroc", "average_precision", "brier", "logloss")
  y <- c(0, 1, 0, 1)
  probability <- c(0.2, 0.5, 0.5, 0.9)
  weight <- c(1, 2, 3, 4)
  result <- metrics(y, probability, weight)
  expected <- c(auroc = 21 / 24, average_precision = 8 / 9,
                brier = 1.33 / 10,
                logloss = -(log(0.8) + 5 * log(0.5) + 4 * log(0.9)) / 10)
  check(near(result$metrics[score_names], expected))
  check(identical(result$calibration_status, "NOT_REQUESTED"))
  check(all(is.na(result$metrics[c("calibration_intercept", "calibration_slope")])))
  check(length(result$calibration_warnings) == 0L && identical(result$clipped, FALSE))
  check(identical(result$all_metrics_finite, FALSE))
  check(identical(result$average_precision_definition,
                  "common thresholds; all exact ties enter together"))

  scaled <- metrics(y, probability, weight * 17)
  check(near(scaled$metrics[score_names], expected))
  permutation <- c(4L, 3L, 2L, 1L)
  permuted <- metrics(y[permutation], probability[permutation], weight[permutation])
  check(near(permuted$metrics[score_names], expected))
  all_tied <- metrics(y, rep(0.5, length(y)), weight)
  check(near(all_tied$metrics[score_names], c(0.5, 0.6, 0.25, log(2))))
  zero_row <- metrics(c(y, 1), c(probability, 0), c(weight, 0))
  check(near(zero_row$metrics[score_names], expected) && zero_row$zero_weight_rows == 1L)
  boundary <- metrics(c(0, 1), c(0, 1), c(1, 1))
  check(near(boundary$metrics[score_names], c(1, 1, 0, 0)))
  wrong_boundary <- metrics(c(0, 1), c(1, 0), c(1, 1))
  check(is.infinite(wrong_boundary$metrics[["logloss"]]) &&
          wrong_boundary$metrics[["logloss"]] > 0)

  expect_error(metrics(numeric(), numeric(), numeric()), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(as.character(y), probability, weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(matrix(y, nrow = 2L), probability, weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(factor(y), probability, weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, probability[-1L], weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(c(0, 2, 0, 1), probability, weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(c(0, NA_real_, 0, 1), probability, weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, c(Inf, 0.5, 0.5, 0.9), weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, c(-0.1, 0.5, 0.5, 0.9), weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, c(1.1, 0.5, 0.5, 0.9), weight), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, probability, c(NA_real_, 2, 3, 4)), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, probability, c(Inf, 2, 3, 4)), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, probability, c(-1, 2, 3, 4)), "WEIGHTED_METRIC_INPUT")
  expect_error(metrics(y, probability, rep(0, length(y))), "WEIGHTED_METRIC_ZERO_WEIGHT")
  expect_error(metrics(y, probability, c(1, 0, 3, 0)), "WEIGHTED_METRIC_SINGLE_CLASS")

  # Tiny invented arrays: these are numeric mechanism inputs, not fitted or
  # retained predictions. Every iteration threshold is explicit and artificial.
  iterations <- paste0("toy_", seq_len(6L))
  models <- c("LASSO", "XGBoost")
  metric_names <- c("metric_a", "metric_b")
  train <- array(0, dim = c(6L, 2L, 2L),
                 dimnames = list(iterations, models, metric_names))
  train[, "XGBoost", "metric_a"] <- c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6)
  train[, "LASSO", "metric_a"] <- train[, "XGBoost", "metric_a"] + 0.2
  train[, "XGBoost", "metric_b"] <- c(0.2, 0.25, 0.35, 0.45, 0.55, 0.65)
  train[, "LASSO", "metric_b"] <- train[, "XGBoost", "metric_b"] - 0.1
  optimism <- matrix(c(0.05, 0.02, 0.01, 0.04), nrow = 2L,
                     dimnames = list(models, metric_names))
  original <- train
  for (k in seq_along(metric_names)) {
    for (j in seq_along(models)) original[, j, k] <- train[, j, k] - optimism[j, k]
  }
  apparent <- matrix(c(0.75, 0.45, 0.25, 0.5), nrow = 2L,
                     dimnames = list(models, metric_names))
  ci <- function(a = apparent, t = train, o = original,
                 expected_iterations = 6L, min_valid = 4L) {
    shifted_ci(a, t, o, expected_iterations = expected_iterations, min_valid = min_valid)
  }
  all_valid <- ci()
  check(identical(all_valid$valid_iterations, iterations) && all_valid$valid_count == 6L)
  check(length(all_valid$excluded_iterations) == 0L)

  # Missingness on different models and metrics must exclude whole iterations.
  masked_train <- train
  masked_original <- original
  masked_train[1L, "LASSO", "metric_a"] <- NA_real_
  masked_original[6L, "XGBoost", "metric_b"] <- Inf
  kept <- 2L:5L
  output <- ci(t = masked_train, o = masked_original)
  check(identical(output$valid_iterations, iterations[kept]))
  check(identical(output$excluded_iterations, iterations[c(1L, 6L)]))
  check(output$valid_count == length(kept))
  check(identical(output$quantile_type, 8L))
  check(identical(output$method, "location-shifted approximate percentile interval"))
  check(identical(output$full_optimism_uncertainty_propagated, FALSE))
  check(identical(output$diagnostic_is_second_corrected_ci, FALSE))
  check(identical(output$intervals_clipped, FALSE))
  check(nrow(output$model) == 4L && nrow(output$paired) == 2L)
  for (k in seq_along(metric_names)) {
    for (j in seq_along(models)) {
      row <- output$model[output$model$metric == metric_names[k] &
                            output$model$model == models[j], , drop = FALSE]
      check(nrow(row) == 1L)
      check(near(row$optimism, optimism[j, k]))
      check(near(row$corrected, apparent[j, k] - optimism[j, k]))
      interval <- unname(stats::quantile(train[kept, j, k], c(0.025, 0.975), type = 8)) -
        optimism[j, k]
      diagnostic <- unname(stats::quantile(original[kept, j, k], c(0.025, 0.975), type = 8))
      check(near(c(row$lower, row$upper), interval))
      check(near(c(row$original_sample_diagnostic_lower,
                   row$original_sample_diagnostic_upper), diagnostic))
      check(near(row$optimism_sd, 0) && near(row$optimism_mcse, 0))
    }
    paired <- output$paired[output$paired$metric == metric_names[k], , drop = FALSE]
    gap <- c(0.2, -0.1)[k]
    shift <- optimism[1L, k] - optimism[2L, k]
    check(nrow(paired) == 1L && identical(paired$direction, "LASSO-XGBoost"))
    check(near(paired$corrected_difference, apparent[1L, k] - apparent[2L, k] - shift))
    check(near(c(paired$lower, paired$upper), rep(gap - shift, 2L)))
  }

  expect_error(ci(t = array("invalid", dim = dim(train), dimnames = dimnames(train))), "CI_ARRAY")
  expect_error(ci(o = original[-1L, , , drop = FALSE]), "CI_ARRAY")
  mismatched_names <- original
  dimnames(mismatched_names)[[1L]][1L] <- "other_toy"
  expect_error(ci(o = mismatched_names), "CI_ARRAY")
  expect_error(ci(expected_iterations = 1L), "CI_COUNTS")
  expect_error(ci(expected_iterations = NA_real_), "CI_COUNTS")
  expect_error(ci(min_valid = 1L), "CI_COUNTS")
  expect_error(ci(min_valid = 2.5), "CI_COUNTS")
  expect_error(ci(min_valid = 7L), "CI_COUNTS")
  expect_error(ci(expected_iterations = 5L), "CI_KEYS")
  duplicate_iterations_train <- train
  duplicate_iterations_original <- original
  dimnames(duplicate_iterations_train)[[1L]][2L] <- iterations[1L]
  dimnames(duplicate_iterations_original)[[1L]][2L] <- iterations[1L]
  expect_error(ci(t = duplicate_iterations_train, o = duplicate_iterations_original), "CI_KEYS")
  reversed_models_train <- train
  reversed_models_original <- original
  dimnames(reversed_models_train)[[2L]] <- rev(models)
  dimnames(reversed_models_original)[[2L]] <- rev(models)
  expect_error(ci(t = reversed_models_train, o = reversed_models_original), "CI_KEYS")
  duplicate_metrics_train <- train
  duplicate_metrics_original <- original
  dimnames(duplicate_metrics_train)[[3L]] <- rep(metric_names[1L], 2L)
  dimnames(duplicate_metrics_original)[[3L]] <- rep(metric_names[1L], 2L)
  expect_error(ci(t = duplicate_metrics_train, o = duplicate_metrics_original), "CI_KEYS")
  bad_apparent <- apparent
  rownames(bad_apparent) <- rev(models)
  expect_error(ci(a = bad_apparent), "CI_APPARENT")
  bad_apparent <- apparent
  bad_apparent[1L, 1L] <- NA_real_
  expect_error(ci(a = bad_apparent), "CI_APPARENT")
  expect_error(ci(t = masked_train, o = masked_original, min_valid = 5L), "CI_INSUFFICIENT_VALID")
  invisible(NULL)
}

passed <- tryCatch({
  withCallingHandlers(run_checks(),
                      warning = function(w) stop("ARTIFICIAL_UNEXPECTED_WARNING", call. = FALSE),
                      message = function(m) stop("ARTIFICIAL_UNEXPECTED_MESSAGE", call. = FALSE))
  TRUE
}, error = function(e) FALSE)
cat(sprintf("STATUS=%s CHECKS=%d\n", if (passed) "PASS" else "FAIL", test_state$checks))
quit(save = "no", status = if (passed) 0L else 1L, runLast = FALSE)
