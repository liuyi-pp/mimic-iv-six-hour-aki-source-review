-- Temporal-exclusion amendment V13_TEMPORAL_EXCLUSION_20260921_V1.
-- Source-only distribution does not confer production execution authorization.
-- Insert after ORIGINAL first-candidate selection/admission-key guard.
-- TEMP-derived selection only. No source UPDATE/DELETE, timestamp replacement,
-- later-stay substitution, outcome derivation, or existing stage-order change.
CREATE TEMP TABLE v13_temporal_selection ON COMMIT DROP AS
SELECT c.subject_id,c.hadm_id,c.stay_id,c.intime,c.outtime,a.dischtime,a.deathtime,
 coalesce(a.dischtime<c.intime,false) AS discharge_before_icu,
 coalesce(a.deathtime<c.intime,false) AS death_before_icu,
 coalesce(c.outtime<c.intime,false) AS icu_out_before_icu_in,
 coalesce(a.dischtime<c.intime OR a.deathtime<c.intime OR c.outtime<c.intime,false) AS excluded
FROM pg_temp.v13_first_candidates c JOIN mimiciv_hosp.admissions a USING(subject_id,hadm_id);
ALTER TABLE pg_temp.v13_temporal_selection ADD PRIMARY KEY(stay_id);
ALTER TABLE pg_temp.v13_temporal_selection ADD UNIQUE(subject_id);
CREATE TEMP VIEW v13_temporal_retained AS
SELECT c.* FROM pg_temp.v13_first_candidates c
JOIN pg_temp.v13_temporal_selection t USING(subject_id,hadm_id,stay_id)
WHERE NOT t.excluded;
CREATE TEMP TABLE v13_temporal_exclusions ON COMMIT DROP AS
SELECT t.*,'INVALID_PRE_ICU_ENDPOINT_TIMELINE'::text AS reason_code
FROM pg_temp.v13_temporal_selection t WHERE excluded;
DO $temporal_selection_guard$ BEGIN
 IF (SELECT count(*) FROM pg_temp.v13_first_candidates)<>
    (SELECT count(*) FROM pg_temp.v13_temporal_selection)
 OR (SELECT count(*) FROM pg_temp.v13_first_candidates)<>
    (SELECT count(*) FROM pg_temp.v13_temporal_retained)+(SELECT count(*) FROM pg_temp.v13_temporal_exclusions)
 THEN RAISE EXCEPTION 'V13_TEMPORAL_SELECTION_DENOMINATOR'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.v13_temporal_selection
   WHERE excluded IS DISTINCT FROM (discharge_before_icu OR death_before_icu OR icu_out_before_icu_in))
 THEN RAISE EXCEPTION 'V13_TEMPORAL_SELECTION_REASON'; END IF;
 IF NOT EXISTS(SELECT 1 FROM pg_temp.v13_temporal_retained)
 THEN RAISE EXCEPTION 'V13_TEMPORAL_NO_RETAINED_CANDIDATE'; END IF;
END $temporal_selection_guard$;
