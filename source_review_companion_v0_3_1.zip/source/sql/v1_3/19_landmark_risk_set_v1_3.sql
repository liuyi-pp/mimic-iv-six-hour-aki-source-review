-- SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Original source is preserved; derived-source configuration changes are separately logged.
-- No data, fitted artifacts, run outputs or credentials accompany this file.
-- Optional/sensitivity branches are not evidence those analyses were performed.


DO $guard$
BEGIN
 IF to_regclass('pg_temp.v13_stage_ledger') IS NULL THEN RAISE EXCEPTION 'V13_STAGE_ORDER_19'; END IF;
 IF (SELECT array_agg(stage ORDER BY stage) FROM pg_temp.v13_stage_ledger) IS DISTINCT FROM ARRAY['15b']::text[]
 THEN RAISE EXCEPTION 'V13_STAGE_ORDER_19'; END IF;
 IF (SELECT count(*) FROM pg_temp.v13_surgery_evidence)<>(SELECT count(*) FROM pg_temp.v13_stays)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_surgery_evidence WHERE NOT source_evidence_verified)
 THEN RAISE EXCEPTION 'V13_SURGERY_SOURCE_CONTRACT_INCOMPLETE'; END IF;
END $guard$;

CREATE TEMP TABLE v13_landmark_19 ON COMMIT DROP AS
WITH q AS (
 SELECT l.*,x.frozen_surgery_related,x.same_day_date_only AS date_only_surgery,x.precise_time_status,
  CASE WHEN l.deathtime<=l.intime+interval '6 hours' THEN false
       WHEN l.deathtime IS NOT NULL THEN true
       WHEN l.hospital_expire_flag=1 THEN NULL
       WHEN l.dischtime IS NOT NULL THEN true ELSE NULL END AS alive_h6,
  CASE WHEN l.dischtime IS NULL THEN NULL ELSE l.dischtime>l.intime+interval '6 hours' END AS admitted_h6,
  CASE WHEN l.outtime IS NULL THEN NULL ELSE l.outtime>l.intime+interval '6 hours' END AS in_icu_h6
 FROM pg_temp.v13_labels_15b l JOIN pg_temp.v13_surgery_evidence x USING(stay_id)
), classified AS (
 SELECT q.*,
  CASE WHEN alive_h6 IS FALSE THEN 'DIED_BY_H6'
       WHEN admitted_h6 IS FALSE THEN 'DISCHARGED_BY_H6'
       WHEN alive_h6 IS NULL OR admitted_h6 IS NULL THEN 'UNKNOWN_H6_STATUS'
       WHEN NOT frozen_surgery_related THEN 'NO_FROZEN_SURGICAL_ELIGIBILITY'
       WHEN esrd_or_maintenance THEN 'CHRONIC_RENAL_EXCLUSION'
       WHEN pre_aki THEN 'PREVALENT_AKI'
       WHEN early_aki THEN 'EARLY_AKI'
       WHEN early_rrt THEN 'EARLY_RRT'
       ELSE 'ELIGIBLE_D2A' END AS eligibility_status
 FROM q
)
SELECT c.*,eligibility_status='ELIGIBLE_D2A' AS risk_set_eligible,
 eligibility_status='ELIGIBLE_D2A' AND in_icu_h6 IS TRUE AS icu_restricted_sensitivity_eligible,
 eligibility_status='ELIGIBLE_D2A' AND NOT date_only_surgery AS exclude_date_only_sensitivity_eligible,
 CASE WHEN eligibility_status='ELIGIBLE_D2A' THEN incident_aki ELSE NULL END AS risk_set_outcome
FROM classified c;
ALTER TABLE pg_temp.v13_landmark_19 ADD PRIMARY KEY(stay_id,threshold);
CREATE TEMP VIEW v13_primary_risk_set AS
 SELECT * FROM pg_temp.v13_landmark_19 WHERE primary_threshold AND risk_set_eligible;

DO $verify$
BEGIN
 IF (SELECT count(*) FROM pg_temp.v13_landmark_19)<>(SELECT count(*) FROM pg_temp.v13_labels_15b)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_primary_risk_set WHERE resolved<>(risk_set_outcome IS NOT NULL))
 THEN RAISE EXCEPTION 'V13_RISK_SET_RECONCILIATION_FAILED'; END IF;
END $verify$;
INSERT INTO pg_temp.v13_stage_ledger(stage) VALUES('19');
