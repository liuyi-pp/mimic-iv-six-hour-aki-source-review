-- SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Derived from an enumerated source snapshot; see README and internal provenance.
-- No research data, fitted parameters, individual predictions or credentials are embedded.
-- Prespecified algorithm constants are code, not fitted research results.
-- This is not the verified manuscript execution version and is not a complete pipeline.




DO $guard$
BEGIN
 IF to_regclass('pg_temp.v13_stage_ledger') IS NULL THEN RAISE EXCEPTION 'V13_NUMERIC_REQUIRES_19'; END IF;
 IF (SELECT array_agg(stage ORDER BY stage) FROM pg_temp.v13_stage_ledger)
      IS DISTINCT FROM ARRAY['15b','19']::text[]
 THEN RAISE EXCEPTION 'V13_NUMERIC_REQUIRES_19'; END IF;
END $guard$;

CREATE TEMP TABLE v13_numeric_raw_16 ON COMMIT DROP AS
SELECT c.stay_id,c.intime+interval '6 hours' AS landmark_time,
 CASE WHEN l.itemid=50912 THEN 'creatinine' ELSE 'hemoglobin' END AS concept,
 l.itemid,l.charttime,l.storetime,l.valuenum AS value,l.valueuom,1 AS priority,
 CASE WHEN l.itemid=50912 THEN 'mg/dl' ELSE 'g/dl' END AS expected_unit,
 CASE WHEN l.itemid=50912 THEN .1 ELSE 1.0 END AS low_value,30.0 AS high_value
FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_hosp.labevents l
 ON l.subject_id=c.subject_id AND l.hadm_id=c.hadm_id
WHERE l.itemid IN(50912,51222) AND l.charttime BETWEEN c.intime AND c.intime+interval '6 hours'
UNION ALL
SELECT c.stay_id,c.intime+interval '6 hours','map',e.itemid,e.charttime,e.storetime,
 e.valuenum,e.valueuom,CASE WHEN e.itemid=220052 THEN 1 ELSE 2 END,'mmhg',20.0,250.0
FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.chartevents e
 ON e.subject_id=c.subject_id AND e.hadm_id=c.hadm_id AND e.stay_id=c.stay_id
WHERE e.itemid IN(220052,220181) AND e.charttime BETWEEN c.intime AND c.intime+interval '6 hours';

CREATE TEMP TABLE v13_numeric_row_qc_16 ON COMMIT DROP AS
SELECT r.*,storetime IS NOT NULL AND storetime<=landmark_time AS known_by_h6,
 lower(replace(coalesce(valueuom,''),' ',''))=expected_unit AS valid_unit,
 coalesce(value BETWEEN low_value AND high_value,false) AS valid_value
FROM pg_temp.v13_numeric_raw_16 r;



CREATE TEMP TABLE v13_numeric_point_qc_16 ON COMMIT DROP AS
SELECT m.mode,r.stay_id,r.concept,r.itemid,r.charttime,r.priority,
 count(*) AS source_rows,count(DISTINCT r.value) AS distinct_values,min(r.value) AS value
FROM pg_temp.v13_numeric_row_qc_16 r
CROSS JOIN (VALUES('PRIMARY'),('CHARTTIME_ONLY_SENSITIVITY')) m(mode)
WHERE r.valid_unit AND r.valid_value AND (m.mode<>'PRIMARY' OR r.known_by_h6)
GROUP BY m.mode,r.stay_id,r.concept,r.itemid,r.charttime,r.priority;


CREATE TEMP TABLE v13_numeric_fused_16 ON COMMIT DROP AS
WITH usable AS (
 SELECT *,min(priority) OVER(PARTITION BY mode,stay_id,concept,charttime) AS preferred_priority
 FROM pg_temp.v13_numeric_point_qc_16 WHERE distinct_values=1
)
SELECT mode,stay_id,concept,charttime,avg(value) AS value,count(*) AS source_item_count
FROM usable WHERE priority=preferred_priority GROUP BY mode,stay_id,concept,charttime;


CREATE TEMP TABLE v13_numeric_features_16 ON COMMIT DROP AS
SELECT c.stay_id,c.subject_id,c.hadm_id,m.mode,
 avg(f.value) FILTER(WHERE f.concept='creatinine') AS creatinine_mean_mg_dl,
 avg(f.value) FILTER(WHERE f.concept='hemoglobin') AS hemoglobin_mean_g_dl,
 avg(f.value) FILTER(WHERE f.concept='map') AS map_mean_mm_hg,
 CASE WHEN count(f.value) FILTER(WHERE f.concept='creatinine')=0 THEN 1 ELSE 0 END AS creatinine_missing,
 CASE WHEN count(f.value) FILTER(WHERE f.concept='hemoglobin')=0 THEN 1 ELSE 0 END AS hemoglobin_missing,
 count(f.value) FILTER(WHERE f.concept='creatinine') AS creatinine_count,
 count(f.value) FILTER(WHERE f.concept='hemoglobin') AS hemoglobin_count,
 count(f.value) FILTER(WHERE f.concept='map') AS map_count
FROM pg_temp.v13_primary_risk_set c
CROSS JOIN (VALUES('PRIMARY'),('CHARTTIME_ONLY_SENSITIVITY')) m(mode)
LEFT JOIN pg_temp.v13_numeric_fused_16 f ON f.stay_id=c.stay_id AND f.mode=m.mode
GROUP BY c.stay_id,c.subject_id,c.hadm_id,m.mode;
ALTER TABLE pg_temp.v13_numeric_features_16 ADD PRIMARY KEY(stay_id,mode);

CREATE TEMP TABLE v13_numeric_audit_16 ON COMMIT DROP AS
SELECT concept,'RAW_WINDOW_ROWS'::text AS metric,count(*)::bigint AS n FROM pg_temp.v13_numeric_row_qc_16 GROUP BY concept
UNION ALL SELECT concept,'LATE_STORETIME',count(*) FROM pg_temp.v13_numeric_row_qc_16 WHERE storetime>landmark_time GROUP BY concept
UNION ALL SELECT concept,'MISSING_STORETIME',count(*) FROM pg_temp.v13_numeric_row_qc_16 WHERE storetime IS NULL GROUP BY concept
UNION ALL SELECT concept,'BAD_UNIT',count(*) FROM pg_temp.v13_numeric_row_qc_16 WHERE NOT valid_unit GROUP BY concept
UNION ALL SELECT concept,'INVALID_VALUE',count(*) FROM pg_temp.v13_numeric_row_qc_16 WHERE NOT valid_value GROUP BY concept
UNION ALL SELECT concept,mode||'_CONFLICT_POINTS',count(*) FROM pg_temp.v13_numeric_point_qc_16 WHERE distinct_values>1 GROUP BY concept,mode
UNION ALL SELECT concept,mode||'_EQUAL_REPEAT_ROWS_REMOVED',sum(source_rows-1)::bigint FROM pg_temp.v13_numeric_point_qc_16 WHERE distinct_values=1 GROUP BY concept,mode;
DO $verify$
BEGIN
 IF (SELECT count(*) FROM pg_temp.v13_numeric_features_16)<>2*(SELECT count(*) FROM pg_temp.v13_primary_risk_set)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_numeric_features_16 WHERE map_mean_mm_hg=0
      OR creatinine_missing<>(creatinine_mean_mg_dl IS NULL)::integer
      OR hemoglobin_missing<>(hemoglobin_mean_g_dl IS NULL)::integer)
 THEN RAISE EXCEPTION 'V13_NUMERIC_FEATURE_RECONCILIATION'; END IF;
END $verify$;


