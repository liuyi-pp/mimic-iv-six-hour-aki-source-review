-- SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Original source is preserved; derived-source configuration changes are separately logged.
-- No data, fitted artifacts, run outputs or credentials accompany this file.
-- Optional/sensitivity branches are not evidence those analyses were performed.





DO $guard$
BEGIN
 
 
 IF current_user::text IS DISTINCT FROM current_setting('v13.authorized_source_role',true) OR
    current_setting('periop_aki.v13_adapter_test_mode',true) IS DISTINCT FROM 'SYNTHETIC_SOURCE_ONLY'
 THEN RAISE EXCEPTION 'V13_ADAPTER_NOT_PRODUCTION_AUTHORIZED'; END IF;
 IF to_regclass('pg_temp.v13_stage_ledger') IS NULL OR to_regclass('pg_temp.eligibility_mapping') IS NULL
 THEN RAISE EXCEPTION 'V13_ADAPTER_INPUTS_REQUIRED'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.v13_stage_ledger)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_stays)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_scr_valid)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_renal_flags)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_surgery_evidence)
 THEN RAISE EXCEPTION 'V13_ADAPTER_REQUIRES_EMPTY_INPUTS'; END IF;
 IF NOT EXISTS(SELECT 1 FROM pg_temp.eligibility_mapping)
    OR EXISTS(SELECT 1 FROM pg_temp.eligibility_mapping WHERE review_status_code IS DISTINCT FROM 'CONFIRMED')
 THEN RAISE EXCEPTION 'V13_SURGERY_MAPPING_NOT_CONFIRMED'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.eligibility_mapping WHERE database_name='MIMIC_IV'
    AND evidence_domain IN('procedures_icd','hcpcsevents')
    AND (source_identifier IS NULL OR btrim(source_identifier)='' OR eligibility_role_code IS NULL
         OR (evidence_domain='procedures_icd' AND secondary_identifier_1 IS NULL)))
 THEN RAISE EXCEPTION 'V13_SURGERY_MAPPING_FIELDS_MISSING'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.eligibility_mapping WHERE database_name='MIMIC_IV'
    AND evidence_domain IN('procedures_icd','hcpcsevents')
    GROUP BY evidence_domain,source_identifier,secondary_identifier_1
    HAVING count(DISTINCT eligibility_role_code)>1)
 THEN RAISE EXCEPTION 'V13_SURGERY_MAPPING_ROLE_CONFLICT'; END IF;
END $guard$;

CREATE TEMP TABLE v13_adapter_audit(metric text PRIMARY KEY,n bigint NOT NULL) ON COMMIT DROP;
CREATE TEMP TABLE v13_surgical_candidates ON COMMIT DROP AS
WITH adult AS MATERIALIZED (
 SELECT i.*,p.anchor_age+extract(year FROM i.intime)::integer-p.anchor_year AS age_years
 FROM mimiciv_icu.icustays i JOIN mimiciv_hosp.patients p USING(subject_id)
 WHERE p.anchor_age+extract(year FROM i.intime)::integer-p.anchor_year>=18
), evidence AS MATERIALIZED (
 SELECT a.subject_id,a.hadm_id,a.stay_id,a.intime,a.outtime,a.age_years,p.chartdate,
        m.eligibility_role_code
 FROM adult a JOIN mimiciv_hosp.procedures_icd p USING(subject_id,hadm_id)
 JOIN pg_temp.eligibility_mapping m ON m.database_name='MIMIC_IV'
  AND m.evidence_domain='procedures_icd' AND m.source_identifier=btrim(p.icd_code)
  AND m.secondary_identifier_1=p.icd_version::text
 WHERE (p.chartdate-a.intime::date) BETWEEN -1 AND 0
 UNION ALL
 SELECT a.subject_id,a.hadm_id,a.stay_id,a.intime,a.outtime,a.age_years,h.chartdate,
        m.eligibility_role_code
 FROM adult a JOIN mimiciv_hosp.hcpcsevents h USING(subject_id,hadm_id)
 JOIN pg_temp.eligibility_mapping m ON m.database_name='MIMIC_IV'
  AND m.evidence_domain='hcpcsevents' AND m.source_identifier=btrim(h.hcpcs_cd)
 WHERE (h.chartdate-a.intime::date) BETWEEN -1 AND 0
)
SELECT subject_id,hadm_id,stay_id,intime,outtime,age_years,
 bool_or(eligibility_role_code='PRIMARY_QUALIFYING') AS has_primary,
 bool_or(eligibility_role_code='EXCLUDE_CARDIAC') AS has_cardiac,
 bool_or(eligibility_role_code='EXCLUDE_OBSTETRIC') AS has_obstetric,
 bool_or(eligibility_role_code='PRIMARY_QUALIFYING' AND chartdate=intime::date) AS same_day_primary,
 bool_or(eligibility_role_code='PRIMARY_QUALIFYING' AND chartdate=intime::date-1) AS prior_day_primary
FROM evidence GROUP BY subject_id,hadm_id,stay_id,intime,outtime,age_years;
CREATE TEMP TABLE v13_first_candidates ON COMMIT DROP AS
SELECT * FROM (
 SELECT c.*,row_number() OVER(PARTITION BY subject_id ORDER BY intime,stay_id) AS eligible_rank
 FROM pg_temp.v13_surgical_candidates c WHERE has_primary AND NOT has_cardiac AND NOT has_obstetric
) q WHERE eligible_rank=1;
DO $admission_guard$
BEGIN
 IF EXISTS(SELECT 1 FROM pg_temp.v13_first_candidates c LEFT JOIN mimiciv_hosp.admissions a
   USING(subject_id,hadm_id) GROUP BY c.stay_id HAVING count(a.hadm_id)<>1)
 THEN RAISE EXCEPTION 'V13_INDEX_ADMISSION_KEY_MISMATCH'; END IF;
END $admission_guard$;
INSERT INTO pg_temp.v13_stays
SELECT c.stay_id,c.subject_id,c.hadm_id,c.intime,a.dischtime,a.deathtime,a.hospital_expire_flag,c.outtime
FROM pg_temp.v13_first_candidates c JOIN mimiciv_hosp.admissions a USING(subject_id,hadm_id);
INSERT INTO pg_temp.v13_surgery_evidence
SELECT stay_id,true,same_day_primary,'MAPPING_NOT_VALIDATED',true FROM pg_temp.v13_first_candidates;


INSERT INTO pg_temp.v13_adapter_audit VALUES
 ('candidate_stays',(SELECT count(*) FROM pg_temp.v13_stays)),
 ('same_and_prior_day_qualifiers',(SELECT count(*) FROM pg_temp.v13_first_candidates WHERE same_day_primary AND prior_day_primary));

CREATE TEMP TABLE v13_scr_source_rows ON COMMIT DROP AS
SELECT s.stay_id,s.hadm_id AS index_hadm_id,s.intime,s.dischtime,s.deathtime,
 l.labevent_id,l.hadm_id AS source_hadm_id,l.charttime,l.storetime,l.valuenum,l.valueuom,
 CASE WHEN l.charttime IS NULL THEN 'MISSING_TIME'
      WHEN l.charttime>=s.intime AND l.hadm_id IS DISTINCT FROM s.hadm_id THEN 'NON_INDEX_POST_ICU'
      WHEN l.valuenum IS NULL THEN 'MISSING_VALUE'
      WHEN lower(replace(coalesce(l.valueuom,''),' ',''))<>'mg/dl' THEN 'UNSUPPORTED_UNIT'
      WHEN NOT(l.valuenum BETWEEN .1 AND 30) THEN 'OUT_OF_RANGE'
      ELSE 'VALID_ROW' END AS row_status
FROM pg_temp.v13_stays s JOIN mimiciv_hosp.labevents l ON l.subject_id=s.subject_id AND l.itemid=50912
 AND (l.charttime IS NULL OR (l.charttime>=s.intime-interval '365 days'
  AND l.charttime<=least(s.intime+interval '168 hours',s.dischtime,s.deathtime)));


INSERT INTO pg_temp.v13_adapter_audit
SELECT 'scr_raw_'||row_status,count(*) FROM pg_temp.v13_scr_source_rows GROUP BY row_status;
CREATE TEMP TABLE v13_scr_qc ON COMMIT DROP AS
SELECT stay_id,charttime,count(*) AS valid_rows,count(DISTINCT valuenum) AS distinct_values,
 count(DISTINCT source_hadm_id) AS distinct_hadm_ids,
 min(valuenum) AS value,
 CASE WHEN bool_or(source_hadm_id=index_hadm_id) THEN min(index_hadm_id)
      WHEN count(DISTINCT source_hadm_id)=1 THEN min(source_hadm_id)
      ELSE NULL END AS retained_source_hadm_id
FROM pg_temp.v13_scr_source_rows WHERE row_status='VALID_ROW' GROUP BY stay_id,charttime;
INSERT INTO pg_temp.v13_scr_valid
SELECT stay_id,retained_source_hadm_id,charttime,value FROM pg_temp.v13_scr_qc WHERE distinct_values=1;
INSERT INTO pg_temp.v13_adapter_audit VALUES
 ('scr_conflicting_points',(SELECT count(*) FROM pg_temp.v13_scr_qc WHERE distinct_values>1)),
 ('scr_repeated_equal_rows',(SELECT coalesce(sum(valid_rows-1),0) FROM pg_temp.v13_scr_qc WHERE distinct_values=1)),
 ('scr_pre_icu_ambiguous_hadm',(SELECT count(*) FROM pg_temp.v13_scr_qc WHERE distinct_values=1 AND distinct_hadm_ids>1)),
 ('scr_retained_points',(SELECT count(*) FROM pg_temp.v13_scr_valid));

CREATE TEMP TABLE v13_prior_renal_evidence ON COMMIT DROP AS
SELECT s.stay_id,
 EXISTS(SELECT 1 FROM mimiciv_hosp.admissions a JOIN mimiciv_hosp.diagnoses_icd d USING(subject_id,hadm_id)
   WHERE a.subject_id=s.subject_id AND a.hadm_id<>s.hadm_id AND a.dischtime<s.intime
    AND ((d.icd_version=9 AND btrim(d.icd_code) LIKE '585%')
      OR (d.icd_version=10 AND btrim(d.icd_code) LIKE 'N18%'))) AS prior_ckd,
 EXISTS(SELECT 1 FROM mimiciv_hosp.admissions a JOIN mimiciv_hosp.procedures_icd p USING(subject_id,hadm_id)
   WHERE a.subject_id=s.subject_id AND a.hadm_id<>s.hadm_id AND a.dischtime<s.intime
    AND ((p.icd_version=9 AND btrim(p.icd_code) IN('3995','5498'))
      OR (p.icd_version=10 AND btrim(p.icd_code)='3E1M39Z'))) AS prior_dialysis_procedure,
 EXISTS(SELECT 1 FROM mimiciv_hosp.diagnoses_icd d WHERE d.subject_id=s.subject_id AND d.hadm_id=s.hadm_id
    AND ((d.icd_version=9 AND btrim(d.icd_code) IN('5856','V4511'))
      OR (d.icd_version=10 AND btrim(d.icd_code) IN('N186','Z992')))) AS frozen_cohort_exclusion
FROM pg_temp.v13_stays s;



CREATE TEMP TABLE v13_rrt_source_rows ON COMMIT DROP AS
SELECT s.stay_id,s.intime,s.dischtime,s.deathtime,p.itemid,p.starttime,p.endtime,p.storetime,
 p.starttime IS NULL OR (p.endtime IS NOT NULL AND p.endtime<p.starttime) AS time_quality_issue
FROM pg_temp.v13_stays s JOIN mimiciv_icu.procedureevents p
 ON p.subject_id=s.subject_id AND p.hadm_id=s.hadm_id AND p.stay_id=s.stay_id
WHERE p.itemid IN(225441,225802,225805)
 AND (p.starttime IS NULL OR p.starttime<=least(s.intime+interval '168 hours',s.dischtime,s.deathtime));
CREATE TEMP TABLE v13_rrt_derived ON COMMIT DROP AS
SELECT stay_id,itemid,starttime,endtime,bool_or(time_quality_issue) AS time_quality_issue,
 min(storetime) AS earliest_recorded_storetime
FROM pg_temp.v13_rrt_source_rows GROUP BY stay_id,itemid,starttime,endtime;



INSERT INTO pg_temp.v13_renal_flags
SELECT s.stay_id,e.prior_ckd,e.frozen_cohort_exclusion,
 coalesce(bool_or(NOT r.time_quality_issue AND r.starttime<=s.intime+interval '6 hours'),false),
 coalesce(bool_or(NOT r.time_quality_issue AND r.starttime>s.intime+interval '6 hours'),false),
 coalesce(bool_or(r.time_quality_issue),false),e.prior_dialysis_procedure,true
FROM pg_temp.v13_stays s JOIN pg_temp.v13_prior_renal_evidence e USING(stay_id)
LEFT JOIN pg_temp.v13_rrt_derived r USING(stay_id)
GROUP BY s.stay_id,e.prior_ckd,e.frozen_cohort_exclusion,e.prior_dialysis_procedure;
INSERT INTO pg_temp.v13_adapter_audit VALUES
 ('rrt_raw_rows',(SELECT count(*) FROM pg_temp.v13_rrt_source_rows)),
 ('rrt_derived_events',(SELECT count(*) FROM pg_temp.v13_rrt_derived)),
 ('rrt_time_quality_events',(SELECT count(*) FROM pg_temp.v13_rrt_derived WHERE time_quality_issue)),
 ('early_rrt_late_or_missing_storetime',(SELECT count(*) FROM pg_temp.v13_rrt_source_rows WHERE starttime<=intime+interval '6 hours' AND (storetime IS NULL OR storetime>intime+interval '6 hours'))),
 ('prior_completed_ckd_stays',(SELECT count(*) FROM pg_temp.v13_prior_renal_evidence WHERE prior_ckd)),
 ('prior_completed_dialysis_procedure_stays',(SELECT count(*) FROM pg_temp.v13_prior_renal_evidence WHERE prior_dialysis_procedure)),
 ('exact_surgical_time_mapping_validated',0);





CREATE TEMP TABLE v13_adapter_limitations(code text PRIMARY KEY,detail text NOT NULL) ON COMMIT DROP;
INSERT INTO pg_temp.v13_adapter_limitations VALUES
 ('DIALYSIS_SUPPORT_VALUE_PREDICATE_UNRESOLVED','chartevents/inputevents dialysis support is not promoted to chronic evidence without an executable positive-value mapping'),
 ('PRECISE_SURGERY_MAPPING_NOT_VALIDATED','No exact surgical event-time branch; not zero patients'),
 ('REAL_SOURCE_HASH_PREFLIGHT_REQUIRED','SQL source reads do not validate signed workbook/mapping hashes or authorize production');
DO $complete$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM pg_temp.v13_stays)
    OR (SELECT count(*) FROM pg_temp.v13_stays)<>(SELECT count(*) FROM pg_temp.v13_renal_flags)
    OR (SELECT count(*) FROM pg_temp.v13_stays)<>(SELECT count(*) FROM pg_temp.v13_surgery_evidence)
 THEN RAISE EXCEPTION 'V13_ADAPTER_DENOMINATOR_MISMATCH'; END IF;
END $complete$;
