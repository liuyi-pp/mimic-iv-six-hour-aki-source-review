-- SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Original source is preserved; derived-source configuration changes are separately logged.
-- No data, fitted artifacts, run outputs or credentials accompany this file.
-- Optional/sensitivity branches are not evidence those analyses were performed.



DO $guard$
BEGIN
 IF to_regclass('pg_temp.v13_stage_ledger') IS NULL THEN RAISE EXCEPTION 'V13_INPUT_CONTRACT_REQUIRED'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.v13_stage_ledger) THEN RAISE EXCEPTION 'V13_STAGE_ORDER_15B'; END IF;
 IF NOT EXISTS(SELECT 1 FROM pg_temp.v13_stays) THEN RAISE EXCEPTION 'V13_EMPTY_INPUT'; END IF;
 IF (SELECT count(*) FROM pg_temp.v13_stays)<>(SELECT count(*) FROM pg_temp.v13_renal_flags)
    OR EXISTS(SELECT 1 FROM pg_temp.v13_renal_flags WHERE NOT source_evidence_verified)
 THEN RAISE EXCEPTION 'V13_RENAL_SOURCE_CONTRACT_INCOMPLETE'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.v13_stays WHERE dischtime<intime OR deathtime<intime OR outtime<intime)
 THEN RAISE EXCEPTION 'V13_ENDPOINT_BEFORE_ICU'; END IF;
END $guard$;

CREATE TEMP TABLE v13_endpoints ON COMMIT DROP AS
SELECT s.*,
 CASE WHEN deathtime IS NOT NULL THEN 'KNOWN_DEATH_ENDPOINT'
      WHEN hospital_expire_flag=1 THEN 'UNKNOWN_DEATH_TIME'
      WHEN dischtime IS NULL THEN 'UNKNOWN_DISCHARGE_ENDPOINT'
      WHEN dischtime<intime+interval '168 hours' THEN 'EARLY_DISCHARGE_CENSORED'
      ELSE 'OBSERVED_TO_168H' END endpoint_class,
 CASE WHEN deathtime IS NOT NULL THEN least(deathtime,dischtime,intime+interval '168 hours')
      WHEN hospital_expire_flag=1 OR dischtime IS NULL THEN NULL
      ELSE least(dischtime,intime+interval '168 hours') END observation_end
FROM pg_temp.v13_stays s;
ALTER TABLE pg_temp.v13_endpoints ADD PRIMARY KEY(stay_id);

CREATE TEMP TABLE v13_baselines ON COMMIT DROP AS
SELECT s.stay_id,
 CASE WHEN count(v.scr_mg_dl) FILTER(WHERE v.charttime<s.intime-interval '7 days')>0
      THEN percentile_cont(.5) WITHIN GROUP(ORDER BY v.scr_mg_dl) FILTER(WHERE v.charttime<s.intime-interval '7 days')
      ELSE min(v.scr_mg_dl) FILTER(WHERE v.charttime>=s.intime-interval '7 days') END baseline_value,
 CASE WHEN count(v.scr_mg_dl) FILTER(WHERE v.charttime<s.intime-interval '7 days')>0 THEN 'REMOTE_MEDIAN'
      WHEN count(v.scr_mg_dl)>0 THEN 'RECENT_MIN' ELSE 'NO_BASELINE' END baseline_source
FROM pg_temp.v13_stays s LEFT JOIN pg_temp.v13_scr_valid v
 ON v.stay_id=s.stay_id AND v.charttime>=s.intime-interval '365 days' AND v.charttime<s.intime
GROUP BY s.stay_id;
ALTER TABLE pg_temp.v13_baselines ADD PRIMARY KEY(stay_id);

CREATE TEMP TABLE v13_comparisons ON COMMIT DROP AS
SELECT s.stay_id,v.charttime,v.scr_mg_dl,b.baseline_value,b.baseline_source,
 extract(epoch FROM v.charttime-s.intime)/3600.0 AS hours_from_icu,
 EXISTS(SELECT 1 FROM pg_temp.v13_scr_valid a WHERE a.stay_id=s.stay_id
        AND a.charttime<v.charttime AND a.charttime>=v.charttime-interval '168 hours') AS anchor7d,
 EXISTS(SELECT 1 FROM pg_temp.v13_scr_valid a WHERE a.stay_id=s.stay_id
        AND a.charttime<v.charttime AND a.charttime>=v.charttime-interval '48 hours'
        AND (a.charttime<s.intime OR a.source_hadm_id=s.hadm_id)) AS has_ordered_pair,
 EXISTS(SELECT 1 FROM pg_temp.v13_scr_valid a WHERE a.stay_id=s.stay_id
        AND a.charttime<v.charttime AND a.charttime>=v.charttime-interval '48 hours'
        AND (a.charttime<s.intime OR a.source_hadm_id=s.hadm_id)
        AND v.scr_mg_dl-a.scr_mg_dl>=.3-1e-12) AS absolute_positive,
 coalesce(v.scr_mg_dl>=1.5*b.baseline_value-1e-12,false) AS relative_hit
FROM pg_temp.v13_endpoints s JOIN pg_temp.v13_baselines b USING(stay_id)
JOIN pg_temp.v13_scr_valid v ON v.stay_id=s.stay_id
 AND v.charttime>=s.intime-interval '168 hours'
 AND v.charttime<=s.intime+interval '168 hours'
 AND (v.charttime<s.intime OR v.source_hadm_id=s.hadm_id)
 
 
 AND (s.dischtime IS NULL OR v.charttime<=s.dischtime)
 AND (s.deathtime IS NULL OR v.charttime<=s.deathtime);
CREATE INDEX ON v13_comparisons(stay_id,charttime);



CREATE TEMP TABLE v13_early_flags ON COMMIT DROP AS
SELECT s.stay_id,t.threshold,
 coalesce(bool_or(c.hours_from_icu BETWEEN 0 AND 6 AND
    (c.absolute_positive OR (c.relative_hit AND (c.anchor7d OR
     (NOT r.prior_ckd AND NOT r.esrd_or_maintenance AND NOT r.early_rrt
      AND NOT r.other_chronic_evidence_by_h6 AND c.baseline_value<t.threshold))))),false) AS early_aki
FROM pg_temp.v13_stays s JOIN pg_temp.v13_renal_flags r USING(stay_id)
CROSS JOIN (VALUES(3.0),(4.0),(5.0)) t(threshold)
LEFT JOIN pg_temp.v13_comparisons c USING(stay_id)
GROUP BY s.stay_id,t.threshold;

CREATE TEMP TABLE v13_relative_tiers ON COMMIT DROP AS
SELECT c.*,t.threshold,
 CASE WHEN NOT c.relative_hit THEN 'NO_RELATIVE_HIT'
      WHEN c.anchor7d THEN 'ACUTE_ANCHORED'
      WHEN NOT r.prior_ckd AND NOT r.esrd_or_maintenance AND NOT r.early_rrt
       AND NOT r.other_chronic_evidence_by_h6 AND c.baseline_value<t.threshold
       AND (c.hours_from_icu<=6 OR NOT t.early_aki) THEN 'ACUTE_PRESUMED_NO_CKD'
      ELSE 'ACUTE_UNCERTAIN_REMOTE' END relative_tier
FROM pg_temp.v13_comparisons c JOIN pg_temp.v13_renal_flags r USING(stay_id)
JOIN pg_temp.v13_early_flags t USING(stay_id);

CREATE TEMP TABLE v13_labels_15b ON COMMIT DROP AS
WITH flags AS (
 SELECT s.stay_id,t.threshold,
  coalesce(bool_or(c.hours_from_icu>=-168 AND c.hours_from_icu<0 AND
   (c.absolute_positive OR c.relative_tier IN('ACUTE_ANCHORED','ACUTE_PRESUMED_NO_CKD'))),false) AS pre_aki,
  coalesce(bool_or(c.hours_from_icu>6 AND c.absolute_positive),false) AS incident_absolute,
  coalesce(bool_or(c.hours_from_icu>6 AND c.relative_tier IN('ACUTE_ANCHORED','ACUTE_PRESUMED_NO_CKD')),false) AS incident_relative,
  coalesce(bool_or(c.hours_from_icu>6 AND c.relative_tier='ACUTE_UNCERTAIN_REMOTE'),false) AS incident_uncertain,
  min(c.charttime) FILTER(WHERE c.hours_from_icu>6 AND
   (c.absolute_positive OR c.relative_tier IN('ACUTE_ANCHORED','ACUTE_PRESUMED_NO_CKD'))) AS first_incident_time,
  count(c.charttime) FILTER(WHERE c.hours_from_icu>6) AS post_valid_count,
  count(c.charttime) FILTER(WHERE c.hours_from_icu>6 AND c.has_ordered_pair) AS post_pairs,
  max(c.charttime) FILTER(WHERE c.hours_from_icu>6) AS last_post_scr
 FROM pg_temp.v13_stays s CROSS JOIN (VALUES(3.0),(4.0),(5.0)) t(threshold)
 LEFT JOIN pg_temp.v13_relative_tiers c ON c.stay_id=s.stay_id AND c.threshold=t.threshold
 GROUP BY s.stay_id,t.threshold
), assembled AS (
 SELECT s.*,b.baseline_value,b.baseline_source,r.prior_ckd,r.esrd_or_maintenance,
  r.early_rrt,r.post_rrt,r.rrt_quality_issue,f.threshold,f.pre_aki,e.early_aki,
  f.incident_absolute,f.incident_relative,f.incident_uncertain,f.first_incident_time,
  f.post_valid_count,f.post_pairs,f.last_post_scr,
  extract(epoch FROM s.observation_end-s.intime)/3600.0 AS observation_hours,
  CASE WHEN r.esrd_or_maintenance THEN 'EXCLUDED_CHRONIC_RENAL'
       WHEN f.pre_aki THEN 'EXCLUDED_PREVALENT_AKI'
       WHEN e.early_aki THEN 'EXCLUDED_EARLY_AKI'
       WHEN r.early_rrt THEN 'EXCLUDED_EARLY_RRT'
       WHEN f.incident_absolute OR f.incident_relative THEN 'INCIDENT_AKI'
       WHEN r.post_rrt THEN 'INDETERMINATE_POST_RRT_ONLY'
       WHEN r.rrt_quality_issue THEN 'INDETERMINATE_RRT_QUALITY'
       WHEN f.incident_uncertain THEN 'INDETERMINATE_ACUTE_INFERENCE'
       WHEN s.observation_end IS NULL THEN 'INDETERMINATE_UNKNOWN_ENDPOINT'
       WHEN b.baseline_value IS NOT NULL AND f.post_pairs>0 AND f.post_valid_count>=2
        AND f.last_post_scr>=s.intime+interval '120 hours'
        AND s.observation_end>=s.intime+interval '168 hours' THEN 'NO_AKI_OBSERVED'
       WHEN s.endpoint_class='KNOWN_DEATH_ENDPOINT' AND s.observation_end<s.intime+interval '168 hours' THEN 'CENSORED_KNOWN_DEATH'
       WHEN s.endpoint_class='EARLY_DISCHARGE_CENSORED' THEN 'CENSORED_EARLY_DISCHARGE'
       WHEN b.baseline_value IS NULL THEN 'INDETERMINATE_NO_BASELINE'
       ELSE 'INDETERMINATE_INSUFFICIENT_SCR' END AS label_status
 FROM pg_temp.v13_endpoints s JOIN pg_temp.v13_baselines b USING(stay_id)
 JOIN pg_temp.v13_renal_flags r USING(stay_id) JOIN flags f USING(stay_id)
 JOIN pg_temp.v13_early_flags e ON e.stay_id=s.stay_id AND e.threshold=f.threshold
)
SELECT a.*,CASE WHEN label_status='INCIDENT_AKI' THEN true
               WHEN label_status='NO_AKI_OBSERVED' THEN false ELSE NULL END AS incident_aki,
 label_status IN('INCIDENT_AKI','NO_AKI_OBSERVED') AS resolved,
 threshold=4.0 AS primary_threshold
FROM assembled a;
ALTER TABLE pg_temp.v13_labels_15b ADD PRIMARY KEY(stay_id,threshold);
DO $verify$
BEGIN
 IF (SELECT count(*) FROM pg_temp.v13_labels_15b)<>3*(SELECT count(*) FROM pg_temp.v13_stays)
 THEN RAISE EXCEPTION 'V13_LABEL_PARTITION_FAILED'; END IF;
END $verify$;
INSERT INTO pg_temp.v13_stage_ledger(stage) VALUES('15b');
