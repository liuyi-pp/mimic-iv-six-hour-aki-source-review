-- SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Original source is preserved; derived-source configuration changes are separately logged.
-- No data, fitted artifacts, run outputs or credentials accompany this file.
-- Optional/sensitivity branches are not evidence those analyses were performed.



DO $guard$
BEGIN
 IF to_regclass('pg_temp.v13_feature_matrix_16') IS NULL THEN RAISE EXCEPTION 'V13_OBSERVATION_REQUIRES_16'; END IF;
 IF (SELECT array_agg(stage ORDER BY stage) FROM pg_temp.v13_stage_ledger)
    IS DISTINCT FROM ARRAY['15b','16','19']::text[] THEN RAISE EXCEPTION 'V13_OBSERVATION_REQUIRES_16'; END IF;
 IF EXISTS(SELECT stay_id FROM pg_temp.v13_primary_risk_set EXCEPT SELECT stay_id FROM pg_temp.v13_feature_matrix_16)
 OR EXISTS(SELECT stay_id FROM pg_temp.v13_feature_matrix_16 EXCEPT SELECT stay_id FROM pg_temp.v13_primary_risk_set)
 THEN RAISE EXCEPTION 'V13_OBSERVATION_KEY_MISMATCH'; END IF;
END $guard$;
CREATE TEMP TABLE v13_observation_risk_17 ON COMMIT DROP AS
WITH prepared AS (
 SELECT m.*,l.resolved::integer AS resolved,l.observation_hours,l.post_valid_count,l.post_pairs,
  extract(epoch FROM l.last_post_scr-l.intime)/3600.0 AS last_post_scr_hours,
  l.endpoint_class,l.date_only_surgery,l.icu_restricted_sensitivity_eligible,l.exclude_date_only_sensitivity_eligible,
  (SELECT count(*) FROM unnest(ARRAY[m.age_years,m.female,m.prior_ckd,m.urgency_urgent,m.urgency_emergency,
    m.creatinine_mean_mg_dl,m.hemoglobin_mean_g_dl,m.urine_output_total_ml,m.fluid_input_total_ml,
    m.rbc_exposure,m.vasopressor_exposure,m.map_mean_mm_hg,m.mechanical_ventilation]) v
    WHERE v IS NOT NULL AND v::text NOT IN('NaN','Infinity','-Infinity')) AS observed_main_values,
  coalesce(l.baseline_value IS NOT NULL AND l.post_pairs>0 AND l.post_valid_count>=2
    AND l.last_post_scr>=l.intime+interval '72 hours' AND l.observation_hours>=120
    AND NOT l.post_rrt AND NOT l.rrt_quality_issue AND NOT l.incident_uncertain,false) AS relaxed_negative_evidence
 FROM pg_temp.v13_feature_matrix_16 m JOIN pg_temp.v13_primary_risk_set l USING(stay_id)
), classified AS (
 SELECT p.*,resolved=1 AND observed_main_values=13 AND map_mean_mm_hg>0 AS complete_case,
  CASE WHEN incident_aki=1 THEN 1 WHEN incident_aki=0 OR relaxed_negative_evidence THEN 0 END::integer AS relaxed_incident_aki,
  CASE WHEN incident_aki=1 THEN 'INCIDENT_AKI_UNCHANGED'
       WHEN incident_aki=0 THEN 'PRIMARY_NEGATIVE_UNCHANGED'
       WHEN relaxed_negative_evidence THEN 'RELAXED_NEGATIVE_72H_120H'
       ELSE 'UNRESOLVED_UNCHANGED' END AS relaxed_status
 FROM prepared p
)
SELECT c.*,(relaxed_incident_aki IS NOT NULL)::integer AS relaxed_resolved FROM classified c;
ALTER TABLE pg_temp.v13_observation_risk_17 ADD PRIMARY KEY(stay_id),ADD UNIQUE(subject_id);

CREATE TEMP TABLE v13_balance_long_17 ON COMMIT DROP AS
SELECT r.stay_id,r.resolved,p.position,p.column_name,p.column_role,
 (to_jsonb(r)->>p.column_name)::numeric AS value
FROM pg_temp.v13_observation_risk_17 r CROSS JOIN pg_temp.v13_predictor_contract_16 p;
CREATE TEMP TABLE v13_balance_summary_17 ON COMMIT DROP AS
WITH stats AS (
 SELECT p.position,p.column_name,p.column_role,
  count(l.stay_id) FILTER(WHERE resolved=1) AS resolved_n,
  count(l.value) FILTER(WHERE resolved=1) AS resolved_observed_n,
  count(l.stay_id) FILTER(WHERE resolved=0) AS unresolved_n,
  count(l.value) FILTER(WHERE resolved=0) AS unresolved_observed_n,
  avg(l.value) FILTER(WHERE resolved=1) AS resolved_mean,
  avg(l.value) FILTER(WHERE resolved=0) AS unresolved_mean,
  stddev_samp(l.value) FILTER(WHERE resolved=1) AS resolved_sd,
  stddev_samp(l.value) FILTER(WHERE resolved=0) AS unresolved_sd
 FROM pg_temp.v13_predictor_contract_16 p LEFT JOIN pg_temp.v13_balance_long_17 l USING(position,column_name,column_role)
 GROUP BY p.position,p.column_name,p.column_role
), denominators AS (
 SELECT s.*,CASE WHEN column_role='CONTINUOUS' THEN sqrt((resolved_sd^2+unresolved_sd^2)/2)
  ELSE sqrt((resolved_mean*(1-resolved_mean)+unresolved_mean*(1-unresolved_mean))/2) END AS smd_denominator
 FROM stats s
), smd_values AS (
 SELECT d.*,CASE WHEN resolved_observed_n=0 OR unresolved_observed_n=0 OR smd_denominator IS NULL THEN NULL
  WHEN smd_denominator>0 THEN (resolved_mean-unresolved_mean)/smd_denominator
  WHEN resolved_mean=unresolved_mean THEN 0 ELSE NULL END AS signed_smd
 FROM denominators d
)
SELECT v.*,abs(signed_smd) AS abs_smd,
 resolved_n-resolved_observed_n AS resolved_missing_n,unresolved_n-unresolved_observed_n AS unresolved_missing_n,
 CASE WHEN resolved_observed_n=0 OR unresolved_observed_n=0 OR smd_denominator IS NULL THEN 'INSUFFICIENT_OBSERVATIONS'
      WHEN smd_denominator=0 AND resolved_mean<>unresolved_mean THEN 'UNDEFINED_ZERO_VARIANCE'
      WHEN smd_denominator=0 THEN 'CONSTANT_EQUAL' ELSE 'DEFINED' END AS smd_status
FROM smd_values v;
CREATE TEMP TABLE v13_unresolved_reasons_17 ON COMMIT DROP AS
SELECT label_status,count(*) AS n FROM pg_temp.v13_observation_risk_17 WHERE resolved=0 GROUP BY label_status;
CREATE TEMP TABLE v13_observation_bands_17 ON COMMIT DROP AS
SELECT resolved,CASE WHEN post_valid_count=0 THEN '0' WHEN post_valid_count=1 THEN '1'
 WHEN post_valid_count<=3 THEN '2-3' ELSE '4+' END AS valid_post_scr_band,count(*) AS n
FROM pg_temp.v13_observation_risk_17 GROUP BY 1,2;
CREATE TEMP TABLE v13_observation_counts_17 ON COMMIT DROP AS
SELECT count(*) AS risk_n,count(*) FILTER(WHERE resolved=1) AS resolved_n,
 count(*) FILTER(WHERE resolved=0) AS unresolved_n,count(*) FILTER(WHERE complete_case) AS complete_case_n,
 count(*) FILTER(WHERE relaxed_resolved=1) AS relaxed_resolved_n,
 count(*) FILTER(WHERE relaxed_status='RELAXED_NEGATIVE_72H_120H') AS newly_relaxed_negative_n
FROM pg_temp.v13_observation_risk_17;
DO $verify$
BEGIN
 IF EXISTS(SELECT 1 FROM pg_temp.v13_observation_risk_17 WHERE resolved<>(incident_aki IS NOT NULL)::integer
    OR complete_case IS NULL OR (complete_case AND resolved=0)
    OR (incident_aki=1 AND relaxed_incident_aki IS DISTINCT FROM 1)
    OR (incident_aki=0 AND relaxed_incident_aki IS DISTINCT FROM 0))
 OR (SELECT count(*) FROM pg_temp.v13_balance_summary_17)<>16
 OR (SELECT coalesce(sum(n),0) FROM pg_temp.v13_unresolved_reasons_17)<>(SELECT unresolved_n FROM pg_temp.v13_observation_counts_17)
 THEN RAISE EXCEPTION 'V13_OBSERVATION_RECONCILIATION'; END IF;
END $verify$;
INSERT INTO pg_temp.v13_stage_ledger(stage) VALUES('17');


