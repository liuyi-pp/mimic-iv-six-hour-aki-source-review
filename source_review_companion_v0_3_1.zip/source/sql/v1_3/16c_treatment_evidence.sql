-- SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Derived from an enumerated source snapshot; see README and internal provenance.
-- No research data, fitted parameters, individual predictions or credentials are embedded.
-- Prespecified algorithm constants are code, not fitted research results.
-- This is not the verified manuscript execution version and is not a complete pipeline.




DO $guard$
BEGIN
 IF to_regclass('pg_temp.v13_fluid_features_16') IS NULL OR to_regclass('pg_temp.v13_urine_features_16') IS NULL
 THEN RAISE EXCEPTION 'V13_TREATMENT_REQUIRES_16B'; END IF;
 IF (SELECT array_agg(stage ORDER BY stage) FROM pg_temp.v13_stage_ledger)
    IS DISTINCT FROM ARRAY['15b','19']::text[] THEN RAISE EXCEPTION 'V13_TREATMENT_REQUIRES_16B'; END IF;
END $guard$;
CREATE TEMP TABLE v13_treatment_input_raw_16 ON COMMIT DROP AS
SELECT c.stay_id,c.intime,c.intime+interval '6 hours' AS landmark_time,
 CASE WHEN i.itemid IN(220996,225168) THEN 'rbc' ELSE 'vasopressor' END AS concept,
 i.itemid,i.starttime,i.endtime,i.storetime,i.amount::numeric AS amount,i.rate::numeric AS rate,
 lower(replace(coalesce(i.amountuom,''),' ','')) AS amount_unit,
 lower(replace(coalesce(i.rateuom,''),' ','')) AS rate_unit,
 upper(btrim(coalesce(i.statusdescription,''))) AS status
FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.inputevents i
 ON i.subject_id=c.subject_id AND i.hadm_id=c.hadm_id AND i.stay_id=c.stay_id
WHERE i.itemid IN(220996,225168,221289,221662,221749,221906,222315,229617,229630,229631,229632)
 AND (i.starttime IS NULL OR (i.starttime<=c.intime+interval '6 hours'
 AND (i.endtime IS NULL OR i.endtime>=c.intime OR i.endtime<i.starttime)));
CREATE TEMP TABLE v13_treatment_input_qc_16 ON COMMIT DROP AS
WITH parsed AS (
 SELECT r.*,
  coalesce(amount>=0 AND amount::text NOT IN('NaN','Infinity','-Infinity') AND
   (amount_unit='ml' OR (concept='vasopressor' AND amount_unit IN('mg','mcg','units','unit','u','iu'))),false) AS valid_amount,
  coalesce(rate>=0 AND rate::text NOT IN('NaN','Infinity','-Infinity') AND
   (rate_unit IN('ml/h','ml/hr','ml/hour') OR (concept='vasopressor' AND rate_unit IN(
    'mg/h','mg/hr','mg/hour','mg/min','mcg/h','mcg/hr','mcg/hour','mcg/min','mcg/kg/min',
    'mcg/kg/h','mcg/kg/hr','mcg/kg/hour','units/min','units/h','units/hr','units/hour','unit/min','unit/hour','u/min','u/h','iu/h'))),false) AS valid_rate
 FROM pg_temp.v13_treatment_input_raw_16 r
)
SELECT r.*,CASE
 WHEN status='REWRITTEN' THEN 'EXCLUDED_REWRITTEN'
 WHEN starttime IS NULL OR endtime IS NULL OR endtime<starttime THEN 'UNKNOWN_TIME'
 WHEN storetime IS NULL OR storetime>landmark_time THEN 'UNKNOWN_AVAILABILITY'
 WHEN starttime>=intime AND endtime<=landmark_time AND valid_amount
   THEN CASE WHEN amount>0 THEN 'POSITIVE' ELSE 'RECORDED_ZERO' END
 WHEN least(endtime,landmark_time)>greatest(starttime,intime) AND valid_rate
   THEN CASE WHEN rate>0 THEN 'POSITIVE' ELSE 'RECORDED_ZERO' END
 ELSE 'UNKNOWN_VALUE_OR_UNIT' END AS evidence_status
FROM parsed r;
CREATE TEMP TABLE v13_ventilation_qc_16 ON COMMIT DROP AS
SELECT c.stay_id,p.itemid,p.starttime,p.endtime,p.storetime,
 CASE WHEN upper(btrim(coalesce(p.statusdescription,'')))='REWRITTEN' THEN 'EXCLUDED_REWRITTEN'
      WHEN p.starttime IS NULL OR p.endtime IS NULL OR p.endtime<=p.starttime THEN 'UNKNOWN_INTERVAL'
      WHEN p.storetime IS NULL OR p.storetime>c.intime+interval '6 hours' THEN 'UNKNOWN_AVAILABILITY'
      WHEN least(p.endtime,c.intime+interval '6 hours')>greatest(p.starttime,c.intime) THEN 'POSITIVE'
      ELSE 'NO_DURATION_IN_WINDOW' END AS evidence_status
FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.procedureevents p
 ON p.subject_id=c.subject_id AND p.hadm_id=c.hadm_id AND p.stay_id=c.stay_id
WHERE p.itemid=225792 AND (p.starttime IS NULL OR
 (p.starttime<=c.intime+interval '6 hours' AND (p.endtime IS NULL OR p.endtime>=c.intime OR p.endtime<p.starttime)));
CREATE TEMP TABLE v13_treatment_features_16 ON COMMIT DROP AS
SELECT c.stay_id,
 EXISTS(SELECT 1 FROM pg_temp.v13_treatment_input_qc_16 r WHERE r.stay_id=c.stay_id AND r.concept='rbc' AND evidence_status='POSITIVE')::integer AS rbc_exposure,
 EXISTS(SELECT 1 FROM pg_temp.v13_treatment_input_qc_16 r WHERE r.stay_id=c.stay_id AND r.concept='vasopressor' AND evidence_status='POSITIVE')::integer AS vasopressor_exposure,
 EXISTS(SELECT 1 FROM pg_temp.v13_ventilation_qc_16 r WHERE r.stay_id=c.stay_id AND evidence_status='POSITIVE')::integer AS mechanical_ventilation,
 (SELECT count(*) FROM pg_temp.v13_treatment_input_qc_16 r WHERE r.stay_id=c.stay_id AND r.concept='rbc' AND evidence_status LIKE 'UNKNOWN_%') AS rbc_unknown_rows,
 (SELECT count(*) FROM pg_temp.v13_treatment_input_qc_16 r WHERE r.stay_id=c.stay_id AND r.concept='vasopressor' AND evidence_status LIKE 'UNKNOWN_%') AS vasopressor_unknown_rows,
 (SELECT count(*) FROM pg_temp.v13_ventilation_qc_16 r WHERE r.stay_id=c.stay_id AND evidence_status LIKE 'UNKNOWN_%') AS ventilation_unknown_rows
FROM pg_temp.v13_primary_risk_set c;
ALTER TABLE pg_temp.v13_treatment_features_16 ADD PRIMARY KEY(stay_id);
CREATE TEMP TABLE v13_treatment_audit_16 ON COMMIT DROP AS
SELECT concept,evidence_status AS metric,count(*) AS n FROM pg_temp.v13_treatment_input_qc_16 GROUP BY concept,evidence_status
UNION ALL SELECT 'ventilation',evidence_status,count(*) FROM pg_temp.v13_ventilation_qc_16 GROUP BY evidence_status
UNION ALL SELECT 'vasopressor','LEGACY_229631_ROWS',count(*) FROM pg_temp.v13_treatment_input_qc_16 WHERE itemid=229631
UNION ALL SELECT 'ventilation','INTUBATION_224385_WINDOW_SUPPORT_ROWS',count(*)
 FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.procedureevents p ON p.subject_id=c.subject_id AND p.hadm_id=c.hadm_id AND p.stay_id=c.stay_id
 WHERE p.itemid=224385 AND p.starttime BETWEEN c.intime AND c.intime+interval '6 hours' AND p.storetime<=c.intime+interval '6 hours'
UNION ALL SELECT 'ventilation','WINDOW_226260_SUPPORT_RECORDS_NOT_POSITIVE_PREDICATE',count(*)
 FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.chartevents e ON e.subject_id=c.subject_id AND e.hadm_id=c.hadm_id AND e.stay_id=c.stay_id
 WHERE e.itemid=226260 AND e.charttime BETWEEN c.intime AND c.intime+interval '6 hours' AND e.storetime<=c.intime+interval '6 hours'
UNION ALL SELECT 'ventilation','DAY1_APACHE_NOT_PRIMARY_ROWS',count(*)
 FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.chartevents e ON e.subject_id=c.subject_id AND e.hadm_id=c.hadm_id AND e.stay_id=c.stay_id
 WHERE e.itemid IN(227061,227021) AND e.charttime BETWEEN c.intime AND c.intime+interval '24 hours';


