-- SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Original source is preserved; derived-source configuration changes are separately logged.
-- No data, fitted artifacts, run outputs or credentials accompany this file.
-- Optional/sensitivity branches are not evidence those analyses were performed.



CREATE TEMP TABLE v13_stage_ledger(stage text PRIMARY KEY, completed_at timestamp NOT NULL DEFAULT clock_timestamp()) ON COMMIT DROP;
CREATE TEMP TABLE v13_stays(
 stay_id bigint PRIMARY KEY, subject_id bigint UNIQUE NOT NULL, hadm_id bigint NOT NULL,
 intime timestamp NOT NULL, dischtime timestamp, deathtime timestamp,
 hospital_expire_flag integer CHECK(hospital_expire_flag IN(0,1)), outtime timestamp
) ON COMMIT DROP;


CREATE TEMP TABLE v13_scr_valid(
 stay_id bigint REFERENCES v13_stays NOT NULL, source_hadm_id bigint,
 charttime timestamp NOT NULL, scr_mg_dl double precision NOT NULL CHECK(scr_mg_dl BETWEEN .1 AND 30),
 PRIMARY KEY(stay_id,charttime)
) ON COMMIT DROP;
CREATE TEMP TABLE v13_renal_flags(
 stay_id bigint PRIMARY KEY REFERENCES v13_stays,
 prior_ckd boolean NOT NULL, esrd_or_maintenance boolean NOT NULL,
 early_rrt boolean NOT NULL, post_rrt boolean NOT NULL, rrt_quality_issue boolean NOT NULL,
 other_chronic_evidence_by_h6 boolean NOT NULL,
 source_evidence_verified boolean NOT NULL
) ON COMMIT DROP;





CREATE TEMP TABLE v13_surgery_evidence(
 stay_id bigint PRIMARY KEY REFERENCES v13_stays,
 frozen_surgery_related boolean NOT NULL, same_day_date_only boolean NOT NULL,
 precise_time_status text NOT NULL CHECK(precise_time_status='MAPPING_NOT_VALIDATED'),
 source_evidence_verified boolean NOT NULL,
 CHECK(NOT same_day_date_only OR frozen_surgery_related)
) ON COMMIT DROP;



