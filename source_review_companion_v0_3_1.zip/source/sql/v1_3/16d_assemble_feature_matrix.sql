-- SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Derived from an enumerated source snapshot; see README and internal provenance.
-- No research data, fitted parameters, individual predictions or credentials are embedded.
-- Prespecified algorithm constants are code, not fitted research results.
-- This is not the verified manuscript execution version and is not a complete pipeline.



DO $guard$
BEGIN
 IF to_regclass('pg_temp.v13_treatment_features_16') IS NULL THEN RAISE EXCEPTION 'V13_MATRIX_REQUIRES_16C'; END IF;
 IF (SELECT array_agg(stage ORDER BY stage) FROM pg_temp.v13_stage_ledger)
    IS DISTINCT FROM ARRAY['15b','19']::text[] THEN RAISE EXCEPTION 'V13_MATRIX_REQUIRES_16C'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.v13_primary_risk_set c
  WHERE (SELECT count(*) FROM mimiciv_hosp.patients p WHERE p.subject_id=c.subject_id)<>1
     OR (SELECT count(*) FROM mimiciv_hosp.admissions a WHERE a.subject_id=c.subject_id AND a.hadm_id=c.hadm_id)<>1)
 THEN RAISE EXCEPTION 'V13_MATRIX_DEMOGRAPHIC_KEY_MISMATCH'; END IF;
END $guard$;
CREATE TEMP TABLE v13_demographics_16 ON COMMIT DROP AS
SELECT c.stay_id,(p.anchor_age+extract(year FROM c.intime)::integer-p.anchor_year)::numeric AS age_years,
 CASE p.gender WHEN 'F' THEN 1 WHEN 'M' THEN 0 END::integer AS female,
 CASE WHEN a.admission_type IN('ELECTIVE','SURGICAL SAME DAY ADMISSION') THEN 'ELECTIVE'
      WHEN a.admission_type IN('URGENT','DIRECT OBSERVATION','AMBULATORY OBSERVATION','OBSERVATION ADMIT') THEN 'URGENT'
      WHEN a.admission_type IN('EW EMER.','EU OBSERVATION','DIRECT EMER.') THEN 'EMERGENCY' END AS urgency
FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_hosp.patients p USING(subject_id)
JOIN mimiciv_hosp.admissions a ON a.subject_id=c.subject_id AND a.hadm_id=c.hadm_id;
ALTER TABLE pg_temp.v13_demographics_16 ADD PRIMARY KEY(stay_id);
CREATE TEMP TABLE v13_predictor_contract_16(position integer PRIMARY KEY,column_name text UNIQUE NOT NULL,column_role text NOT NULL) ON COMMIT DROP;
INSERT INTO v13_predictor_contract_16 VALUES
 (1,'age_years','CONTINUOUS'),(2,'female','BINARY'),(3,'prior_ckd','BINARY'),
 (4,'urgency_urgent','BINARY'),(5,'urgency_emergency','BINARY'),
 (6,'creatinine_mean_mg_dl','CONTINUOUS'),(7,'creatinine_missing','MISSING_INDICATOR'),
 (8,'hemoglobin_mean_g_dl','CONTINUOUS'),(9,'hemoglobin_missing','MISSING_INDICATOR'),
 (10,'urine_output_total_ml','CONTINUOUS'),(11,'urine_output_missing','MISSING_INDICATOR'),
 (12,'fluid_input_total_ml','CONTINUOUS'),(13,'rbc_exposure','BINARY'),
 (14,'vasopressor_exposure','BINARY'),(15,'map_mean_mm_hg','CONTINUOUS'),(16,'mechanical_ventilation','BINARY');
CREATE TEMP TABLE v13_feature_matrix_16 ON COMMIT DROP AS
SELECT c.subject_id,c.hadm_id,c.stay_id,c.incident_aki::integer AS incident_aki,c.label_status,
 d.age_years,d.female,k.prior_ckd::integer AS prior_ckd,
 (d.urgency='URGENT')::integer AS urgency_urgent,(d.urgency='EMERGENCY')::integer AS urgency_emergency,
 n.creatinine_mean_mg_dl,n.creatinine_missing,n.hemoglobin_mean_g_dl,n.hemoglobin_missing,
 u.urine_output_total_ml,u.urine_output_missing,f.fluid_input_known_ml AS fluid_input_total_ml,
 t.rbc_exposure,t.vasopressor_exposure,n.map_mean_mm_hg,t.mechanical_ventilation
FROM pg_temp.v13_primary_risk_set c
JOIN pg_temp.v13_demographics_16 d USING(stay_id)
JOIN pg_temp.v13_renal_flags k USING(stay_id)
JOIN pg_temp.v13_numeric_features_16 n ON n.stay_id=c.stay_id AND n.mode='PRIMARY'
JOIN pg_temp.v13_urine_features_16 u ON u.stay_id=c.stay_id
JOIN pg_temp.v13_fluid_features_16 f ON f.stay_id=c.stay_id
JOIN pg_temp.v13_treatment_features_16 t ON t.stay_id=c.stay_id;
ALTER TABLE pg_temp.v13_feature_matrix_16 ADD PRIMARY KEY(stay_id),ADD UNIQUE(subject_id);
CREATE TEMP TABLE v13_matrix_qc_16 ON COMMIT DROP AS
SELECT 'RISK_ROWS'::text AS metric,count(*) AS n FROM pg_temp.v13_primary_risk_set
UNION ALL SELECT 'MATRIX_ROWS',count(*) FROM pg_temp.v13_feature_matrix_16
UNION ALL SELECT 'UNRESOLVED_RETAINED',count(*) FROM pg_temp.v13_feature_matrix_16 WHERE incident_aki IS NULL
UNION ALL SELECT 'DEMOGRAPHIC_UNKNOWN',count(*) FROM pg_temp.v13_feature_matrix_16
 WHERE age_years IS NULL OR female IS NULL OR urgency_urgent IS NULL OR urgency_emergency IS NULL
UNION ALL SELECT 'FLUID_UNASCERTAINABLE',count(*) FROM pg_temp.v13_fluid_features_16 WHERE fluid_status='UNASCERTAINABLE';
DO $verify$
BEGIN
 IF (SELECT count(*) FROM pg_temp.v13_feature_matrix_16)<>(SELECT count(*) FROM pg_temp.v13_primary_risk_set)
 OR EXISTS(SELECT 1 FROM pg_temp.v13_feature_matrix_16 WHERE age_years IS NULL OR age_years<18 OR female IS NULL
   OR urgency_urgent IS NULL OR urgency_emergency IS NULL OR prior_ckd IS NULL
   OR urgency_urgent+urgency_emergency>1
   OR creatinine_missing<>(creatinine_mean_mg_dl IS NULL)::integer
   OR hemoglobin_missing<>(hemoglobin_mean_g_dl IS NULL)::integer
   OR urine_output_missing<>(urine_output_total_ml IS NULL)::integer)
 THEN RAISE EXCEPTION 'V13_MATRIX_RECONCILIATION_OR_UNKNOWN_DEMOGRAPHIC'; END IF;
END $verify$;
INSERT INTO pg_temp.v13_stage_ledger(stage) VALUES('16');


