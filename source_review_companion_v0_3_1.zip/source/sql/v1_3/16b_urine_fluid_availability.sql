-- SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
-- Derived from an enumerated source snapshot; see README and internal provenance.
-- No research data, fitted parameters, individual predictions or credentials are embedded.
-- Prespecified algorithm constants are code, not fitted research results.
-- This is not the verified manuscript execution version and is not a complete pipeline.



DO $guard$
BEGIN
 IF to_regclass('pg_temp.v13_stage_ledger') IS NULL THEN RAISE EXCEPTION 'V13_VOLUME_REQUIRES_19_16A'; END IF;
 IF (SELECT array_agg(stage ORDER BY stage) FROM pg_temp.v13_stage_ledger)
      IS DISTINCT FROM ARRAY['15b','19']::text[]
    OR to_regclass('pg_temp.v13_numeric_features_16') IS NULL
 THEN RAISE EXCEPTION 'V13_VOLUME_REQUIRES_19_16A'; END IF;
END $guard$;

CREATE TEMP TABLE v13_urine_raw_16 ON COMMIT DROP AS
SELECT c.stay_id,o.itemid,o.charttime,o.storetime,o.value::numeric AS value,o.valueuom,
 o.storetime IS NOT NULL AND o.storetime<=c.intime+interval '6 hours' AS known_by_h6,
 lower(replace(coalesce(o.valueuom,''),' ',''))='ml' AS valid_unit,
 coalesce(o.value BETWEEN 0 AND 2000,false) AS valid_value
FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.outputevents o
 ON o.subject_id=c.subject_id AND o.hadm_id=c.hadm_id AND o.stay_id=c.stay_id
WHERE o.itemid IN(226561,226559,226565,226558,226564,226557,226567,226560)
 AND o.charttime BETWEEN c.intime AND c.intime+interval '6 hours';
CREATE TEMP TABLE v13_urine_point_qc_16 ON COMMIT DROP AS
SELECT stay_id,itemid,charttime,count(*) AS source_rows,
 count(DISTINCT value) AS distinct_values,min(value) AS value
FROM pg_temp.v13_urine_raw_16 WHERE known_by_h6 AND valid_unit AND valid_value
GROUP BY stay_id,itemid,charttime;


CREATE TEMP TABLE v13_urine_fused_16 ON COMMIT DROP AS
SELECT stay_id,charttime,avg(value) AS value,count(*) AS source_item_count
FROM pg_temp.v13_urine_point_qc_16 WHERE distinct_values=1 GROUP BY stay_id,charttime;
CREATE TEMP TABLE v13_urine_features_16 ON COMMIT DROP AS
SELECT c.stay_id,sum(f.value) AS urine_output_total_ml,count(f.value) AS urine_output_count,
 (count(f.value)=0)::integer AS urine_output_missing,
 CASE WHEN count(f.value)>0 THEN 'VALUE'
      WHEN EXISTS(SELECT 1 FROM pg_temp.v13_urine_raw_16 r WHERE r.stay_id=c.stay_id)
      THEN 'NO_USABLE_RECORD' ELSE 'NO_RECORD' END AS urine_status
FROM pg_temp.v13_primary_risk_set c LEFT JOIN pg_temp.v13_urine_fused_16 f USING(stay_id)
GROUP BY c.stay_id;
ALTER TABLE pg_temp.v13_urine_features_16 ADD PRIMARY KEY(stay_id);

CREATE TEMP TABLE v13_fluid_raw_16 ON COMMIT DROP AS
SELECT c.stay_id,c.intime,c.intime+interval '6 hours' AS landmark_time,
 i.itemid,i.orderid,i.starttime,i.endtime,i.storetime,i.amount::numeric AS amount,
 lower(replace(coalesce(i.amountuom,''),' ','')) AS amount_unit,
 i.rate::numeric AS rate,lower(replace(coalesce(i.rateuom,''),' ','')) AS rate_unit,
 upper(btrim(coalesce(i.statusdescription,''))) AS status
FROM pg_temp.v13_primary_risk_set c JOIN mimiciv_icu.inputevents i
 ON i.subject_id=c.subject_id AND i.hadm_id=c.hadm_id AND i.stay_id=c.stay_id
WHERE i.itemid IN(220861,220862,220863,220864,220949,220950,220951,220952,220953,220955,
 220956,220963,220964,220965,220966,220967,220968,221000,221002,221014,221017,221208,
 225944,228140,228141,228142)
 AND (i.starttime IS NULL OR (i.starttime<=c.intime+interval '6 hours'
      AND (i.endtime IS NULL OR i.endtime>=c.intime OR i.endtime<i.starttime)));


CREATE TEMP TABLE v13_fluid_row_qc_16 ON COMMIT DROP AS
SELECT r.*,
 CASE
  WHEN status='REWRITTEN' THEN 'EXCLUDED_REWRITTEN'
  WHEN starttime IS NULL OR endtime IS NULL OR endtime<starttime OR orderid IS NULL THEN 'UNKNOWN_TIME_OR_KEY'
  WHEN storetime IS NULL THEN 'UNKNOWN_MISSING_STORETIME'
  WHEN storetime>landmark_time THEN 'UNKNOWN_LATE_STORETIME'
  WHEN amount_unit<>'ml' THEN 'UNKNOWN_AMOUNT_UNIT'
  WHEN starttime>=intime AND endtime<=landmark_time
   THEN CASE WHEN amount>=0 AND amount::text NOT IN('NaN','Infinity','-Infinity')
             THEN 'KNOWN_COMPLETED_AMOUNT' ELSE 'UNKNOWN_COMPLETED_AMOUNT' END
  WHEN rate>=0 AND rate::text NOT IN('NaN','Infinity','-Infinity') AND rate_unit IN('ml/h','ml/hr','ml/hour')
   THEN 'KNOWN_RATE_INTEGRAL'
  ELSE 'UNKNOWN_RATE'
 END AS availability
FROM pg_temp.v13_fluid_raw_16 r;
CREATE TEMP TABLE v13_fluid_values_16 ON COMMIT DROP AS
SELECT r.*,
 CASE WHEN availability='KNOWN_COMPLETED_AMOUNT' THEN amount
      WHEN availability='KNOWN_RATE_INTEGRAL'
       THEN rate*greatest(extract(epoch FROM
            (CASE WHEN endtime<=landmark_time THEN endtime ELSE landmark_time END)
            -greatest(starttime,intime)),0)/3600.0 END AS known_ml
FROM pg_temp.v13_fluid_row_qc_16 r;



CREATE TEMP TABLE v13_fluid_segment_qc_16 ON COMMIT DROP AS
SELECT stay_id,itemid,orderid,greatest(starttime,intime) AS window_start,
 least(endtime,landmark_time) AS window_end,count(*) AS source_rows,
 count(DISTINCT known_ml) AS distinct_values,min(known_ml) AS known_ml
FROM pg_temp.v13_fluid_values_16 WHERE known_ml IS NOT NULL
GROUP BY stay_id,itemid,orderid,greatest(starttime,intime),least(endtime,landmark_time);
CREATE TEMP TABLE v13_fluid_features_16 ON COMMIT DROP AS
WITH row_summary AS (
 SELECT stay_id,count(*) FILTER(WHERE status<>'REWRITTEN') AS candidate_rows,
  count(*) FILTER(WHERE availability LIKE 'UNKNOWN_%') AS unknown_rows,
  sum(amount) FILTER(WHERE availability LIKE 'UNKNOWN_%' AND amount_unit='ml' AND amount>=0
      AND amount::text NOT IN('NaN','Infinity','-Infinity')) AS retrospective_unknown_recorded_amount_ml
 FROM pg_temp.v13_fluid_values_16 GROUP BY stay_id
), segments AS (
 SELECT stay_id,count(*) FILTER(WHERE distinct_values=1) AS known_segments,
  sum(known_ml) FILTER(WHERE distinct_values=1) AS known_ml,
  count(*) FILTER(WHERE distinct_values>1) AS conflict_segments
 FROM pg_temp.v13_fluid_segment_qc_16 GROUP BY stay_id
)
SELECT c.stay_id,
 CASE WHEN coalesce(r.candidate_rows,0)=0 THEN 0::numeric ELSE s.known_ml END AS fluid_input_known_ml,
 CASE WHEN coalesce(r.candidate_rows,0)=0 THEN 'NO_RECORD_EVIDENCE_ZERO'
      WHEN coalesce(s.known_segments,0)=0 THEN 'UNASCERTAINABLE'
      WHEN coalesce(r.unknown_rows,0)>0 OR coalesce(s.conflict_segments,0)>0 THEN 'PARTIAL_KNOWN'
      ELSE 'KNOWN' END AS fluid_status,
 coalesce(r.unknown_rows,0) AS unknown_rows,coalesce(s.conflict_segments,0) AS conflict_segments,
 coalesce(s.known_segments,0) AS known_segments,
 r.retrospective_unknown_recorded_amount_ml
FROM pg_temp.v13_primary_risk_set c LEFT JOIN row_summary r USING(stay_id) LEFT JOIN segments s USING(stay_id);
ALTER TABLE pg_temp.v13_fluid_features_16 ADD PRIMARY KEY(stay_id);


CREATE TEMP TABLE v13_volume_audit_16 ON COMMIT DROP AS
SELECT 'urine'::text AS concept,'RAW_ROWS'::text AS metric,count(*)::bigint AS n FROM pg_temp.v13_urine_raw_16
UNION ALL SELECT 'urine','NOT_KNOWN_BY_H6',count(*) FROM pg_temp.v13_urine_raw_16 WHERE NOT known_by_h6
UNION ALL SELECT 'urine','BAD_UNIT',count(*) FROM pg_temp.v13_urine_raw_16 WHERE NOT valid_unit
UNION ALL SELECT 'urine','INVALID_VALUE',count(*) FROM pg_temp.v13_urine_raw_16 WHERE NOT valid_value
UNION ALL SELECT 'urine','CONFLICT_POINTS',count(*) FROM pg_temp.v13_urine_point_qc_16 WHERE distinct_values>1
UNION ALL SELECT 'urine','EQUAL_REPEAT_ROWS_REMOVED',coalesce(sum(source_rows-1),0)::bigint FROM pg_temp.v13_urine_point_qc_16 WHERE distinct_values=1
UNION ALL SELECT 'fluid',availability,count(*) FROM pg_temp.v13_fluid_values_16 GROUP BY availability
UNION ALL SELECT 'fluid','CONFLICT_SEGMENTS',count(*) FROM pg_temp.v13_fluid_segment_qc_16 WHERE distinct_values>1
UNION ALL SELECT 'fluid','EQUAL_REPEAT_ROWS_REMOVED',coalesce(sum(source_rows-1),0)::bigint FROM pg_temp.v13_fluid_segment_qc_16 WHERE distinct_values=1;
DO $verify$
BEGIN
 IF (SELECT count(*) FROM pg_temp.v13_urine_features_16)<>(SELECT count(*) FROM pg_temp.v13_primary_risk_set)
 OR (SELECT count(*) FROM pg_temp.v13_fluid_features_16)<>(SELECT count(*) FROM pg_temp.v13_primary_risk_set)
 OR EXISTS(SELECT 1 FROM pg_temp.v13_urine_features_16 WHERE urine_output_missing<>(urine_output_total_ml IS NULL)::integer)
 OR EXISTS(SELECT 1 FROM pg_temp.v13_fluid_features_16 WHERE fluid_status='UNASCERTAINABLE' AND fluid_input_known_ml IS NOT NULL)
 THEN RAISE EXCEPTION 'V13_VOLUME_RECONCILIATION'; END IF;
END $verify$;

