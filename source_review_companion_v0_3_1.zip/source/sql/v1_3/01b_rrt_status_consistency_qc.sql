-- Additive, TEMP-only QC after 01_mimic_source_adapter, before 15b.
-- Internal counts are NOT a release-ready aggregate. No clinical status filtering.
-- Source-only distribution does not confer production execution authorization.
DO $guard$
BEGIN
 IF current_user<>'synthetic_owner' OR
    current_setting('periop_aki.v13_adapter_test_mode',true) IS DISTINCT FROM 'SYNTHETIC_SOURCE_ONLY'
 THEN RAISE EXCEPTION 'V13_RRT_STATUS_QC_NOT_PRODUCTION_AUTHORIZED'; END IF;
 IF to_regclass('pg_temp.v13_rrt_source_rows') IS NULL OR
    to_regclass('pg_temp.v13_rrt_derived') IS NULL OR
    to_regclass('pg_temp.v13_stage_ledger') IS NULL
 THEN RAISE EXCEPTION 'V13_RRT_STATUS_QC_REQUIRES_ADAPTER'; END IF;
 IF EXISTS(SELECT 1 FROM pg_temp.v13_stage_ledger) OR
    to_regclass('pg_temp.v13_rrt_status_qc_rows') IS NOT NULL
 THEN RAISE EXCEPTION 'V13_RRT_STATUS_QC_WRONG_STAGE_OR_REPLAY'; END IF;
END $guard$;

-- EXISTS preserves source-row multiplicity (a JOIN to duplicated source_rows
-- would multiply records). No trimming, case-folding, ordering or status priority.
CREATE TEMP TABLE v13_rrt_status_qc_rows ON COMMIT DROP AS
SELECT p.stay_id,p.itemid,p.starttime,p.endtime,p.storetime,p.statusdescription
FROM mimiciv_icu.procedureevents p JOIN pg_temp.v13_stays s
 ON p.subject_id=s.subject_id AND p.hadm_id=s.hadm_id AND p.stay_id=s.stay_id
WHERE EXISTS(SELECT 1 FROM pg_temp.v13_rrt_source_rows r
 WHERE r.stay_id=p.stay_id AND r.itemid=p.itemid
 AND r.starttime IS NOT DISTINCT FROM p.starttime
 AND r.endtime IS NOT DISTINCT FROM p.endtime
 AND r.storetime IS NOT DISTINCT FROM p.storetime);

DO $reconcile$
BEGIN
 IF EXISTS(
  (SELECT stay_id,itemid,starttime,endtime,storetime FROM pg_temp.v13_rrt_status_qc_rows
   EXCEPT ALL SELECT stay_id,itemid,starttime,endtime,storetime FROM pg_temp.v13_rrt_source_rows)
  UNION ALL
  (SELECT stay_id,itemid,starttime,endtime,storetime FROM pg_temp.v13_rrt_source_rows
   EXCEPT ALL SELECT stay_id,itemid,starttime,endtime,storetime FROM pg_temp.v13_rrt_status_qc_rows)
 ) THEN RAISE EXCEPTION 'V13_RRT_STATUS_QC_SOURCE_MULTISET_MISMATCH'; END IF;
END $reconcile$;

CREATE TEMP TABLE v13_rrt_status_signature_qc ON COMMIT DROP AS
SELECT stay_id,itemid,starttime,endtime,count(*) AS raw_rows,
 count(DISTINCT statusdescription) AS known_status_variants,
 count(*) FILTER(WHERE statusdescription IS NULL) AS missing_status_rows,
 -- JSON array encodes NULL separately from any literal string such as '<NULL>'.
 count(DISTINCT jsonb_build_array(statusdescription)) AS raw_status_variants,
 count(DISTINCT jsonb_build_array(statusdescription))>1 AS status_inconsistent,
 count(DISTINCT statusdescription)>1 AS known_status_disagreement,
 bool_or(statusdescription IS NULL) AND bool_or(statusdescription IS NOT NULL) AS missing_and_known_mixed
FROM pg_temp.v13_rrt_status_qc_rows
GROUP BY stay_id,itemid,starttime,endtime;

CREATE TEMP TABLE v13_rrt_status_audit(metric text PRIMARY KEY,n bigint NOT NULL) ON COMMIT DROP;
INSERT INTO pg_temp.v13_rrt_status_audit VALUES
 ('rrt_status_qc_raw_rows',(SELECT count(*) FROM pg_temp.v13_rrt_status_qc_rows)),
 ('rrt_status_qc_signatures',(SELECT count(*) FROM pg_temp.v13_rrt_status_signature_qc)),
 ('rrt_same_signature_status_inconsistent_groups',(SELECT count(*) FROM pg_temp.v13_rrt_status_signature_qc WHERE status_inconsistent)),
 ('rrt_same_signature_known_status_disagreement_groups',(SELECT count(*) FROM pg_temp.v13_rrt_status_signature_qc WHERE known_status_disagreement)),
 ('rrt_same_signature_missing_and_known_status_groups',(SELECT count(*) FROM pg_temp.v13_rrt_status_signature_qc WHERE missing_and_known_mixed)),
 ('rrt_same_signature_inconsistent_raw_rows',(SELECT coalesce(sum(raw_rows),0) FROM pg_temp.v13_rrt_status_signature_qc WHERE status_inconsistent)),
 ('rrt_same_signature_inconsistent_stays',(SELECT count(DISTINCT stay_id) FROM pg_temp.v13_rrt_status_signature_qc WHERE status_inconsistent)),
 ('rrt_all_status_missing_groups',(SELECT count(*) FROM pg_temp.v13_rrt_status_signature_qc WHERE known_status_variants=0));
-- No downstream clinical table references these QC outputs. In particular,
-- v13_rrt_derived, renal flags and the stage ledger remain unchanged.
