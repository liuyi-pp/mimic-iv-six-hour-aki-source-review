# SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
# Derived from an enumerated source snapshot; see README and internal provenance.
# No research data, fitted parameters, individual predictions or credentials are embedded.
# Prespecified algorithm constants are code, not fitted research results.
# This is not the verified manuscript execution version and is not a complete pipeline.

args <- commandArgs(trailingOnly = TRUE)

parse_args <- function(x) {
  out <- list(expected_rows = NULL, expected_events = NULL, input = NULL, output_dir = NULL, seed = 20260903L, bootstrap = 500L,
              min_valid = 475L, self_test = FALSE, worker_id = NULL,
              iteration_start = 1L, iteration_end = 500L, finalize_only = FALSE)
  for (arg in x) {
    if (arg == "--self-test") out$self_test <- TRUE
    else if (arg == "--finalize-only") out$finalize_only <- TRUE
    else if (grepl("^--input=", arg)) out$input <- sub("^--input=", "", arg)
    else if (grepl("^--output-dir=", arg)) out$output_dir <- sub("^--output-dir=", "", arg)
    else if (grepl("^--seed=", arg)) out$seed <- as.integer(sub("^--seed=", "", arg))
    else if (grepl("^--bootstrap=", arg)) out$bootstrap <- as.integer(sub("^--bootstrap=", "", arg))
    else if (grepl("^--min-valid=", arg)) out$min_valid <- as.integer(sub("^--min-valid=", "", arg))
    else if (grepl("^--worker-id=", arg)) out$worker_id <- sub("^--worker-id=", "", arg)
    else if (grepl("^--iteration-start=", arg)) out$iteration_start <- as.integer(sub("^--iteration-start=", "", arg))
    else if (grepl("^--iteration-end=", arg)) out$iteration_end <- as.integer(sub("^--iteration-end=", "", arg))
    else if (grepl("^--expected-rows=", arg)) out$expected_rows <- as.numeric(sub("^--expected-rows=", "", arg))
    else if (grepl("^--expected-events=", arg)) out$expected_events <- as.numeric(sub("^--expected-events=", "", arg))
    else stop("Unknown argument: ", arg)
  }
  out
}

cfg <- parse_args(args)
cfg$worker_mode <- !is.null(cfg$worker_id)
required_packages <- c("data.table", "glmnet", "xgboost", "jsonlite")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages)) stop("Missing R packages: ", paste(missing_packages, collapse = ", "))

clip_prob <- function(p) pmin(pmax(p, 1e-6), 1 - 1e-6)
log_loss <- function(y, p) {
  p <- clip_prob(p)
  -mean(y * log(p) + (1 - y) * log(1 - p))
}
brier_score <- function(y, p) mean((as.numeric(p) - y)^2)

auroc <- function(y, p) {
  y <- as.integer(y)
  n1 <- sum(y == 1L); n0 <- sum(y == 0L)
  if (n1 == 0L || n0 == 0L) return(NA_real_)
  r <- rank(as.numeric(p), ties.method = "average")
  (sum(r[y == 1L]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

average_precision <- function(y, p) {
  y <- as.integer(y)
  positives <- sum(y == 1L)
  if (positives == 0L) return(NA_real_)
  ord <- order(as.numeric(p), decreasing = TRUE, method = "radix")
  ys <- y[ord]
  precision_at_rank <- cumsum(ys) / seq_along(ys)
  sum(precision_at_rank[ys == 1L]) / positives
}

calibration_terms <- function(y, p) {
  lp <- qlogis(clip_prob(p))
  intercept <- tryCatch(
    unname(stats::coef(stats::glm(y ~ 1 + offset(lp), family = stats::binomial()))[[1L]]),
    error = function(e) NA_real_
  )
  slope_fit <- tryCatch(stats::glm(y ~ lp, family = stats::binomial()), error = function(e) NULL)
  slope <- if (is.null(slope_fit)) NA_real_ else unname(stats::coef(slope_fit)[[2L]])
  c(calibration_intercept = intercept, calibration_slope = slope)
}

metric_vector <- function(y, p) {
  c(
    auroc = auroc(y, p),
    auprc = average_precision(y, p),
    brier = brier_score(y, p),
    logloss = log_loss(y, p),
    calibration_terms(y, p)
  )
}

make_stratified_group_folds <- function(group, y, k, seed) {
  group_frame <- unique(data.frame(group = as.character(group), y = as.integer(y), stringsAsFactors = FALSE))
  if (anyDuplicated(group_frame$group)) stop("A subject group has conflicting outcomes")
  set.seed(seed)
  group_frame$fold <- NA_integer_
  for (cls in c(0L, 1L)) {
    idx <- which(group_frame$y == cls)
    idx <- sample(idx, length(idx), replace = FALSE)
    group_frame$fold[idx] <- rep(seq_len(k), length.out = length(idx))
  }
  fold_map <- setNames(group_frame$fold, group_frame$group)
  unname(fold_map[as.character(group)])
}

continuous_columns <- c(
  "age_years", "creatinine_mean_mg_dl", "hemoglobin_mean_g_dl",
  "urine_output_total_ml", "fluid_input_total_ml", "map_mean_mm_hg"
)
binary_columns <- c(
  "female", "prior_ckd", "urgency_urgent", "urgency_emergency",
  "creatinine_missing", "hemoglobin_missing", "urine_output_missing",
  "rbc_exposure", "vasopressor_exposure", "mechanical_ventilation"
)
predictor_columns <- c(
  "age_years", "female", "prior_ckd", "urgency_urgent", "urgency_emergency",
  "creatinine_mean_mg_dl", "creatinine_missing",
  "hemoglobin_mean_g_dl", "hemoglobin_missing",
  "urine_output_total_ml", "urine_output_missing", "fluid_input_total_ml",
  "rbc_exposure", "vasopressor_exposure", "map_mean_mm_hg", "mechanical_ventilation"
)

fit_preprocessor <- function(d) {
  medians <- vapply(continuous_columns, function(nm) {
    x <- as.numeric(d[[nm]])
    value <- stats::median(x[is.finite(x)], na.rm = TRUE)
    if (!is.finite(value)) stop("No finite training value for ", nm)
    value
  }, numeric(1))
  imputed <- as.data.frame(d[, continuous_columns, drop = FALSE])
  for (nm in continuous_columns) {
    x <- as.numeric(imputed[[nm]])
    x[!is.finite(x)] <- medians[[nm]]
    imputed[[nm]] <- x
  }
  centers <- vapply(imputed, mean, numeric(1))
  scales <- vapply(imputed, stats::sd, numeric(1))
  scales[!is.finite(scales) | scales == 0] <- 1
  list(medians = medians, centers = centers, scales = scales)
}

apply_preprocessor <- function(d, prep, standardize = FALSE) {
  x <- matrix(0, nrow = nrow(d), ncol = length(predictor_columns),
              dimnames = list(NULL, predictor_columns))
  for (nm in continuous_columns) {
    value <- as.numeric(d[[nm]])
    value[!is.finite(value)] <- prep$medians[[nm]]
    if (standardize) value <- (value - prep$centers[[nm]]) / prep$scales[[nm]]
    x[, nm] <- value
  }
  for (nm in binary_columns) {
    value <- as.numeric(d[[nm]])
    if (any(!is.finite(value))) stop("Invalid binary value in ", nm)
    if (any(!value %in% c(0, 1))) stop("Non-binary value in ", nm)
    x[, nm] <- value
  }
  x
}

lasso_lambda_grid <- 10^seq(0, -5, length.out = 100L)

tune_lasso <- function(d, folds) {
  sum_loss <- rep(0, length(lasso_lambda_grid))
  n_loss <- rep(0L, length(lasso_lambda_grid))
  for (fold in sort(unique(folds))) {
    train <- folds != fold; valid <- !train
    prep <- fit_preprocessor(d[train, , drop = FALSE])
    x_train <- apply_preprocessor(d[train, , drop = FALSE], prep, standardize = TRUE)
    x_valid <- apply_preprocessor(d[valid, , drop = FALSE], prep, standardize = TRUE)
    fit <- glmnet::glmnet(x_train, d$incident_aki[train], family = "binomial", alpha = 1,
                          lambda = lasso_lambda_grid, standardize = FALSE, intercept = TRUE)
    pred <- clip_prob(stats::predict(fit, newx = x_valid, s = lasso_lambda_grid, type = "response"))
    y <- d$incident_aki[valid]
    for (j in seq_along(lasso_lambda_grid)) {
      sum_loss[j] <- sum_loss[j] - 2 * sum(y * log(pred[, j]) + (1 - y) * log(1 - pred[, j]))
      n_loss[j] <- n_loss[j] + length(y)
    }
  }
  mean_deviance <- sum_loss / n_loss
  min_value <- min(mean_deviance)
  candidates <- which(mean_deviance <= min_value + 1e-12)
  selected <- candidates[[1L]]
  list(
    lambda = lasso_lambda_grid[[selected]],
    mean_deviance = mean_deviance[[selected]],
    path = data.frame(lambda = lasso_lambda_grid, mean_binomial_deviance = mean_deviance,
                      selected = seq_along(lasso_lambda_grid) == selected)
  )
}

fit_lasso <- function(d, lambda) {
  prep <- fit_preprocessor(d)
  x <- apply_preprocessor(d, prep, standardize = TRUE)
  fit <- glmnet::glmnet(x, d$incident_aki, family = "binomial", alpha = 1,
                        lambda = lambda, standardize = FALSE, intercept = TRUE)
  list(fit = fit, prep = prep, lambda = lambda)
}

predict_lasso <- function(object, d) {
  x <- apply_preprocessor(d, object$prep, standardize = TRUE)
  as.numeric(stats::predict(object$fit, newx = x, s = object$lambda, type = "response"))
}

xgb_grid <- expand.grid(
  max_depth = c(2L, 3L, 4L),
  eta = c(0.01, 0.03, 0.10),
  subsample = c(0.8, 1.0),
  colsample_bytree = c(0.8, 1.0),
  min_child_weight = c(1, 5),
  stringsAsFactors = FALSE
)
xgb_round_grid <- c(100L, 300L, 500L, 1000L)

tune_xgb <- function(d, folds, seed, self_test = FALSE) {
  base_grid <- xgb_grid
  rounds <- xgb_round_grid
  if (self_test) {
    base_grid <- base_grid[1:2, , drop = FALSE]
    rounds <- c(5L, 10L)
  }
  candidates <- merge(base_grid, data.frame(nrounds = rounds), by = NULL)
  candidates$loss_sum <- 0
  candidates$brier_sum <- 0
  candidates$n <- 0L
  for (fold in sort(unique(folds))) {
    train <- folds != fold; valid <- !train
    prep <- fit_preprocessor(d[train, , drop = FALSE])
    x_train <- apply_preprocessor(d[train, , drop = FALSE], prep, standardize = FALSE)
    x_valid <- apply_preprocessor(d[valid, , drop = FALSE], prep, standardize = FALSE)
    dm_train <- xgboost::xgb.DMatrix(x_train, label = d$incident_aki[train])
    dm_valid <- xgboost::xgb.DMatrix(x_valid)
    for (g in seq_len(nrow(base_grid))) {
      pars <- base_grid[g, ]
      fit <- xgboost::xgb.train(
        params = list(
          objective = "binary:logistic", eval_metric = "logloss",
          max_depth = as.integer(pars$max_depth), eta = pars$eta,
          subsample = pars$subsample, colsample_bytree = pars$colsample_bytree,
          min_child_weight = pars$min_child_weight, lambda = 1, gamma = 0,
          nthread = 1, seed = as.integer(seed + fold)
        ), data = dm_train, nrounds = max(rounds), verbose = 0
      )
      for (nr in rounds) {
        p <- clip_prob(stats::predict(fit, dm_valid, iterationrange = c(1L, nr)))
        row_index <- which(
          candidates$max_depth == pars$max_depth & candidates$eta == pars$eta &
          candidates$subsample == pars$subsample &
          candidates$colsample_bytree == pars$colsample_bytree &
          candidates$min_child_weight == pars$min_child_weight & candidates$nrounds == nr
        )
        y <- d$incident_aki[valid]
        candidates$loss_sum[row_index] <- candidates$loss_sum[row_index] -
          sum(y * log(p) + (1 - y) * log(1 - p))
        candidates$brier_sum[row_index] <- candidates$brier_sum[row_index] + sum((p - y)^2)
        candidates$n[row_index] <- candidates$n[row_index] + length(y)
      }
    }
  }
  candidates$logloss <- candidates$loss_sum / candidates$n
  candidates$brier <- candidates$brier_sum / candidates$n
  min_loss <- min(candidates$logloss)
  eligible <- candidates[candidates$logloss <= min_loss + 1e-6, , drop = FALSE]
  eligible <- eligible[order(eligible$brier, eligible$max_depth, eligible$nrounds,
                             eligible$eta, eligible$subsample, eligible$colsample_bytree,
                             eligible$min_child_weight), , drop = FALSE]
  list(
    selected = eligible[1L, c("max_depth", "eta", "subsample", "colsample_bytree",
                              "min_child_weight", "nrounds", "logloss", "brier"), drop = FALSE],
    grid = candidates[, c("max_depth", "eta", "subsample", "colsample_bytree",
                          "min_child_weight", "nrounds", "logloss", "brier")]
  )
}

fit_xgb <- function(d, selected, seed) {
  prep <- fit_preprocessor(d)
  x <- apply_preprocessor(d, prep, standardize = FALSE)
  dm <- xgboost::xgb.DMatrix(x, label = d$incident_aki)
  fit <- xgboost::xgb.train(
    params = list(
      objective = "binary:logistic", eval_metric = "logloss",
      max_depth = as.integer(selected$max_depth), eta = selected$eta,
      subsample = selected$subsample, colsample_bytree = selected$colsample_bytree,
      min_child_weight = selected$min_child_weight, lambda = 1, gamma = 0,
      nthread = 1, seed = as.integer(seed)
    ), data = dm, nrounds = as.integer(selected$nrounds), verbose = 0
  )
  list(fit = fit, prep = prep, selected = selected)
}

predict_xgb <- function(object, d) {
  x <- apply_preprocessor(d, object$prep, standardize = FALSE)
  as.numeric(stats::predict(object$fit, xgboost::xgb.DMatrix(x)))
}

metric_row <- function(iteration, model, status, train_metrics = NULL, test_metrics = NULL,
                       error_code = "", tuning = "") {
  names6 <- c("auroc", "auprc", "brier", "logloss", "calibration_intercept", "calibration_slope")
  if (is.null(train_metrics)) train_metrics <- setNames(rep(NA_real_, length(names6)), names6)
  if (is.null(test_metrics)) test_metrics <- setNames(rep(NA_real_, length(names6)), names6)
  values <- list(iteration = iteration, model = model, status = status,
                 error_code = error_code, tuning = tuning)
  for (nm in names6) {
    values[[paste0("train_", nm)]] <- unname(train_metrics[[nm]])
    values[[paste0("test_", nm)]] <- unname(test_metrics[[nm]])
    values[[paste0("optimism_", nm)]] <- unname(train_metrics[[nm]] - test_metrics[[nm]])
  }
  as.data.frame(values, stringsAsFactors = FALSE)
}

append_csv <- function(d, path) {
  data.table::fwrite(d, path, append = file.exists(path), col.names = !file.exists(path), na = "")
}

calibration_deciles <- function(y, p, model) {
  breaks <- unique(stats::quantile(p, probs = seq(0, 1, 0.1), na.rm = TRUE, type = 8))
  if (length(breaks) < 3L) return(data.frame())
  group <- cut(p, breaks = breaks, include.lowest = TRUE, labels = FALSE)
  out <- aggregate(cbind(predicted = p, observed = y) ~ group, FUN = mean)
  counts <- aggregate(y ~ group, FUN = length)
  events <- aggregate(y ~ group, FUN = sum)
  out$n <- counts$y; out$events <- events$y; out$model <- model
  out[, c("model", "group", "n", "events", "predicted", "observed")]
}

decision_curve <- function(y, p, model) {
  n <- length(y)
  thresholds <- seq(0.05, 0.50, 0.01)
  data.frame(
    model = model,
    threshold = thresholds,
    net_benefit_model = vapply(thresholds, function(t) {
      pred <- p >= t
      tp <- sum(pred & y == 1L); fp <- sum(pred & y == 0L)
      tp / n - fp / n * t / (1 - t)
    }, numeric(1)),
    net_benefit_all = mean(y) - (1 - mean(y)) * thresholds / (1 - thresholds),
    net_benefit_none = 0
  )
}

write_json <- function(x, path) jsonlite::write_json(x, path, pretty = TRUE, auto_unbox = TRUE, na = "null")

if (cfg$self_test) {
  set.seed(cfg$seed)
  n <- 180L
  d <- data.frame(
    subject_id = seq_len(n), incident_aki = stats::rbinom(n, 1, 0.42),
    age_years = stats::rnorm(n, 65, 12), female = stats::rbinom(n, 1, 0.45),
    prior_ckd = stats::rbinom(n, 1, 0.20), urgency_urgent = stats::rbinom(n, 1, 0.25),
    urgency_emergency = stats::rbinom(n, 1, 0.25), creatinine_mean_mg_dl = stats::rlnorm(n, 0, 0.3),
    creatinine_missing = stats::rbinom(n, 1, 0.08), hemoglobin_mean_g_dl = stats::rnorm(n, 11, 2),
    hemoglobin_missing = stats::rbinom(n, 1, 0.05), urine_output_total_ml = stats::rgamma(n, 2, 0.004),
    urine_output_missing = stats::rbinom(n, 1, 0.10), fluid_input_total_ml = stats::rgamma(n, 2, 0.002),
    rbc_exposure = stats::rbinom(n, 1, 0.10), vasopressor_exposure = stats::rbinom(n, 1, 0.15),
    map_mean_mm_hg = stats::rnorm(n, 75, 10), mechanical_ventilation = stats::rbinom(n, 1, 0.20)
  )
  d$creatinine_mean_mg_dl[d$creatinine_missing == 1] <- NA
  d$hemoglobin_mean_g_dl[d$hemoglobin_missing == 1] <- NA
  d$urine_output_total_ml[d$urine_output_missing == 1] <- NA
  d$map_mean_mm_hg[sample.int(n, 8)] <- NA
  folds <- make_stratified_group_folds(d$subject_id, d$incident_aki, 5L, cfg$seed + 1000L)
  lt <- tune_lasso(d, folds); lf <- fit_lasso(d, lt$lambda); lp <- predict_lasso(lf, d)
  xt <- tune_xgb(d, folds, cfg$seed + 1000L, self_test = TRUE)
  xf <- fit_xgb(d, xt$selected, cfg$seed); xp <- predict_xgb(xf, d)
  stopifnot(length(lp) == n, length(xp) == n, all(is.finite(lp)), all(is.finite(xp)))
  cat("SELF_TEST_PASS\n")
  quit(save = "no", status = 0L)
}

if (is.null(cfg$input) || is.null(cfg$output_dir)) stop("--input and --output-dir are required")
if (!file.exists(cfg$input)) stop("Model matrix does not exist: ", cfg$input)
if (!dir.exists(cfg$output_dir)) stop("Output directory does not exist: ", cfg$output_dir)
if (cfg$bootstrap != 500L || cfg$min_valid != 475L) stop("Formal execution requires bootstrap=500 and min-valid=475")
if (cfg$iteration_start < 1L || cfg$iteration_end > cfg$bootstrap || cfg$iteration_start > cfg$iteration_end) {
  stop("Invalid bootstrap iteration range")
}

d <- data.table::fread(cfg$input, na.strings = c("", "NA"), data.table = FALSE)
required_columns <- c("subject_id", "hadm_id", "stay_id", "incident_aki", predictor_columns, "row_sha256")
if (!all(required_columns %in% names(d))) stop("Model matrix is missing required columns")
if (is.null(cfg$expected_rows) || is.null(cfg$expected_events) ||
    length(cfg$expected_rows) != 1L || length(cfg$expected_events) != 1L ||
    !is.finite(cfg$expected_rows) || !is.finite(cfg$expected_events) ||
    cfg$expected_rows < 1 || cfg$expected_events < 0 ||
    cfg$expected_rows != floor(cfg$expected_rows) ||
    cfg$expected_events != floor(cfg$expected_events) || cfg$expected_events > cfg$expected_rows) {
  stop("HOLD: explicit independently verified local expected rows/events are required; no defaults are supplied.")
}
if (nrow(d) != cfg$expected_rows || sum(d$incident_aki) != cfg$expected_events) {
  stop("Local expected rows/events contract mismatch.")
}
if (anyDuplicated(d$subject_id) || anyDuplicated(d$stay_id)) stop("Subject or stay is not unique")
if (any(!d$incident_aki %in% c(0L, 1L))) stop("Invalid outcome")

bootstrap_path <- file.path(cfg$output_dir, "bootstrap_model_metrics_v1_0.csv")
tuning_path <- file.path(cfg$output_dir, "bootstrap_tuning_choices_v1_0.csv")
lasso_path_path <- file.path(cfg$output_dir, "bootstrap_lasso_lambda_paths_v1_0.csv")
xgb_grid_path <- file.path(cfg$output_dir, "bootstrap_xgboost_grid_scores_v1_0.csv")
failure_path <- file.path(cfg$output_dir, "bootstrap_failures_v1_0.csv")
progress_path <- file.path(cfg$output_dir, "bootstrap_progress_v1_0.json")

if (!cfg$worker_mode && !cfg$finalize_only) {
cat("Fitting apparent models with frozen tuning rules.\n")
apparent_folds <- make_stratified_group_folds(d$subject_id, d$incident_aki, 5L, cfg$seed + 1000L)
lasso_tuned <- tune_lasso(d, apparent_folds)
lasso_fit <- fit_lasso(d, lasso_tuned$lambda)
lasso_prob <- predict_lasso(lasso_fit, d)
xgb_tuned <- tune_xgb(d, apparent_folds, cfg$seed + 1000L)
xgb_fit <- fit_xgb(d, xgb_tuned$selected, cfg$seed)
xgb_prob <- predict_xgb(xgb_fit, d)

apparent <- rbind(
  data.frame(model = "LASSO", t(metric_vector(d$incident_aki, lasso_prob)), stringsAsFactors = FALSE),
  data.frame(model = "XGBOOST", t(metric_vector(d$incident_aki, xgb_prob)), stringsAsFactors = FALSE)
)
data.table::fwrite(apparent, file.path(cfg$output_dir, "apparent_model_metrics_v1_0.csv"), na = "")
data.table::fwrite(rbind(calibration_deciles(d$incident_aki, lasso_prob, "LASSO"),
                        calibration_deciles(d$incident_aki, xgb_prob, "XGBOOST")),
                   file.path(cfg$output_dir, "apparent_calibration_deciles_v1_0.csv"), na = "")
data.table::fwrite(rbind(decision_curve(d$incident_aki, lasso_prob, "LASSO"),
                        decision_curve(d$incident_aki, xgb_prob, "XGBOOST")),
                   file.path(cfg$output_dir, "apparent_decision_curve_v1_0.csv"), na = "")
data.table::fwrite(data.frame(subject_id = d$subject_id, hadm_id = d$hadm_id, stay_id = d$stay_id,
                              incident_aki = d$incident_aki, lasso_probability = lasso_prob,
                              xgboost_probability = xgb_prob),
                   file.path(cfg$output_dir, "apparent_patient_predictions_v1_0.csv"), na = "")
saveRDS(list(lasso = lasso_fit, xgboost = xgb_fit), file.path(cfg$output_dir, "apparent_fitted_models_v1_0.rds"))

apparent_tuning <- rbind(
  data.frame(iteration = 0L, model = "LASSO", tuning = paste0("lambda=", format(lasso_tuned$lambda, scientific = TRUE)), stringsAsFactors = FALSE),
  data.frame(iteration = 0L, model = "XGBOOST", tuning = paste(names(xgb_tuned$selected), unlist(xgb_tuned$selected), sep = "=", collapse = ";"), stringsAsFactors = FALSE)
)
if (!file.exists(tuning_path)) data.table::fwrite(apparent_tuning, tuning_path)
if (!file.exists(lasso_path_path)) data.table::fwrite(cbind(iteration = 0L, lasso_tuned$path), lasso_path_path)
if (!file.exists(xgb_grid_path)) data.table::fwrite(cbind(iteration = 0L, xgb_tuned$grid), xgb_grid_path)
}

if (!cfg$finalize_only) {
existing_boot <- data.frame()
if (file.exists(bootstrap_path)) {
  existing_boot <- data.table::fread(bootstrap_path, data.table = FALSE)
}

for (b in seq.int(cfg$iteration_start, cfg$iteration_end)) {
  existing_models <- if (nrow(existing_boot)) unique(existing_boot$model[existing_boot$iteration == b]) else character()
  if (all(c("LASSO", "XGBOOST") %in% existing_models)) next
  outer_seed <- cfg$seed + b
  set.seed(outer_seed)
  sampled_subjects <- sample(d$subject_id, size = nrow(d), replace = TRUE)
  index <- match(sampled_subjects, d$subject_id)
  boot <- d[index, , drop = FALSE]
  if (length(unique(boot$incident_aki)) < 2L) {
    fail <- data.frame(iteration = b, model = "BOTH", error_code = "SINGLE_OUTCOME_CLASS", error_message = "Bootstrap sample has one outcome class", stringsAsFactors = FALSE)
    append_csv(fail, failure_path)
    if (!"LASSO" %in% existing_models) append_csv(metric_row(b, "LASSO", "FAILED", error_code = "SINGLE_OUTCOME_CLASS"), bootstrap_path)
    if (!"XGBOOST" %in% existing_models) append_csv(metric_row(b, "XGBOOST", "FAILED", error_code = "SINGLE_OUTCOME_CLASS"), bootstrap_path)
    existing_boot <- data.table::fread(bootstrap_path, data.table = FALSE)
    next
  }
  folds <- make_stratified_group_folds(boot$subject_id, boot$incident_aki, 5L, cfg$seed + 1000L * b)

  lasso_result <- if ("LASSO" %in% existing_models) NULL else tryCatch({
    tuned <- tune_lasso(boot, folds)
    fit <- fit_lasso(boot, tuned$lambda)
    p_train <- predict_lasso(fit, boot); p_test <- predict_lasso(fit, d)
    tuning <- paste0("lambda=", format(tuned$lambda, scientific = TRUE))
    list(row = metric_row(b, "LASSO", "PASS", metric_vector(boot$incident_aki, p_train),
                          metric_vector(d$incident_aki, p_test), tuning = tuning), tuning = tuning,
         path = tuned$path)
  }, error = function(e) list(error = conditionMessage(e)))
  if (!is.null(lasso_result) && !is.null(lasso_result$error)) {
    append_csv(data.frame(iteration = b, model = "LASSO", error_code = "LASSO_ERROR", error_message = lasso_result$error), failure_path)
    append_csv(metric_row(b, "LASSO", "FAILED", error_code = "LASSO_ERROR"), bootstrap_path)
  } else if (!is.null(lasso_result)) {
    append_csv(lasso_result$row, bootstrap_path)
    append_csv(data.frame(iteration = b, model = "LASSO", tuning = lasso_result$tuning), tuning_path)
    append_csv(cbind(iteration = b, lasso_result$path), lasso_path_path)
  }

  xgb_result <- if ("XGBOOST" %in% existing_models) NULL else tryCatch({
    tuned <- tune_xgb(boot, folds, cfg$seed + 1000L * b)
    fit <- fit_xgb(boot, tuned$selected, outer_seed)
    p_train <- predict_xgb(fit, boot); p_test <- predict_xgb(fit, d)
    tuning <- paste(names(tuned$selected), unlist(tuned$selected), sep = "=", collapse = ";")
    list(row = metric_row(b, "XGBOOST", "PASS", metric_vector(boot$incident_aki, p_train),
                          metric_vector(d$incident_aki, p_test), tuning = tuning), tuning = tuning,
         grid = tuned$grid)
  }, error = function(e) list(error = conditionMessage(e)))
  if (!is.null(xgb_result) && !is.null(xgb_result$error)) {
    append_csv(data.frame(iteration = b, model = "XGBOOST", error_code = "XGBOOST_ERROR", error_message = xgb_result$error), failure_path)
    append_csv(metric_row(b, "XGBOOST", "FAILED", error_code = "XGBOOST_ERROR"), bootstrap_path)
  } else if (!is.null(xgb_result)) {
    append_csv(xgb_result$row, bootstrap_path)
    append_csv(data.frame(iteration = b, model = "XGBOOST", tuning = xgb_result$tuning), tuning_path)
    append_csv(cbind(iteration = b, xgb_result$grid), xgb_grid_path)
  }

  current <- data.table::fread(bootstrap_path, data.table = FALSE)
  existing_boot <- current
  progress <- list(
    run_status = "IN_PROGRESS", completed_iterations = length(unique(current$iteration[current$iteration > 0])),
    bootstrap_expected = cfg$bootstrap,
    valid_lasso = sum(current$model == "LASSO" & current$status == "PASS"),
    valid_xgboost = sum(current$model == "XGBOOST" & current$status == "PASS"),
    updated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
  )
  write_json(progress, progress_path)
  cat(sprintf("Bootstrap %d/%d complete; valid LASSO=%d, XGBOOST=%d\n", b, cfg$bootstrap,
              progress$valid_lasso, progress$valid_xgboost))
}
}

if (cfg$worker_mode) {
  worker_metrics <- data.table::fread(bootstrap_path, data.table = FALSE)
  worker_gate <- list(
    worker_id = cfg$worker_id,
    iteration_start = cfg$iteration_start,
    iteration_end = cfg$iteration_end,
    assigned_iterations = cfg$iteration_end - cfg$iteration_start + 1L,
    complete_iterations = sum(table(worker_metrics$iteration) >= 2L),
    valid_lasso = sum(worker_metrics$model == "LASSO" & worker_metrics$status == "PASS"),
    valid_xgboost = sum(worker_metrics$model == "XGBOOST" & worker_metrics$status == "PASS"),
    failed_rows = sum(worker_metrics$status != "PASS"),
    completed_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
  )
  write_json(worker_gate, file.path(cfg$output_dir, "worker_completion_v1_0.json"))
  cat("PARALLEL_WORKER_COMPLETE ", cfg$worker_id, " ", cfg$iteration_start, "-", cfg$iteration_end, "\n", sep = "")
  quit(save = "no", status = 0L)
}

boot_metrics <- data.table::fread(bootstrap_path, data.table = FALSE)
if (!exists("apparent")) {
  apparent_path <- file.path(cfg$output_dir, "apparent_model_metrics_v1_0.csv")
  if (!file.exists(apparent_path)) stop("Apparent model metrics are required for finalization")
  apparent <- data.table::fread(apparent_path, data.table = FALSE)
}
metric_names <- c("auroc", "auprc", "brier", "logloss", "calibration_intercept", "calibration_slope")
summary_rows <- list()
for (model in c("LASSO", "XGBOOST")) {
  bm <- boot_metrics[boot_metrics$model == model & boot_metrics$status == "PASS", , drop = FALSE]
  valid <- nrow(bm)
  if (valid < cfg$min_valid) stop(model, " has only ", valid, " valid bootstrap repetitions; required ", cfg$min_valid)
  app <- apparent[apparent$model == model, , drop = FALSE]
  for (metric in metric_names) {
    optimism <- bm[[paste0("optimism_", metric)]]
    corrected <- as.numeric(app[[metric]]) - mean(optimism, na.rm = TRUE)
    corrected_replicates <- as.numeric(app[[metric]]) - optimism
    summary_rows[[length(summary_rows) + 1L]] <- data.frame(
      model = model, metric = metric, apparent = as.numeric(app[[metric]]),
      bootstrap_train_mean = mean(bm[[paste0("train_", metric)]], na.rm = TRUE),
      original_test_mean = mean(bm[[paste0("test_", metric)]], na.rm = TRUE),
      optimism_mean = mean(optimism, na.rm = TRUE), optimism_corrected = corrected,
      percentile_ci_low = unname(stats::quantile(corrected_replicates, 0.025, na.rm = TRUE, type = 8)),
      percentile_ci_high = unname(stats::quantile(corrected_replicates, 0.975, na.rm = TRUE, type = 8)),
      valid_repetitions = valid, stringsAsFactors = FALSE
    )
  }
}
performance_summary <- do.call(rbind, summary_rows)
data.table::fwrite(performance_summary, file.path(cfg$output_dir, "optimism_corrected_performance_v1_0.csv"), na = "")

gate <- list(
  final_gate = "PASS_RESTRICTED_MIMIC_MODEL_DEVELOPMENT_INTERNAL_VALIDATION_V1_0",
  next_gate = "HARD_STOP_MODEL_RESULTS_HUMAN_REVIEW_NOT_COMPLETED",
  eicu_gate = "HARD_STOP_EICU_EXTERNAL_VALIDATION_FEASIBILITY_NOT_PASSED",
  model_rows = nrow(d), events = sum(d$incident_aki), parameter_df = 16L,
  bootstrap_expected = cfg$bootstrap,
  valid_lasso = sum(boot_metrics$model == "LASSO" & boot_metrics$status == "PASS"),
  valid_xgboost = sum(boot_metrics$model == "XGBOOST" & boot_metrics$status == "PASS"),
  public_patient_rows_exported = 0L, eicu_access_runs = 0L,
  completed_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
)
write_json(gate, file.path(cfg$output_dir, "restricted_model_run_gate_v1_0.json"))
write_json(list(run_status = "COMPLETE", completed_iterations = cfg$bootstrap,
                valid_lasso = gate$valid_lasso, valid_xgboost = gate$valid_xgboost,
                completed_at = gate$completed_at), progress_path)
writeLines(capture.output(sessionInfo()), file.path(cfg$output_dir, "r_session_info_v1_0.txt"), useBytes = TRUE)
cat("Restricted MIMIC model development and internal validation completed.\n")
cat("Final gate:", gate$final_gate, "\n")
