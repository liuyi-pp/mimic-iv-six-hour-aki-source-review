# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.



v13_model_development_contract <- function() list(
  seed=20260903L,iterations=500L,min_valid=450L,max_attempts=3L,folds=5L,
  max_failed_slots=50L,consecutive_failed_stop=25L,
  lambda=10^seq(0,-5,length.out=100L),
  xgb=expand.grid(max_depth=c(2L,3L,4L),eta=c(.01,.03,.10),subsample=c(.8,1),
      colsample_bytree=c(.8,1),min_child_weight=c(1,5)),rounds=c(100L,300L,500L,1000L),
  fold_unit='PATIENT_GROUPED',preprocessing='CURRENT_TRAINING_PARTITION',
  paired_models=c('LASSO','XGBoost'),metric_policy='ALL_SIX_PRIMARY_METRICS_FINITE_BOTH_MODELS')

.v20_seeded <- function(seed,fun) {
  kind<-RNGkind();had<-exists('.Random.seed',envir=.GlobalEnv,inherits=FALSE)
  if(had)old<-get('.Random.seed',envir=.GlobalEnv)
  on.exit({do.call(RNGkind,as.list(kind));if(had)assign('.Random.seed',old,envir=.GlobalEnv)
            else if(exists('.Random.seed',envir=.GlobalEnv,inherits=FALSE))rm('.Random.seed',envir=.GlobalEnv)},add=TRUE)
  RNGkind("L'Ecuyer-CMRG");set.seed(seed);fun()
}
v13_bootstrap_attempt_plan <- function(iterations=500L) {
  .br_assert(length(iterations)==1L&&.br_whole(iterations,1L)&&iterations<=500L,'V20_PLAN_COUNTS')
  
  seeds<-.v20_seeded(20260903L,function()sample.int(.Machine$integer.max-1L,4500L,replace=FALSE))
  d<-data.frame(iteration=rep(seq_len(500L),each=3L),attempt=rep(1:3,500L),
                resample_seed=seeds[1:1500],lasso_tuning_seed=seeds[1501:3000],xgboost_tuning_seed=seeds[3001:4500])
  d[d$iteration<=iterations,,drop=FALSE]
}
.v20_group_folds <- function(y,count,seed) {
  fold<-rep(NA_integer_,length(y))
  .v20_seeded(seed,function(){
    for(cls in 0:1) {
      ii<-which(y==cls&count>0)
      if(length(ii)<5L)stop('V20_INSUFFICIENT_CLASS_GROUPS',call.=FALSE)
      ii<-ii[sample.int(length(ii))];fold[ii]<-rep(1:5,length.out=length(ii))
    };fold
  })
}
.v20_failure_boundary <- function(failed,consecutive) {
  if(consecutive>=25L)'CONSECUTIVE_25_EXHAUSTED_SLOTS'
  else if(failed>50L)'OVER_50_EXHAUSTED_SLOTS' else NULL
}

v13_run_synthetic_pair_execution <- function(reference,directory,fit_pair,run_id,
                                            iterations=3L,min_valid=2L,
                                            data_class=NULL,backend_class='TEST_DOUBLE_NOT_FITTED') {
  .br_runtime()
  .br_assert(identical(data_class,'INVENTED_MECHANISM_FIXTURE_ONLY'),'V20_PRODUCTION_NOT_AUTHORIZED')
  .br_assert(length(backend_class)==1L&&backend_class %in% c('TEST_DOUBLE_NOT_FITTED','ACTUAL_SYNTHETIC_FULL_GRID'),
             'V20_BACKEND_CLASS')
  reference<-.br_keys(reference,'Stage20 reference')
  .br_assert(all(startsWith(reference$subject_id,'SYN_'))&&all(startsWith(reference$stay_id,'SYN_')),
             'V20_SYNTHETIC_KEYS_REQUIRED')
  .br_assert(is.numeric(reference$incident_aki)&&!anyNA(reference$incident_aki)&&
      all(reference$incident_aki %in% 0:1)&&length(unique(reference$incident_aki))==2L,'V20_RESOLVED_REFERENCE_REQUIRED')
  .br_assert(is.function(fit_pair)&&dir.exists(directory)&&length(list.files(directory,all.files=TRUE,no..=TRUE))==0L,
             'V20_NEW_EMPTY_SYNTHETIC_DIRECTORY_REQUIRED')
  .br_assert(.br_whole(min_valid,1L)&&length(min_valid)==1L&&min_valid<=iterations,'V20_MIN_VALID')
  plan<-v13_bootstrap_attempt_plan(iterations);contract<-v13_model_development_contract()
  .br_atomic_new_rds(list(data_class=data_class,contract=contract,plan=plan,
                        backend=backend_class),file.path(directory,'synthetic_execution_contract.rds'))
  matrix_hash<-.br_sha(reference);code_hash<-unname(tools::sha256sum('source/src/analysis/v1_3/bootstrap_pair_execution.R'))
  ledger<-data.frame(iteration=integer(),attempt=integer(),status=character(),error_code=character())
  failed<-0L;consecutive<-0L;identity<-NULL;stop_reason<-NULL
  metrics<-list();n<-nrow(reference)
  for(i in seq_len(iterations)) {
    succeeded<-FALSE
    for(a in 1:3) {
      row<-plan[plan$iteration==i&plan$attempt==a,,drop=FALSE]
      sample_index<-.v20_seeded(row$resample_seed,function()sample.int(n,n,replace=TRUE))
      counts<-tabulate(sample_index,nbins=n)
      candidate<-tryCatch({
        folds<-.v20_group_folds(reference$incident_aki,counts,row$lasso_tuning_seed)
        
        
        fitted<-fit_pair(training=reference[sample_index,,drop=FALSE],reference=reference,
                         folds=folds[sample_index],seeds=row,contract=contract)
        .br_assert(is.list(fitted)&&identical(names(fitted),c('LASSO','XGBoost')),'V20_PAIRED_FIT_SCHEMA')
        train_metrics<-test_metrics<-list();preds<-list()
        for(model in names(fitted)) {
          f<-fitted[[model]]
          .br_assert(identical(f$backend_class,backend_class),'V20_BACKEND_CLASS_MISMATCH')
          .br_assert(identical(f$training_contract_sha256,.br_sha(contract)),'V20_TUNING_CONTRACT_CHANGED')
          .br_assert(identical(as.character(f$sample_subject_ids),as.character(reference$subject_id[sample_index])),
                     'V20_PAIRED_SAMPLE_CHANGED')
          .br_assert(!is.null(f$model)&&!is.null(f$preprocessing),'V20_MODEL_PROVENANCE_MISSING')
          pred<-.br_align(f$predictions,reference,paste(model,'predictions'))
          .br_assert(is.numeric(pred$probability)&&all(is.finite(pred$probability)&pred$probability>=0&pred$probability<=1),
                     'V20_INVALID_PREDICTION')
          train_metrics[[model]]<-v13_fractional_metrics(reference$incident_aki,pred$probability,counts)
          test_metrics[[model]]<-v13_fractional_metrics(reference$incident_aki,pred$probability,rep(1,n))
          .br_assert(train_metrics[[model]]$all_metrics_finite&&test_metrics[[model]]$all_metrics_finite,
                     'V20_NONFINITE_PRIMARY_METRIC')
          preds[[model]]<-pred
        }
        meta<-list(run_id=run_id,analysis_variant='SYNTHETIC_EXECUTION_MECHANISM_ONLY',iteration=i,attempt=a,
                   expected_iterations=as.integer(iterations),expected_sample_size=n,resample_seed=row$resample_seed,
                   lasso_tuning_seed=row$lasso_tuning_seed,xgboost_tuning_seed=row$xgboost_tuning_seed,
                   analysis_matrix_sha256=matrix_hash,code_sha256=code_hash,
                   lasso_model_sha256=.br_sha(fitted$LASSO$model),xgboost_model_sha256=.br_sha(fitted$XGBoost$model),
                   lasso_preprocessing_sha256=.br_sha(fitted$LASSO$preprocessing),
                   xgboost_preprocessing_sha256=.br_sha(fitted$XGBoost$preprocessing),lasso_status='PASS',xgboost_status='PASS')
        record<-build_bootstrap_prediction_record(reference,preds$LASSO,preds$XGBoost,
          reference$subject_id[sample_index],reference$subject_id[sample_index],meta)
        list(record=record,train=train_metrics,original=test_metrics)
      },error=function(e){
        message<-conditionMessage(e)
        code<-if(grepl('^V20_[A-Z_]+$',message))message else 'V20_PAIRED_FIT_OR_METRIC_FAILURE'
        list(error_code=code)
      })
      passed<-is.null(candidate$error_code)
      if(passed) {
        
        .br_write_record(candidate$record,directory)
        identity<-.br_identity(candidate$record)
        .br_atomic_new_rds(list(train=candidate$train,original=candidate$original),
                          file.path(directory,sprintf('synthetic_metrics_%06d.rds',i)))
        metrics[[as.character(i)]]<-list(train=candidate$train,original=candidate$original)
      }
      entry<-data.frame(iteration=as.integer(i),attempt=as.integer(a),status=if(passed)'SUCCESS' else 'FAILED',
                        error_code=if(passed)'' else candidate$error_code)
      .br_atomic_new_rds(list(entry=entry,seeds=row,sample_sha256=.br_sha(reference$subject_id[sample_index])),
                        file.path(directory,sprintf('attempt_%06d_%02d.rds',i,a)))
      ledger<-rbind(ledger,entry)
      if(passed){succeeded<-TRUE;break}
    }
    if(succeeded)consecutive<-0L else {failed<-failed+1L;consecutive<-consecutive+1L}
    stop_reason<-.v20_failure_boundary(failed,consecutive)
    if(!is.null(stop_reason))break
  }
  .br_atomic_new_rds(ledger,file.path(directory,'attempt_ledger.rds'))
  verification<-NULL
  if(is.null(stop_reason)) {
    if(is.null(identity))stop_reason<-'NO_VALID_PAIRED_ITERATIONS'
    else verification<-.v13_check_retained_with_attempts(directory,identity,ledger,min_valid)
  }
  status<-if(is.null(stop_reason))'SYNTHETIC_PAIR_EXECUTION_RECONCILED' else 'STOPPED_AT_SIGNED_FAILURE_BOUNDARY'
  answer<-list(status=status,stop_reason=stop_reason,ledger=ledger,identity=identity,
               verification=verification,metrics=metrics,
               actual_outcome_models_fitted=if(backend_class=='TEST_DOUBLE_NOT_FITTED')FALSE else if(!is.null(identity))TRUE else NA,
               backend_class=backend_class,production_ready=FALSE)
  .br_atomic_new_rds(answer,file.path(directory,'synthetic_execution_result.rds'))
  answer
}
