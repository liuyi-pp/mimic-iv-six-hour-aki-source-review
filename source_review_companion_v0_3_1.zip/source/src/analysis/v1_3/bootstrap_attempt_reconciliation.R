# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.



v13_validate_attempt_ledger <- function(ledger,expected_iterations=500L,min_valid=450L) {
  fail<-function(msg)stop(paste0('BOOTSTRAP_LEDGER: ',msg),call.=FALSE)
  if(length(expected_iterations)!=1L || !is.finite(expected_iterations) || expected_iterations<1 || expected_iterations!=floor(expected_iterations) ||
     length(min_valid)!=1L || !is.finite(min_valid) || min_valid<1 || min_valid>expected_iterations || min_valid!=floor(min_valid)) fail('invalid counts')
  if(!is.data.frame(ledger) || !identical(names(ledger),c('iteration','attempt','status','error_code')) || !nrow(ledger)) fail('schema')
  for(nm in c('iteration','attempt')) if(!is.numeric(ledger[[nm]]) || anyNA(ledger[[nm]]) || any(!is.finite(ledger[[nm]])) || any(ledger[[nm]]!=floor(ledger[[nm]]))) fail('integer keys')
  if(any(!ledger$iteration %in% seq_len(expected_iterations)) || any(!ledger$attempt %in% 1:3) ||
     anyDuplicated(ledger[c('iteration','attempt')])) fail('duplicate or out-of-range attempts')
  if(!is.character(ledger$status) || anyNA(ledger$status) || any(!ledger$status %in% c('SUCCESS','FAILED')) ||
     !is.character(ledger$error_code) || anyNA(ledger$error_code)) fail('status/error fields')
  if(any(ledger$error_code[ledger$status=='SUCCESS']!='') ||
     any(!grepl('^[A-Z][A-Z0-9_]+$',ledger$error_code[ledger$status=='FAILED']))) fail('error-code provenance')
  ledger<-ledger[order(ledger$iteration,ledger$attempt),,drop=FALSE];row.names(ledger)<-NULL
  success<-integer();failed<-integer();successful_attempts<-integer()
  for(i in seq_len(expected_iterations)) {
    r<-ledger[ledger$iteration==i,,drop=FALSE]
    if(!nrow(r) || !identical(as.integer(r$attempt),seq_len(nrow(r)))) fail('missing iteration or retry gap')
    s<-which(r$status=='SUCCESS')
    if(length(s)>1L || (length(s) && s!=nrow(r))) fail('retry after success')
    if(length(s)) {success<-c(success,i);successful_attempts<-c(successful_attempts,nrow(r))}
    else {if(nrow(r)!=3L)fail('failed slot has not exhausted attempts');failed<-c(failed,i)}
  }
  if(length(success)<min_valid)fail('insufficient valid slots')
  runs<-rle(seq_len(expected_iterations) %in% failed)
  if(length(failed)>50L || any(runs$values & runs$lengths>=25L))fail('signed stopping boundary reached')
  list(ledger=ledger,successful_iterations=success,successful_attempts=successful_attempts,
       failed_iterations=failed,failed_attempts=sum(ledger$status=='FAILED'))
}

.v13_check_retained_with_attempts <- function(directory,expected_identity,ledger,min_valid) {
  checked<-v13_validate_attempt_ledger(ledger,expected_identity$expected_iterations,min_valid)
  manifest_path<-file.path(directory,'bootstrap_prediction_run_manifest.rds')
  .br_assert(file.exists(manifest_path),'Retention run manifest is missing')
  .br_assert(identical(readRDS(manifest_path),expected_identity),'Unexpected retention run identity')
  expected<-sprintf('bootstrap_predictions_iteration_%06d.rds',checked$successful_iterations)
  actual<-list.files(directory,pattern='^bootstrap_predictions_iteration_[0-9]+[.]rds$',ignore.case=TRUE)
  .br_assert(setequal(expected,actual),'Successful ledger/file coverage mismatch; failed slots cannot masquerade as predictions')
  for(j in seq_along(expected)) {
    record<-.br_read_record(file.path(directory,expected[j]))
    .br_assert(identical(.br_identity(record),expected_identity) &&
        record$body$metadata$iteration==checked$successful_iterations[j] &&
        record$body$metadata$attempt==checked$successful_attempts[j],
        'Retained prediction iteration/attempt does not match ledger')
  }
  list(status='SUCCESSFUL_PREDICTIONS_AND_FAILED_ATTEMPTS_RECONCILED',
       successful_iterations=checked$successful_iterations,failed_iterations=checked$failed_iterations,
       failed_attempts=checked$failed_attempts,ledger=checked$ledger,patient_level_egress_allowed=FALSE)
}

check_restricted_v13_predictions_with_attempts <- function(run_directory,expected_identity,ledger) {
  .br_assert(identical(as.integer(expected_identity$expected_iterations),500L),'v1.3 production requires 500 assigned slots')
  directory<-.br_production_directory(run_directory)
  .v13_check_retained_with_attempts(directory,expected_identity,ledger,min_valid=450L)
}
