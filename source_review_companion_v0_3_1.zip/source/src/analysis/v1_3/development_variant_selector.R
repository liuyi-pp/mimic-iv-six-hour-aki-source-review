# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.


v13_select_development_variant <- function(risk,contract,variant) {
  allowed<-c('PRIMARY','COMPLETE_CASE','RELAXED_OBSERVATION')
  if(length(variant)!=1L||is.na(variant)||!variant %in% allowed)
    stop('V13_DEVELOPMENT_VARIANT',call.=FALSE)
  prepared<-v13_prepare_observation_input(risk,contract)
  if(!'stay_id' %in% names(risk)||!is.character(risk$stay_id)||anyNA(risk$stay_id)||
     any(!nzchar(risk$stay_id))||anyDuplicated(risk$stay_id))
    stop('V13_DEVELOPMENT_STAY_KEYS',call.=FALSE)
  keep<-switch(variant,PRIMARY=risk$resolved==1,
               COMPLETE_CASE=prepared$complete_case,
               RELAXED_OBSERVATION=prepared$relaxed_resolved==1)
  y<-if(variant=='RELAXED_OBSERVATION')prepared$relaxed_outcome else risk$incident_aki
  reference<-risk[keep,c('subject_id','stay_id','incident_aki',contract),drop=FALSE]
  reference$incident_aki<-y[keep]
  rownames(reference)<-NULL
  if(!nrow(reference)||anyNA(reference$incident_aki)||
     !all(reference$incident_aki %in% 0:1)) stop('V13_DEVELOPMENT_RESOLVED_ONLY',call.=FALSE)
  list(variant=variant,reference=reference,
       selection=data.frame(subject_id=risk$subject_id,stay_id=risk$stay_id,
                            included=keep,primary_resolved=risk$resolved,
                            variant_outcome=y),
       denominators=c(input_risk=nrow(risk),selected=sum(keep),excluded=sum(!keep),
                      positive=sum(y[keep]==1),negative=sum(y[keep]==0)),
       contract=contract,imputation_performed=FALSE,outcome_model_fitted=FALSE)
}
