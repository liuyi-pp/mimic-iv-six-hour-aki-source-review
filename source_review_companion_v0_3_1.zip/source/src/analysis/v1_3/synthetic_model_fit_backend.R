# SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
# Derived from an enumerated source snapshot; see README and internal provenance.
# No research data, fitted parameters, individual predictions or credentials are embedded.
# Prespecified algorithm constants are code, not fitted research results.
# This is not the verified manuscript execution version and is not a complete pipeline.



v13_load_fitting_primitives <- function() {
  path<-Sys.getenv("CANDIDATE_PRIMITIVES_PATH",unset="source/src/analysis/run_restricted_mimic_model_development_v1_0.R")
  functions<-c('clip_prob','fit_preprocessor','apply_preprocessor','tune_lasso','fit_lasso','predict_lasso',
               'tune_xgb','fit_xgb','predict_xgb')
  constants<-c('continuous_columns','binary_columns','predictor_columns','lasso_lambda_grid','xgb_grid','xgb_round_grid')
  env<-new.env(parent=globalenv());loaded<-character()
  for(x in parse(path,keep.source=FALSE)) {
    if(!is.call(x)||!identical(x[[1]],as.name('<-'))||!is.symbol(x[[2]]))next
    nm<-as.character(x[[2]])
    if(nm %in% functions) {
      stopifnot(is.call(x[[3]])&&identical(x[[3]][[1]],as.name('function')))
      eval(x,env);loaded<-c(loaded,nm)
    } else if(nm %in% constants){eval(x,env);loaded<-c(loaded,nm)}
  }
  stopifnot(setequal(loaded,c(functions,constants)))
  contract<-v13_model_development_contract()
  stopifnot(identical(env$lasso_lambda_grid,contract$lambda),nrow(env$xgb_grid)==72L,
            identical(env$xgb_round_grid,contract$rounds),all(env$xgb_grid==contract$xgb))
  env
}

v13_fit_synthetic_model_pair <- function(training,reference,folds,seeds,contract) {
  stopifnot(all(startsWith(as.character(training$subject_id),'SYN_')),
            all(startsWith(as.character(reference$subject_id),'SYN_')),
            identical(contract,v13_model_development_contract()))
  env<-v13_load_fitting_primitives()
  for(d in list(training,reference)) {
    stopifnot(all(env$predictor_columns %in% names(d)),is.numeric(d$incident_aki),
              !anyNA(d$incident_aki),all(d$incident_aki %in% 0:1))
    for(nm in env$predictor_columns)stopifnot(is.numeric(d[[nm]]))
    for(nm in env$binary_columns)stopifnot(!anyNA(d[[nm]]),all(d[[nm]] %in% 0:1))
    stopifnot(all(is.na(d$map_mean_mm_hg)|d$map_mean_mm_hg>0))
  }
  stopifnot(length(folds)==nrow(training),setequal(unique(folds),1:5),
    all(tapply(folds,training$subject_id,function(v)length(unique(v)))==1L))
  for(f in 1:5)stopifnot(length(unique(training$incident_aki[folds==f]))==2L,
                        length(unique(training$incident_aki[folds!=f]))==2L)
  
  lt<-env$tune_lasso(training,folds);lf<-env$fit_lasso(training,lt$lambda)
  lp<-env$predict_lasso(lf,reference)
  
  xt<-env$tune_xgb(training,folds,seeds$xgboost_tuning_seed,self_test=FALSE)
  xf<-env$fit_xgb(training,xt$selected,seeds$xgboost_tuning_seed)
  xp<-env$predict_xgb(xf,reference)
  stopifnot(nrow(lt$path)==100L,nrow(xt$grid)==288L)
  wrap<-function(fit,p,prep,tuning)list(predictions=data.frame(reference[c('subject_id','stay_id')],probability=p),
    sample_subject_ids=training$subject_id,training_contract_sha256=.br_sha(contract),model=fit,
    preprocessing=prep,tuning=tuning,backend_class='ACTUAL_SYNTHETIC_FULL_GRID')
  list(LASSO=wrap(lf,lp,lf$prep,lt),XGBoost=wrap(xf,xp,xf$prep,xt))
}
