# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.




v13_location_shifted_ci <- function(apparent, train, original,
                                   expected_iterations = 500L, min_valid = 450L) {
  models <- c('LASSO','XGBoost')
  plain <- function(x) (is.double(x) || is.integer(x)) && !is.object(x)
  if (!plain(train) || !plain(original) || length(dim(train)) != 3L ||
      !identical(dim(train), dim(original)) || !identical(dimnames(train), dimnames(original)))
    stop('CI_ARRAY: matched numeric iteration/model/metric arrays required', call. = FALSE)
  if (length(expected_iterations) != 1L || !is.finite(expected_iterations) ||
      expected_iterations < 2 || expected_iterations != floor(expected_iterations) ||
      length(min_valid) != 1L || !is.finite(min_valid) || min_valid < 2 ||
      min_valid != floor(min_valid) || min_valid > expected_iterations)
    stop('CI_COUNTS: invalid iteration thresholds', call. = FALSE)
  dn <- dimnames(train)
  if (dim(train)[1] != expected_iterations || dim(train)[2] != 2L || dim(train)[3] < 1L ||
      length(dn) != 3L || is.null(dn[[1]]) || anyNA(dn[[1]]) ||
      any(!nzchar(dn[[1]])) || anyDuplicated(dn[[1]]) ||
      !identical(dn[[2]], models) || is.null(dn[[3]]) || anyNA(dn[[3]]) ||
      any(!nzchar(dn[[3]])) || anyDuplicated(dn[[3]]))
    stop('CI_KEYS: all assigned unique iterations, two named models and named metrics required', call. = FALSE)
  if (!plain(apparent) || !is.matrix(apparent) ||
      !identical(dim(apparent), c(2L, dim(train)[3])) ||
      !identical(rownames(apparent), models) || !identical(colnames(apparent), dn[[3]]) ||
      any(!is.finite(apparent)))
    stop('CI_APPARENT: finite named 2-by-metric matrix required', call. = FALSE)
  valid <- apply(is.finite(train) & is.finite(original), 1L, all)
  B <- sum(valid)
  if (B < min_valid) stop('CI_INSUFFICIENT_VALID: shared paired metric set below threshold', call. = FALSE)
  q <- function(x) unname(quantile(x, c(.025,.975), type = 8))
  model_rows <- list(); paired_rows <- list()
  for (k in seq_len(dim(train)[3])) {
    t <- matrix(train[valid,,k], ncol = 2L)
    v <- matrix(original[valid,,k], ncol = 2L)
    optimism <- t-v; delta <- colMeans(optimism)
    for (j in 1:2) {
      interval <- q(t[,j])-delta[j]
      diagnostic <- q(v[,j])
      model_rows[[length(model_rows)+1L]] <- data.frame(metric=dn[[3]][k],model=models[j],
        apparent=apparent[j,k],optimism=delta[j],corrected=apparent[j,k]-delta[j],
        lower=interval[1],upper=interval[2],optimism_sd=sd(optimism[,j]),
        optimism_mcse=sd(optimism[,j])/sqrt(B),
        original_sample_diagnostic_lower=diagnostic[1],original_sample_diagnostic_upper=diagnostic[2])
    }
    shift <- delta[1]-delta[2]; interval <- q(t[,1]-t[,2])-shift
    paired_rows[[k]] <- data.frame(metric=dn[[3]][k],direction='LASSO-XGBoost',
      corrected_difference=apparent[1,k]-apparent[2,k]-shift,lower=interval[1],upper=interval[2])
  }
  list(model=do.call(rbind,model_rows),paired=do.call(rbind,paired_rows),
       valid_iterations=dn[[1]][valid],excluded_iterations=dn[[1]][!valid],valid_count=B,
       method='location-shifted approximate percentile interval',quantile_type=8L,
       full_optimism_uncertainty_propagated=FALSE,
       diagnostic_is_second_corrected_ci=FALSE,intervals_clipped=FALSE)
}
