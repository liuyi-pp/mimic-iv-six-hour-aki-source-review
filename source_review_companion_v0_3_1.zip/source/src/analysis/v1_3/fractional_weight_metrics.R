# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.


v13_fractional_metrics <- function(y, probability, weight, calibration = TRUE) {
  plain <- function(x) is.numeric(x) && !is.object(x) && is.null(dim(x))
  if (!plain(y) || !plain(probability) || !plain(weight) || !length(y) ||
      length(y)!=length(probability) || length(y)!=length(weight) ||
      anyNA(y) || any(!y %in% c(0,1)) || any(!is.finite(probability)) ||
      any(probability<0 | probability>1) || any(!is.finite(weight)) || any(weight<0))
    stop('WEIGHTED_METRIC_INPUT: finite binary outcomes, probabilities and nonnegative weights required',call.=FALSE)
  use <- weight>0
  if (!any(use)) stop('WEIGHTED_METRIC_ZERO_WEIGHT',call.=FALSE)
  y <- y[use]; p <- probability[use]; w <- weight[use]/max(weight[use])
  pos <- sum(w[y==1]); neg <- sum(w[y==0]); total <- sum(w)
  if(pos<=0 || neg<=0) stop('WEIGHTED_METRIC_SINGLE_CLASS',call.=FALSE)
  o <- order(p); p0 <- p[o]; y0 <- y[o]; w0 <- w[o]
  group <- cumsum(c(TRUE,diff(p0)!=0))
  wp <- as.numeric(rowsum(w0*y0,group,reorder=FALSE))
  wn <- as.numeric(rowsum(w0*(1-y0),group,reorder=FALSE))
  auc <- sum(wp*(cumsum(wn)-wn+.5*wn))/(pos*neg)
  rp <- rev(wp); rn <- rev(wn)
  ap <- sum(rp/pos*cumsum(rp)/cumsum(rp+rn))
  loss <- numeric(length(y)); loss[y==1] <- -log(p[y==1]); loss[y==0] <- -log1p(-p[y==0])
  values <- c(auroc=auc,average_precision=ap,brier=sum(w*(y-p)^2)/total,
              logloss=sum(w*loss)/total,calibration_intercept=NA_real_,calibration_slope=NA_real_)
  status <- 'NOT_REQUESTED'; notes <- character()
  if(isTRUE(calibration)) {
    if(any(p<=0 | p>=1)) status <- 'UNDEFINED_BOUNDARY_PROBABILITY'
    else {
      lp <- qlogis(p); d <- data.frame(y=y,lp=lp,w=w)
      safe_glm <- function(formula) tryCatch(withCallingHandlers(
        glm(formula,data=d,weights=w,family=binomial(),na.action=na.fail,
            control=glm.control(maxit=100)),
        warning=function(e){notes <<- c(notes,conditionMessage(e)); invokeRestart('muffleWarning')}),error=function(e) e)
      intercept <- safe_glm(y~1+offset(lp))
      slope <- if(length(unique(lp))>1L) safe_glm(y~lp) else NULL
      valid <- function(f) inherits(f,'glm') && isTRUE(f$converged) && !isTRUE(f$boundary) && all(is.finite(coef(f)))
      if(valid(intercept)) values['calibration_intercept'] <- unname(coef(intercept)[1])
      if(valid(slope) && !any(grepl('fitted probabilities numerically 0 or 1',notes,fixed=TRUE)))
        values['calibration_slope'] <- unname(coef(slope)['lp'])
      status <- if(all(is.finite(values[c('calibration_intercept','calibration_slope')]))) 'PASS' else 'UNDEFINED_OR_FAILED_FIT'
    }
  }
  list(metrics=values,calibration_status=status,calibration_warnings=unique(notes),
       zero_weight_rows=sum(!use),all_metrics_finite=all(is.finite(values)),
       clipped=FALSE,average_precision_definition='common thresholds; all exact ties enter together')
}
