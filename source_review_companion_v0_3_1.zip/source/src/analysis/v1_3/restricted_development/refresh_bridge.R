# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.


.pr25_check <- function(ok,code) if(!isTRUE(ok)) stop(code,call.=FALSE)
.pr25_text <- function(x) is.character(x)&&length(x)==1L&&!is.na(x)&&nzchar(x)
.pr25_hash <- function(path) unname(tools::sha256sum(path))
.pr25_modules <- c('ipw_observation_model.R','observation_sql_bridge.R','development_variant_selector.R',
 'bootstrap_prediction_retention.R','fractional_weight_metrics.R','bootstrap_pair_execution.R',
 'location_shifted_ci.R','synthetic_resumable_development.R','synthetic_model_fit_backend.R',
 'restricted_development/fit_backend.R','restricted_development/engine.R')
.pr25_contract <- strsplit(paste('age_years female prior_ckd urgency_urgent urgency_emergency',
 'creatinine_mean_mg_dl creatinine_missing hemoglobin_mean_g_dl hemoglobin_missing',
 'urine_output_total_ml urine_output_missing fluid_input_total_ml rbc_exposure',
 'vasopressor_exposure map_mean_mm_hg mechanical_ventilation'),' ',fixed=TRUE)[[1]]

v13_primary_refresh_capture <- function(lines,data_class) {
 .pr25_check(.pr25_text(data_class)&&data_class %in% c('RESTRICTED_PATIENT_DERIVED',
  'INVENTED_SQL_FIXTURE_ONLY'),'REFRESH_CAPTURE_CLASS')
 .pr25_check(is.character(lines)&&!anyNA(lines),'REFRESH_CAPTURE_LINES')
 lines<-lines[nzchar(trimws(lines))]
 .pr25_check(length(lines)==3L,'REFRESH_CAPTURE_COMPLETENESS')
 parts<-lapply(lines,function(x)jsonlite::fromJSON(x,simplifyVector=FALSE))
 payload<-parts[[1]];complete<-parts[[2]];rollback<-parts[[3]]
 .pr25_check(identical(sort(names(payload)),sort(c('data_class','stages','branch','risk','contract',
  'source_limitations','snapshot')))&&!anyDuplicated(names(payload)),'REFRESH_CAPTURE_SCHEMA')
 .pr25_check(identical(payload$data_class,data_class)&&identical(payload$branch$profile,'PRIMARY')&&
  identical(payload$branch$input_class,data_class)&&identical(payload$branch$primary_analysis,TRUE)&&
  identical(payload$branch$combined_sensitivities,FALSE)&&identical(payload$branch$outcome_imputation,FALSE)&&
  identical(unlist(payload$stages,use.names=FALSE),c('15b','19','16','17'))&&
  identical(unlist(payload$contract,use.names=FALSE),.pr25_contract),'REFRESH_PRIMARY_CONTRACT')
 .pr25_check(is.list(payload$snapshot)&&length(payload$snapshot)>0L,'REFRESH_SNAPSHOT_REQUIRED')
 expected<-list(status='COMPLETE_PRIMARY_REFRESH_CAPTURE_NOT_MODEL_RESULT',snapshot=payload$snapshot,
  source_reads_role_enforced=TRUE,transaction_read_only='off',formal_500_started=FALSE,
  aggregate_release_authorized=FALSE)
 .pr25_check(identical(sort(names(complete)),sort(names(expected)))&&
  all(vapply(names(expected),function(k)identical(complete[[k]],expected[[k]]),logical(1))),
  'REFRESH_CAPTURE_COMPLETION')
 expected<-list(status='CAPTURE_ROLLBACK_VERIFIED',temporary_context_removed=TRUE,temporary_ledger_removed=TRUE)
 .pr25_check(identical(sort(names(rollback)),sort(names(expected)))&&
  all(vapply(names(expected),function(k)identical(rollback[[k]],expected[[k]]),logical(1))),
  'REFRESH_CAPTURE_ROLLBACK')
 parsed<-jsonlite::fromJSON(lines[1]);risk<-parsed$risk
 .pr25_check(is.data.frame(risk)&&nrow(risk)>0L&&!anyDuplicated(names(risk)),'REFRESH_RISK_SCHEMA')
 for(key in c('subject_id','stay_id')) {
  .pr25_check(is.numeric(risk[[key]])&&!anyNA(risk[[key]])&&
   all(is.finite(risk[[key]])&risk[[key]]==floor(risk[[key]])&risk[[key]]>0&risk[[key]]<2^53),
   'REFRESH_KEY_PRECISION')
  risk[[key]]<-as.character(risk[[key]])
 }
 converted<-character()
 for(nm in c(.pr25_contract,'incident_aki','relaxed_incident_aki')) {
  if(is.logical(risk[[nm]])&&all(is.na(risk[[nm]]))) {
   risk[[nm]]<-as.numeric(risk[[nm]]);converted<-c(converted,nm)
  }
 }
 prepared<-v13_prepare_observation_input(risk,.pr25_contract)
 .pr25_check(!any(risk$urgency_urgent+risk$urgency_emergency>1),'REFRESH_URGENCY_CONFLICT')
 selected<-v13_select_development_variant(risk,.pr25_contract,'PRIMARY')
 list(payload=parsed,risk=risk,prepared=prepared,selected=selected,contract=.pr25_contract,
  converted=converted)
}

v13_primary_refresh_nonfit_summary <- function(capture) {
 ref<-capture$selected$reference;contract<-capture$contract
 predictors<-lapply(contract,function(nm) {
  valid<-is.finite(ref[[nm]])
  list(name=nm,n=nrow(ref),missing=sum(!valid),distinct_nonmissing=length(unique(ref[[nm]][valid])))
 })
 classes<-c(negative=sum(ref$incident_aki==0),positive=sum(ref$incident_aki==1))
 variant<-list(variant='PRIMARY',denominators=as.list(capture$selected$denominators),
  outcome_classes=as.list(classes),fivefold_minimum_class_groups_met=all(classes>=5),
  all_missing_predictor_present=any(vapply(predictors,function(x)x$missing==x$n,logical(1))),
  constant_predictors=contract[vapply(predictors,function(x)x$distinct_nonmissing==1L,logical(1))],
  predictors=predictors,imputation_performed=FALSE,model_fitted=FALSE)
 list(profile='PRIMARY',observation_schema_passed=TRUE,
  denominators=as.list(capture$prepared$denominators),all_missing_json_type_normalization=capture$converted,
  source_limitations=capture$payload$source_limitations,variants=list(PRIMARY=variant),
  observation_indicator_has_both_classes=length(unique(capture$risk$resolved))==2L)
}

v13_primary_refresh_scope <- function(m,mode) {
 .pr25_check(mode %in% c('model','nonfit')&&length(mode)==1L,'REFRESH_ENTRY_MODE')
 kind<-if(mode=='model')'V13_PRIMARY_REFRESH_STAGE20_EXECUTION_MANIFEST' else 'V13_PRIMARY_REFRESH_ZERO_FIT_INPUT_QC'
 .pr25_check(identical(m$kind,kind)&&identical(m$data_class,'RESTRICTED_PATIENT_DERIVED')&&
  identical(m$analysis,'PRIMARY__PRIMARY')&&identical(unlist(m$profiles,use.names=FALSE),'PRIMARY')&&
  identical(m$aggregate_release_authorized,FALSE),'REFRESH_MANIFEST_SCOPE')
 .pr25_check(if(mode=='model')identical(m$model_execution_authorized,TRUE) else
  identical(m$model_fitting_authorized,FALSE)&&
   (is.null(m$model_execution_authorized)||identical(m$model_execution_authorized,FALSE)),
  'REFRESH_FITTING_AUTHORITY')
 .pr25_check(identical(unlist(m$modules,use.names=FALSE),.pr25_modules),'REFRESH_MODULE_SET')
 for(field in c('code_sha256','evidence_sha256')) {
  x<-m[[field]]
  .pr25_check(is.list(x)&&length(x)>0L&&!is.null(names(x))&&!anyDuplicated(names(x))&&
   all(nzchar(names(x)))&&all(vapply(x,function(h).pr25_text(h)&&grepl('^[0-9a-f]{64}$',h),logical(1))),
   'REFRESH_HASH_INVENTORY')
 }
 for(path_field in c('capture_path','capture_receipt_path')) {
  path<-m[[path_field]]
  .pr25_check(.pr25_text(path)&&path %in% names(m$evidence_sha256),'REFRESH_UNBOUND_CAPTURE')
 }
 .pr25_check(identical(m$evidence_sha256[[m$capture_path]],m$capture_sha256)&&
  identical(m$evidence_sha256[[m$capture_receipt_path]],m$capture_receipt_sha256),'REFRESH_CAPTURE_BINDING')
 if(mode=='model')for(field in c('authorization_path','qc_disposition_path','nonfit_report_path','prior_qc_path'))
  .pr25_check(.pr25_text(m[[field]])&&m[[field]] %in% names(m$evidence_sha256),'REFRESH_UNBOUND_AUTHORITY')
 invisible(TRUE)
}

v13_primary_refresh_verify_files <- function(m) {
 for(inventory in c('code_sha256','evidence_sha256'))
  for(path in names(m[[inventory]]))
   .pr25_check(identical(.pr25_hash(path),m[[inventory]][[path]]),'REFRESH_FILE_HASH')
 invisible(TRUE)
}

v13_primary_refresh_validate_nonfit <- function(qc,capture_sha) {
 .pr25_check(identical(qc$status,'COMPLETED_RESTRICTED_PRIMARY_REFRESH_ZERO_FIT_INPUT_QC_NOT_MODEL_CLEARANCE')&&
  identical(qc$capture_sha256,capture_sha)&&identical(qc$data_class,'RESTRICTED_PATIENT_DERIVED')&&
  identical(qc$aggregate_release_authorized,FALSE)&&identical(qc$formal500_started,FALSE)&&
  identical(qc$source_data_changed,FALSE)&&identical(qc$original_rows_preserved,TRUE)&&
  is.numeric(qc$model_fit_calls)&&qc$model_fit_calls==0&&is.numeric(qc$ps_fit_calls)&&qc$ps_fit_calls==0&&
  length(qc$profiles)==1L&&identical(qc$profiles[[1]]$profile,'PRIMARY')&&
  identical(names(qc$profiles[[1]]$variants),'PRIMARY'),'REFRESH_NONFIT_EVIDENCE')
 v<-qc$profiles[[1]]$variants$PRIMARY
 .pr25_check(identical(v$fivefold_minimum_class_groups_met,TRUE)&&
  identical(v$all_missing_predictor_present,FALSE)&&identical(v$imputation_performed,FALSE)&&
  identical(v$model_fitted,FALSE),'REFRESH_NONFIT_NECESSARY_CONDITIONS')
 invisible(TRUE)
}

v13_primary_refresh_authority <- function(doc,m) {
 .pr25_check(identical(doc$schema,'V13_PRIMARY_REFRESH_SCOPE_DISPOSITION_V1')&&
  identical(doc$decision,'AUTHORIZED_PRIMARY_REFRESH_AFTER_PREFLIGHT')&&
  identical(doc$authority_kind,'EXPLICIT_USER_CHAT_A_PLUS_B')&&
  identical(doc$authority_record_sha256,m$evidence_sha256[[m$authorization_path]])&&
  identical(doc$fresh_capture_sha256,m$capture_sha256)&&
  identical(doc$prior_qc_sha256,m$evidence_sha256[[m$prior_qc_path]])&&
  identical(doc$nonfit_report_sha256,m$evidence_sha256[[m$nonfit_report_path]])&&
  identical(doc$profile,'PRIMARY')&&identical(doc$analysis,'PRIMARY__PRIMARY')&&
  identical(doc$model_execution_authorized,TRUE)&&identical(doc$old_human_signature_reused,FALSE)&&
  identical(doc$ipw_chain_authorized,FALSE)&&
  identical(doc$clinical_qc_clearance_claimed,FALSE)&&
  identical(doc$existing_unverified_limitations_preserved,TRUE)&&
  identical(doc$existing_suppression_preserved,TRUE)&&identical(doc$aggregate_release_authorized,FALSE),
  'REFRESH_CONDITIONAL_AUTHORITY')
 invisible(TRUE)
}

v13_primary_refresh_engine_scope_marker <- function(doc,m) {
 v13_primary_refresh_authority(doc,m)
 
 
 
 
 
 'CLEARED_FOR_SPECIFIED_MODEL_SCOPE'
}
