# SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
# Derived from an enumerated source snapshot; see README and internal provenance.
# No research data, fitted parameters, individual predictions or credentials are embedded.
# Prespecified algorithm constants are code, not fitted research results.
# This is not the verified manuscript execution version and is not a complete pipeline.



v13_restricted_fit_pair <- function(training,reference,folds,seeds,contract) {
  .br_assert(identical(contract,v13_model_development_contract()),'PROD_CONTRACT')
  env<-v13_load_fitting_primitives() 
  for(d in list(training,reference)) {
    .br_assert(all(env$predictor_columns %in% names(d))&&
      is.numeric(d$incident_aki)&&!anyNA(d$incident_aki)&&all(d$incident_aki %in% 0:1),'PROD_FIT_SCHEMA')
    for(nm in env$predictor_columns).br_assert(is.numeric(d[[nm]]),'PROD_FIT_NUMERIC')
    for(nm in env$binary_columns).br_assert(!anyNA(d[[nm]])&&all(d[[nm]] %in% 0:1),'PROD_FIT_BINARY')
    .br_assert(all(is.na(d$map_mean_mm_hg)|d$map_mean_mm_hg>0),'PROD_FIT_MAP')
  }
  .br_assert(length(folds)==nrow(training)&&setequal(unique(folds),1:5)&&
    all(tapply(folds,training$subject_id,function(x)length(unique(x)))==1L),'PROD_PATIENT_FOLDS')
  for(f in 1:5).br_assert(length(unique(training$incident_aki[folds==f]))==2L&&
    length(unique(training$incident_aki[folds!=f]))==2L,'PROD_FOLD_CLASSES')
  
  lt<-env$tune_lasso(training,folds);lf<-env$fit_lasso(training,lt$lambda)
  lp<-env$predict_lasso(lf,reference)
  xt<-env$tune_xgb(training,folds,seeds$xgboost_tuning_seed,self_test=FALSE)
  xf<-env$fit_xgb(training,xt$selected,seeds$xgboost_tuning_seed)
  xp<-env$predict_xgb(xf,reference)
  .br_assert(nrow(lt$path)==100L&&nrow(xt$grid)==288L,'PROD_FULL_GRID')
  wrap<-function(fit,p,tuning)list(predictions=data.frame(reference[c('subject_id','stay_id')],probability=p),
    sample_subject_ids=training$subject_id,training_contract_sha256=.br_sha(contract),
    model=fit,preprocessing=fit$prep,tuning=tuning,backend_class='ACTUAL_FROZEN_FULL_GRID')
  list(LASSO=wrap(lf,lp,lt),XGBoost=wrap(xf,xp,xt))
}

v13_restricted_replay <- function(fitted,reference) {
  env<-v13_load_fitting_primitives()
  lapply(setNames(c('LASSO','XGBoost'),c('LASSO','XGBoost')),function(m) {
    f<-fitted[[m]]
    .br_assert(nrow(if(m=='LASSO')f$tuning$path else f$tuning$grid)==
      if(m=='LASSO')100L else 288L,'PROD_REPLAY_GRID')
    if(m=='LASSO')env$predict_lasso(f$model,reference) else env$predict_xgb(f$model,reference)
  })
}
