# SOURCE-ONLY LOCAL CANDIDATE: NOT RELEASED OR EXECUTION-AUTHORIZED.
# Derived from an enumerated source snapshot; see README and internal provenance.
# No research data, fitted parameters, individual predictions or credentials are embedded.
# Prespecified algorithm constants are code, not fitted research results.
# This is not the verified manuscript execution version and is not a complete pipeline.



.v13_prod_spec <- function(s,reference,directory) {
  .br_runtime()
  .br_assert(is.list(s)&&identical(s$schema,'V13_RESTRICTED_DEVELOPMENT_V1')&&
    s$mode %in% c('RESTRICTED_CLINICAL','INVENTED_ENGINE_TEST')&&
    identical(s$aggregate_release_authorized,FALSE),'PROD_SCOPE')
  profiles<-c('PRIMARY','BASELINE_THRESHOLD_3','BASELINE_THRESHOLD_5','ICU_AT_H6',
    'EXCLUDE_DATE_ONLY','CHARTTIME_ONLY','ACUTE_LENIENT','ACUTE_STRICT','SCR_OR_RECORDED_RRT')
  .br_assert(s$profile %in% profiles&&s$selection %in% c('PRIMARY','COMPLETE_CASE','RELAXED_OBSERVATION')&&
    (s$profile=='PRIMARY'||s$selection=='PRIMARY'),'PROD_BRANCH')
  .br_assert(.br_scalar_text(s$run_id)&&grepl('^[A-Za-z0-9_-]{1,100}$',s$run_id),'PROD_RUN_ID')
  .br_assert(.br_whole(s$iterations,2L)&&length(s$iterations)==1L&&s$iterations<=500L&&
    .br_whole(s$min_valid,2L)&&length(s$min_valid)==1L&&s$min_valid<=s$iterations,'PROD_COUNTS')
  for(k in c('input_sha256','authorization_sha256','qc_disposition_sha256','capture_receipt_sha256'))
    .br_assert(.br_scalar_text(s[[k]])&&grepl('^[0-9a-f]{64}$',s[[k]]),'PROD_BINDING_HASH')
  .br_assert(length(s$code_sha256)>0L&&!anyDuplicated(names(s$code_sha256)),'PROD_CODE_INVENTORY')
  for(p in names(s$code_sha256)).br_assert(identical(unname(tools::sha256sum(p)),s$code_sha256[[p]]),'PROD_CODE_HASH')
  .br_assert(identical(s$model_execution_authorized,TRUE)&&identical(s$clinical_qc_disposition,'CLEARED_FOR_SPECIFIED_MODEL_SCOPE'),
    'PROD_QC_OR_EXECUTION_NOT_CLEARED')
  .br_assert(dir.exists(directory),'PROD_DIRECTORY')
  if(s$mode=='RESTRICTED_CLINICAL') {
    .br_assert(identical(s$iterations,500L)&&identical(s$min_valid,450L)&&
      identical(s$backend,'ACTUAL_FROZEN_FULL_GRID'),'PROD_FORMAL_CONTRACT')
    .br_production_directory(directory)
    .br_assert(all(grepl('^[1-9][0-9]*$',reference$subject_id))&&
      all(grepl('^[1-9][0-9]*$',reference$stay_id)),'PROD_CLINICAL_KEYS')
  } else {
    .br_assert(s$iterations<=5L&&s$backend %in% c('TEST_DOUBLE_NOT_FITTED','ACTUAL_FROZEN_FULL_GRID')&&
      all(startsWith(reference$subject_id,'SYN_'))&&all(startsWith(reference$stay_id,'SYN_')),'PROD_TEST_ONLY')
    candidate_root<-Sys.getenv("CANDIDATE_RESTRICTED_ROOT",unset="")
    .br_assert(nzchar(candidate_root),"HOLD_CANDIDATE_RESTRICTED_ROOT_REQUIRED")
    root<-normalizePath(candidate_root,winslash='/',mustWork=TRUE)
    .br_assert(startsWith(normalizePath(directory,winslash='/',mustWork=TRUE),paste0(root,'/')),'PROD_TEST_ROOT')
  }
  .br_assert(is.numeric(reference$incident_aki)&&!anyNA(reference$incident_aki)&&
    all(reference$incident_aki %in% 0:1)&&all(table(factor(reference$incident_aki,levels=0:1))>=5),'PROD_REFERENCE_CLASSES')
  invisible(TRUE)
}

.v13_prod_prediction <- function(bundle) list(schema='V13_RESTRICTED_REFERENCE_PREDICTIONS_V1',
  record=bundle$record,out_of_bag=bundle$record$body$data$inbag_multiplicity==0L)

v13_run_restricted_development <- function(reference,directory,spec,fit_pair=v13_restricted_fit_pair,
    replay=v13_restricted_replay,phase='run',stop_after_commits=Inf,after_commit=function(path)NULL) {
  reference<-.br_keys(reference,'restricted reference');rownames(reference)<-NULL
  .v13_prod_spec(spec,reference,directory)
  .br_assert(phase %in% c('run','verify')&&length(phase)==1L&&
    length(stop_after_commits)==1L&&!is.na(stop_after_commits)&&stop_after_commits>=1&&
    (is.infinite(stop_after_commits)||.br_whole(stop_after_commits,1L)),'PROD_PHASE')
  if(spec$mode=='RESTRICTED_CLINICAL').br_assert(identical(fit_pair,v13_restricted_fit_pair)&&
    identical(replay,v13_restricted_replay)&&identical(body(after_commit),body(function(path)NULL)),
    'PROD_CALLBACK_SUBSTITUTION')
  lock<-file.path(directory,'.development_lock')
  .br_assert(dir.create(lock,showWarnings=FALSE),'PROD_LOCKED')
  owned<-normalizePath(lock,winslash='/',mustWork=TRUE)
  .br_assert(identical(dirname(owned),normalizePath(directory,winslash='/',mustWork=TRUE)),'PROD_LOCK_PATH')
  on.exit({if(dir.exists(owned)&&!length(list.files(owned,all.files=TRUE,no..=TRUE)))unlink(owned,recursive=TRUE)},add=TRUE)
  n<-nrow(reference);B<-as.integer(spec$iterations);contract<-v13_model_development_contract()
  plan<-v13_bootstrap_attempt_plan(B)
  apparent_seed<-data.frame(iteration=0L,attempt=1L,resample_seed=20260903L,
    lasso_tuning_seed=20260903L,xgboost_tuning_seed=20261903L)
  manifest<-list(spec=spec,reference_sha256=.br_sha(reference),contract=contract,plan=plan,
    apparent_seed=apparent_seed,r_version=as.character(getRversion()),
    packages=if(spec$backend=='ACTUAL_FROZEN_FULL_GRID')vapply(c('glmnet','xgboost','Matrix'),
      function(p)as.character(packageVersion(p)),character(1)) else NULL,
    callbacks=.br_sha(list(formals(fit_pair),body(fit_pair),formals(replay),body(replay))))
  identity<-.br_sha(manifest);mp<-file.path(directory,'manifest.rds');ap<-file.path(directory,'apparent.rds')
  existing<-setdiff(list.files(directory,all.files=TRUE,no..=TRUE),'.development_lock')
  .br_assert(all(existing %in% c('manifest.rds','apparent.rds','result.rds')|
    grepl('^attempt_[0-9]{6}_[0-9]{2}[.]rds$|^predictions_[0-9]{6}[.]rds$',existing)),'PROD_UNKNOWN_OR_PARTIAL')
  if(file.exists(mp)).br_assert(identical(.v13_checkpoint_read(mp),manifest),'PROD_IDENTITY_CHANGED')
  else {
    .br_assert(phase=='run'&&!length(existing),'PROD_MANIFEST_MISSING')
    .v13_checkpoint_write(manifest,mp)
  }
  fit_calls<-0L;added<-0L;models<-c('LASSO','XGBoost')
  fit<-function(index,seeds) {
    .br_assert(phase=='run','PROD_VERIFY_NO_FIT');fit_calls<<-fit_calls+1L
    .v13_development_fit(reference,index,seeds,fit_pair,contract,spec$backend)
  }
  validate_fit<-function(fitted,predictions,index,do_replay=FALSE) {
    .br_assert(identical(names(fitted),models)&&identical(names(predictions),models),'PROD_FITTED_SCHEMA')
    for(m in models) {
      f<-fitted[[m]];p<-.br_align(predictions[[m]],reference,m)$probability
      .br_assert(identical(f$backend_class,spec$backend)&&identical(f$training_contract_sha256,.br_sha(contract))&&
        identical(f$sample_subject_ids,reference$subject_id[index])&&
        identical(.br_align(f$predictions,reference,m)$probability,p),'PROD_FITTED_PROVENANCE')
    }
    if(do_replay) {
      probs<-replay(fitted,reference)
      for(m in models).br_assert(identical(probs[[m]],.br_align(predictions[[m]],reference,m)$probability),'PROD_MODEL_REPLAY')
    }
  }
  paths<-sort(list.files(directory,pattern='^attempt_[0-9]{6}_[0-9]{2}[.]rds$',full.names=TRUE))
  .br_assert(!any(grepl('^attempt_|^predictions_|^result[.]rds$',existing))||file.exists(ap),'PROD_APPARENT_MISSING')
  if(file.exists(ap)) {
    apparent<-.v13_checkpoint_read(ap)
    .br_assert(identical(apparent$identity,identity)&&identical(apparent$result$metrics,
      .v13_development_metrics(reference,apparent$result$predictions,rep(1,n))),'PROD_APPARENT_CHANGED')
    validate_fit(apparent$result$fitted,apparent$result$predictions,seq_len(n),TRUE)
  } else {
    .br_assert(phase=='run','PROD_VERIFY_INCOMPLETE')
    result<-fit(seq_len(n),apparent_seed)
    validate_fit(result$fitted,result$predictions,seq_len(n),TRUE)
    apparent<-list(identity=identity,result=result);.v13_checkpoint_write(apparent,ap)
  }
  metric_names<-names(apparent$result$metrics$original$LASSO$metrics)
  .br_assert(length(metric_names)==6L,'PROD_SIX_METRICS')
  train<-original<-array(NA_real_,c(B,2L,6L),dimnames=list(as.character(seq_len(B)),models,metric_names))
  ledger<-data.frame(iteration=integer(),attempt=integer(),status=character(),error_code=character())
  ei<-1L;ea<-1L;failed<-consecutive<-0L;boundary<-NULL;expected_predictions<-character()
  consume<-function(b,path,restore_export=FALSE) {
    .br_assert(is.null(boundary),'PROD_CHECKPOINT_AFTER_FAILURE_BOUNDARY')
    .br_assert(identical(b$identity,identity)&&identical(b$iteration,ei)&&identical(b$attempt,ea)&&ei<=B&&
      basename(path)==sprintf('attempt_%06d_%02d.rds',ei,ea),'PROD_CHECKPOINT_SEQUENCE')
    seeds<-plan[plan$iteration==ei&plan$attempt==ea,,drop=FALSE]
    ii<-.v20_seeded(seeds$resample_seed,function()sample.int(n,n,TRUE))
    .br_assert(identical(b$seeds,seeds)&&identical(b$sample_sha256,.br_sha(reference$subject_id[ii]))&&
      b$status %in% c('SUCCESS','FAILED'),'PROD_SAMPLE_OR_STATUS')
    if(b$status=='SUCCESS') {
      .br_assert(is.null(b$error_code),'PROD_SUCCESS_ERROR')
      .br_validate_record(b$record);d<-b$record$body$data;meta<-b$record$body$metadata
      .br_assert(identical(d$subject_id,reference$subject_id)&&identical(d$stay_id,reference$stay_id)&&
        identical(d$incident_aki,as.integer(reference$incident_aki))&&
        identical(d$inbag_multiplicity,tabulate(ii,nbins=n)),'PROD_REFERENCE_CHANGED')
      .br_assert(identical(meta$run_id,spec$run_id)&&identical(meta$analysis_variant,paste(spec$profile,spec$selection,sep='__'))&&
        identical(meta$analysis_matrix_sha256,manifest$reference_sha256)&&identical(meta$code_sha256,.br_sha(spec$code_sha256))&&
        meta$iteration==ei&&meta$attempt==ea&&meta$expected_iterations==B&&
        meta$resample_seed==seeds$resample_seed&&meta$lasso_tuning_seed==seeds$lasso_tuning_seed&&
        meta$xgboost_tuning_seed==seeds$xgboost_tuning_seed,'PROD_RECORD_IDENTITY')
      preds<-list(LASSO=data.frame(reference[c('subject_id','stay_id')],probability=d$lasso_probability),
        XGBoost=data.frame(reference[c('subject_id','stay_id')],probability=d$xgboost_probability))
      .br_assert(identical(b$metrics,.v13_development_metrics(reference,preds,tabulate(ii,nbins=n))),'PROD_METRICS_CHANGED')
      for(m in models) {
        tag<-if(m=='LASSO')'lasso' else 'xgboost'
        .br_assert(identical(.br_sha(b$fitted[[m]]$model),meta[[paste0(tag,'_model_sha256')]])&&
          identical(.br_sha(b$fitted[[m]]$preprocessing),meta[[paste0(tag,'_preprocessing_sha256')]]),'PROD_MODEL_HASH')
        train[ei,m,]<<-b$metrics$train[[m]]$metrics;original[ei,m,]<<-b$metrics$original[[m]]$metrics
      }
      validate_fit(b$fitted,preds,ii,phase=='verify')
      pp<-file.path(directory,sprintf('predictions_%06d.rds',ei));expected<-.v13_prod_prediction(b)
      expected_predictions<<-c(expected_predictions,basename(pp))
      if(file.exists(pp)).br_assert(identical(.v13_checkpoint_read(pp),expected),'PROD_PREDICTIONS_CHANGED')
      else if(restore_export).v13_checkpoint_write(expected,pp)
      consecutive<<-0L;ei<<-ei+1L;ea<<-1L
    } else {
      .br_assert(.br_scalar_text(b$error_code)&&grepl('^V20_[A-Z_]+$',b$error_code)&&
        is.null(b$record)&&is.null(b$fitted)&&is.null(b$metrics),'PROD_FAILED_RECORD')
      if(ea==3L) {failed<<-failed+1L;consecutive<<-consecutive+1L;ei<<-ei+1L;ea<<-1L
        boundary<<-.v20_failure_boundary(failed,consecutive)
      } else ea<<-ea+1L
    }
    ledger<<-rbind(ledger,data.frame(iteration=b$iteration,attempt=b$attempt,status=b$status,
      error_code=if(is.null(b$error_code))'' else b$error_code))
  }
  
  
  for(path in paths)consume(.v13_checkpoint_read(path),path,FALSE)
  present_predictions<-list.files(directory,pattern='^predictions_')
  .br_assert(all(present_predictions %in% expected_predictions),'PROD_ORPHAN_PREDICTIONS')
  
  
  for(path in paths) {
    b<-.v13_checkpoint_read(path)
    if(b$status=='SUCCESS') {
      pp<-file.path(directory,sprintf('predictions_%06d.rds',b$iteration))
      if(!file.exists(pp)).v13_checkpoint_write(.v13_prod_prediction(b),pp)
    }
  }
  if(phase=='verify').br_assert(ei>B||!is.null(boundary),'PROD_VERIFY_INCOMPLETE')
  if(file.exists(file.path(directory,'result.rds'))).br_assert(ei>B||!is.null(boundary),'PROD_PREMATURE_RESULT')
  while(ei<=B&&is.null(boundary)&&phase=='run') {
    seeds<-plan[plan$iteration==ei&plan$attempt==ea,,drop=FALSE]
    ii<-.v20_seeded(seeds$resample_seed,function()sample.int(n,n,TRUE))
    candidate<-tryCatch(fit(ii,seeds),error=function(e) {
      msg<-conditionMessage(e)
      list(error_code=if(grepl('^V20_[A-Z_]+$',msg))msg else 'V20_PAIRED_FIT_OR_METRIC_FAILURE')
    })
    b<-list(identity=identity,iteration=ei,attempt=ea,seeds=seeds,
      sample_sha256=.br_sha(reference$subject_id[ii]),status=if(is.null(candidate$error_code))'SUCCESS' else 'FAILED',
      error_code=candidate$error_code)
    if(b$status=='SUCCESS') {
      f<-candidate$fitted
      meta<-list(run_id=spec$run_id,analysis_variant=paste(spec$profile,spec$selection,sep='__'),iteration=ei,attempt=ea,
        expected_iterations=B,expected_sample_size=n,resample_seed=seeds$resample_seed,
        lasso_tuning_seed=seeds$lasso_tuning_seed,xgboost_tuning_seed=seeds$xgboost_tuning_seed,
        analysis_matrix_sha256=manifest$reference_sha256,code_sha256=.br_sha(spec$code_sha256),
        lasso_model_sha256=.br_sha(f$LASSO$model),xgboost_model_sha256=.br_sha(f$XGBoost$model),
        lasso_preprocessing_sha256=.br_sha(f$LASSO$preprocessing),xgboost_preprocessing_sha256=.br_sha(f$XGBoost$preprocessing),
        lasso_status='PASS',xgboost_status='PASS')
      b$record<-build_bootstrap_prediction_record(reference,candidate$predictions$LASSO,candidate$predictions$XGBoost,
        reference$subject_id[ii],reference$subject_id[ii],meta)
      b$metrics<-candidate$metrics;b$fitted<-candidate$fitted
    }
    path<-file.path(directory,sprintf('attempt_%06d_%02d.rds',ei,ea))
    .v13_checkpoint_write(b,path) 
    added<-added+1L;after_commit(path);consume(b,path,TRUE)
    cat('Paired slot progress: ',ei-1L,'/',B,'; committed attempts this call: ',added,'\n',sep='');flush.console()
    if(added>=stop_after_commits&&ei<=B&&is.null(boundary))return(list(status='PAUSED_COMMITTED_PREFIX',fit_calls=fit_calls,identity=identity))
  }
  app<-do.call(rbind,lapply(models,function(m)apparent$result$metrics$original[[m]]$metrics));rownames(app)<-models
  result<-list(status=if(is.null(boundary))'COMPLETED_RESTRICTED_DEVELOPMENT_NOT_RELEASED' else 'STOPPED_AT_SIGNED_FAILURE_BOUNDARY',
    identity=identity,mode=spec$mode,profile=spec$profile,selection=spec$selection,ledger=ledger,
    apparent=app,train=train,original=original,stop_reason=boundary,
    ci=if(is.null(boundary))v13_location_shifted_ci(app,train,original,B,as.integer(spec$min_valid)) else NULL,
    aggregate_release_authorized=FALSE)
  rp<-file.path(directory,'result.rds')
  if(file.exists(rp)).br_assert(identical(.v13_checkpoint_read(rp),result),'PROD_RESULT_CHANGED')
  else .v13_checkpoint_write(result,rp)
  list(status=result$status,identity=identity,fit_calls=fit_calls,added_attempts=added,
    completed_slots=ei-1L,valid_slots=sum(ledger$status=='SUCCESS'),stop_reason=boundary,
    result_sha256=unname(tools::sha256sum(rp)),aggregate_release_authorized=FALSE)
}
