# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.



v13_prepare_observation_input <- function(risk,contract) {
  cols<-c(v13_ps_continuous,v13_ps_binary)
  if(!is.data.frame(risk)||anyDuplicated(names(risk))||length(contract)!=16L||anyDuplicated(contract)||
     !setequal(contract,cols)||!all(c(cols,'subject_id','resolved','incident_aki','complete_case',
       'relaxed_incident_aki','relaxed_resolved') %in% names(risk))) stop('OBSERVATION_SCHEMA',call.=FALSE)
  if(!is.character(risk$subject_id)||!nrow(risk)||anyNA(risk$subject_id)||any(!nzchar(risk$subject_id))||
     anyDuplicated(risk$subject_id)) stop('OBSERVATION_PATIENT_KEYS',call.=FALSE)
  for(nm in c(cols,'resolved','incident_aki','relaxed_incident_aki','relaxed_resolved'))
    if(!is.numeric(risk[[nm]])||is.object(risk[[nm]])) stop('OBSERVATION_NUMERIC_TYPE',call.=FALSE)
  for(nm in c(v13_ps_binary,'resolved','relaxed_resolved'))
    if(anyNA(risk[[nm]])||any(!risk[[nm]] %in% c(0,1))) stop('OBSERVATION_BINARY',call.=FALSE)
  R<-risk$resolved;y<-risk$incident_aki;yr<-risk$relaxed_incident_aki
  if(any(!is.na(y[R==0]))||anyNA(y[R==1])||any(!y[R==1] %in% c(0,1))||
     any(risk$relaxed_resolved!=as.integer(!is.na(yr)))||any(!yr[!is.na(yr)] %in% c(0,1))||
     anyNA(yr[R==1])||any(yr[R==1]!=y[R==1])) stop('OBSERVATION_OUTCOME_SCOPE',call.=FALSE)
  if(any(is.finite(risk$map_mean_mm_hg)&risk$map_mean_mm_hg<=0)) stop('OBSERVATION_MAP_ZERO',call.=FALSE)
  for(pair in list(c('creatinine_mean_mg_dl','creatinine_missing'),c('hemoglobin_mean_g_dl','hemoglobin_missing'),c('urine_output_total_ml','urine_output_missing')))
    if(any(as.integer(!is.finite(risk[[pair[1]]]))!=risk[[pair[2]]])) stop('OBSERVATION_MISSING_FLAG',call.=FALSE)
  main<-setdiff(cols,c('creatinine_missing','hemoglobin_missing','urine_output_missing'))
  cc<-unname(R==1 & apply(is.finite(as.matrix(risk[,main,drop=FALSE])),1,all))
  if(!is.logical(risk$complete_case)||anyNA(risk$complete_case)||!identical(cc,unname(risk$complete_case)))
    stop('OBSERVATION_CC_RECONCILIATION',call.=FALSE)
  list(risk=risk[,c('subject_id','resolved','incident_aki',cols),drop=FALSE],complete_case=cc,
       relaxed_outcome=yr,relaxed_resolved=risk$relaxed_resolved,
       denominators=c(risk=nrow(risk),resolved=sum(R),unresolved=sum(R==0),complete_case=sum(cc),
                      relaxed_resolved=sum(risk$relaxed_resolved)),
       original_rows_preserved=TRUE,cc_refit_performed=FALSE,relaxed_refit_performed=FALSE)
}

v13_observation_weight_diagnostics <- function(prepared,count=rep(1,nrow(prepared$risk))) {
  risk<-prepared$risk
  .v13_counts(count,nrow(risk))
  if(sum(count)!=nrow(risk)) stop('OBSERVATION_NOT_N_OF_N',call.=FALSE)
  fit<-v13_fit_observation_ps(risk,risk$resolved,count)
  weights<-v13_ipw_weights(fit,sum(count[prepared$complete_case]))
  list(status=weights$status,fit=fit,weights=weights,
       outcome_model_fitted=FALSE,performance_evaluated=FALSE,
       scope='observation PS and weight diagnostics only; no fixed outcome predictions supplied')
}
