# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.


v13_ps_continuous <- c('age_years','creatinine_mean_mg_dl','hemoglobin_mean_g_dl',
                      'urine_output_total_ml','fluid_input_total_ml','map_mean_mm_hg')
v13_ps_binary <- c('female','prior_ckd','urgency_urgent','urgency_emergency',
                  'creatinine_missing','hemoglobin_missing','urine_output_missing',
                  'rbc_exposure','vasopressor_exposure','mechanical_ventilation')

.v13_counts <- function(count,n) {
  if(!is.numeric(count) || is.object(count) || !is.null(dim(count)) || length(count)!=n ||
     any(!is.finite(count)) || any(count<0 | count!=floor(count)) || sum(count)<=0 || sum(count)>2^53-1)
    stop('IPW_MULTIPLICITY',call.=FALSE)
}
.v13_replicated_quantile <- function(x,count,probs,type=8L) {
  .v13_counts(count,length(x))
  if(any(!is.finite(x))) stop('IPW_QUANTILE_NONFINITE',call.=FALSE)
  use <- count>0; x<-x[use]; count<-count[use]; o<-order(x); x<-x[o]; count<-count[o]
  n<-sum(count); cumulative<-cumsum(count)
  at <- function(k) x[which(cumulative>=max(1,min(n,k)))[1L]]
  vapply(probs,function(p){
    h<-if(type==8L) (n+1/3)*p+1/3 else if(type==7L) 1+(n-1)*p else stop('IPW_QUANTILE_TYPE')
    j<-floor(h); g<-h-j; (1-g)*at(j)+g*at(j+1)
  },numeric(1))
}

v13_ps_design <- function(features,count) {
  cols<-c(v13_ps_continuous,v13_ps_binary)
  if(!is.data.frame(features) || anyDuplicated(names(features)) || !all(cols %in% names(features)))
    stop('IPW_FEATURE_COLUMNS',call.=FALSE)
  .v13_counts(count,nrow(features))
  x<-features[,cols,drop=FALSE]
  for(nm in cols) if(!is.numeric(x[[nm]]) || is.object(x[[nm]])) stop('IPW_FEATURE_TYPE: ',nm,call.=FALSE)
  for(nm in v13_ps_binary) if(anyNA(x[[nm]]) || any(!x[[nm]] %in% c(0,1))) stop('IPW_BINARY: ',nm,call.=FALSE)
  if(any(x$urgency_urgent+x$urgency_emergency>1)) stop('IPW_URGENCY_CONFLICT',call.=FALSE)
  
  x$map_mean_mm_hg[!is.finite(x$map_mean_mm_hg) | x$map_mean_mm_hg<=0]<-NA_real_
  missing_pairs<-c(creatinine_mean_mg_dl='creatinine_missing',hemoglobin_mean_g_dl='hemoglobin_missing',urine_output_total_ml='urine_output_missing')
  for(nm in names(missing_pairs)) if(any(as.integer(!is.finite(x[[nm]])) != x[[missing_pairs[[nm]]]]))
    stop('IPW_MISSING_FLAG_MISMATCH: ',nm,call.=FALSE)
  medians<-setNames(numeric(length(v13_ps_continuous)),v13_ps_continuous)
  for(nm in v13_ps_continuous) {
    valid<-is.finite(x[[nm]]) & count>0
    if(!any(valid)) stop('IPW_ALL_MISSING_TRAINING: ',nm,call.=FALSE)
    medians[nm]<-.v13_replicated_quantile(x[[nm]][valid],count[valid],.5,type=7L)
    x[[nm]][!is.finite(x[[nm]])]<-medians[nm]
  }
  use<-count>0
  
  center<-vapply(x,function(z) weighted.mean(z[use],count[use]),numeric(1))
  scale<-vapply(names(x),function(nm) sqrt(weighted.mean((x[[nm]][use]-center[nm])^2,count[use])),numeric(1))
  scale[scale==0]<-1
  matrix<-cbind('(Intercept)'=1,sweep(sweep(as.matrix(x[use,,drop=FALSE]),2,center),2,scale,'/'))
  qrfit<-qr(matrix,tol=1e-10)
  basis<-sort(qrfit$pivot[seq_len(qrfit$rank)])
  list(matrix=matrix[,basis,drop=FALSE],full_encoded_columns=cols,
       numerical_basis_columns=colnames(matrix)[basis],aliased_columns=colnames(matrix)[-basis],
       medians=medians,centers=center,scales=scale,inbag_rows=which(use),counts=count[use])
}

v13_fit_observation_ps <- function(features,resolved,count=rep(1,nrow(features))) {
  if(!is.numeric(resolved) || length(resolved)!=nrow(features) || anyNA(resolved) || any(!resolved %in% c(0,1)))
    stop('IPW_RESOLVED_INPUT',call.=FALSE)
  if(!requireNamespace('detectseparation',quietly=TRUE) || !requireNamespace('logistf',quietly=TRUE))
    stop('IPW_DEPENDENCIES_NOT_LOADED',call.=FALSE)
  design<-v13_ps_design(features,count); y<-resolved[design$inbag_rows]; w<-design$counts
  if(length(unique(y))!=2L) stop('IPW_RESOLVED_SINGLE_CLASS',call.=FALSE)
  x<-design$matrix
  separated<-detectseparation::detect_separation(x=x,y=y,weights=w,family=binomial(),intercept=TRUE)
  if(anyNA(separated$coefficients)) stop('IPW_SEPARATION_DETECTION_FAILED',call.=FALSE)
  is_separated<-any(is.infinite(separated$coefficients))
  warnings<-character(); capture<-function(e){warnings<<-c(warnings,conditionMessage(e));invokeRestart('muffleWarning')}
  fit<-NULL; reason<-if(is_separated) 'DETECTED_SEPARATION' else 'NONE'
  if(!is_separated) {
    fit<-tryCatch(withCallingHandlers(glm.fit(x=x,y=y,weights=w,family=binomial(),control=glm.control(maxit=100)),warning=capture),error=function(e)e)
    if(!inherits(fit,'list') || inherits(fit,'error') || !isTRUE(fit$converged) || isTRUE(fit$boundary) ||
       any(!is.finite(fit$coefficients)) || any(grepl('fitted probabilities numerically 0 or 1',warnings,fixed=TRUE))) reason<-'ML_FAILED_OR_BOUNDARY'
  }
  method<-'LOGISTIC_ML'
  if(reason!='NONE') {
    d<-as.data.frame(x); names(d)<-paste0('z',seq_len(ncol(x))); d$R<-y
    formula<-reformulate(paste0('z',seq_len(ncol(x))),response='R',intercept=FALSE)
    control<-logistf::logistf.control(maxit=1000)
    fit<-withCallingHandlers(logistf::logistf(formula,data=d,weights=w,pl=FALSE,firth=TRUE,flic=FALSE,
                                            na.action=na.fail,control=control),warning=capture)
    limits<-c(control$lconv,control$gconv,control$xconv)
    if(any(!is.finite(fit$coefficients)) || length(fit$conv)!=3L || any(!is.finite(fit$conv)) || any(abs(fit$conv)>limits))
      stop('IPW_FIRTH_NOT_CONVERGED',call.=FALSE)
    p<-as.numeric(predict(fit,newdata=d,type='response')); method<-'FIRTH_LOGISTIC'
  } else p<-as.numeric(fit$fitted.values)
  if(any(!is.finite(p) | p<=0 | p>=1)) stop('IPW_PS_BOUNDARY',call.=FALSE)
  list(probability=p,inbag_rows=design$inbag_rows,counts=w,method=method,fallback_reason=reason,
       warnings=unique(warnings),preprocessing=design,resolved=y)
}

v13_ipw_weights <- function(ps_fit,cc_count,quantile_type=8L) {
  p<-ps_fit$probability; R<-ps_fit$resolved; count<-ps_fit$counts
  .v13_counts(count,length(p))
  if(length(R)!=length(p) || anyNA(R) || any(!R %in% c(0,1)) || any(!is.finite(p)|p<=0|p>=1) ||
     length(cc_count)!=1L || !is.finite(cc_count) || cc_count<0 || cc_count!=floor(cc_count)) stop('IPW_WEIGHT_INPUT',call.=FALSE)
  
  o<-order(p); group<-cumsum(c(TRUE,diff(p[o])!=0)); mass<-as.numeric(rowsum(count[o],group,reorder=FALSE))
  midpoint<-(cumsum(mass)-mass/2)/sum(mass)
  groupbin<-pmin(10L,pmax(1L,floor(10*midpoint)+1L)); bin<-integer(length(p)); bin[o]<-groupbin[group]
  support<-do.call(rbind,lapply(sort(unique(bin)),function(b) data.frame(bin=b,
    resolved=sum(count[bin==b & R==1]),unresolved=sum(count[bin==b & R==0]))))
  selected<-R==1
  if(!any(selected)) stop('IPW_NO_RESOLVED_ROWS',call.=FALSE)
  raw<-weighted.mean(R,count)/p[selected]
  cuts<-.v13_replicated_quantile(raw,count[selected],c(.01,.99),type=quantile_type)
  winsor<-pmin(cuts[2],pmax(cuts[1],raw))
  evaluation_weight<-count[selected]*winsor
  
  ess<-sum(evaluation_weight)^2/sum(count[selected]*winsor^2)
  reasons<-character()
  if(any(support$resolved==0)) reasons<-c(reasons,'OCCUPIED_BIN_WITHOUT_RESOLVED')
  if(any(support$unresolved==0)) reasons<-c(reasons,'PRESPECIFIED_CONSERVATIVE_BIN_WITHOUT_UNRESOLVED')
  if(ess<.8*cc_count) reasons<-c(reasons,'ESS_BELOW_80_PERCENT_CC')
  list(status=if(length(reasons)) 'DIAGNOSTICS_ONLY' else 'PASS',reasons=reasons,support=support,
       resolved_indices=which(selected),raw_weight=raw,winsor_weight=winsor,evaluation_weight=evaluation_weight,
       truncation=cuts,quantile_type=quantile_type,ess=ess,cc_count=cc_count,
       truncated_copies=sum(count[selected][raw!=winsor]),binning='weighted rank midpoint deciles, exact ties unsplit')
}
