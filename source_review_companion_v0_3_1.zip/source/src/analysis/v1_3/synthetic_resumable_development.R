# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.




.v13_checkpoint_write <- function(value,path) {
  raw<-serialize(value,NULL,version=3L)
  
  .br_atomic_new_rds(list(payload=raw,sha256=.br_sha(raw)),path)
}
.v13_checkpoint_read <- function(path) {
  x<-readRDS(path)
  .br_assert(is.list(x)&&identical(names(x),c('payload','sha256'))&&is.raw(x$payload)&&
    identical(.br_sha(x$payload),x$sha256),'DEV_CHECKPOINT_HASH')
  unserialize(x$payload)
}
.v13_development_metrics <- function(reference,predictions,count) {
  models<-c('LASSO','XGBoost');train<-original<-list()
  for(m in models) {
    p<-.br_align(predictions[[m]],reference,m)$probability
    train[[m]]<-v13_fractional_metrics(reference$incident_aki,p,count)
    original[[m]]<-v13_fractional_metrics(reference$incident_aki,p,rep(1,nrow(reference)))
    .br_assert(train[[m]]$all_metrics_finite&&original[[m]]$all_metrics_finite,'V20_NONFINITE_PRIMARY_METRIC')
  }
  list(train=train,original=original)
}
.v13_development_fit <- function(reference,index,seeds,fit_pair,contract,backend) {
  count<-tabulate(index,nbins=nrow(reference))
  folds<-.v20_group_folds(reference$incident_aki,count,seeds$lasso_tuning_seed)
  fitted<-fit_pair(reference[index,,drop=FALSE],reference,folds[index],seeds,contract)
  .br_assert(is.list(fitted)&&identical(names(fitted),c('LASSO','XGBoost')),'V20_PAIRED_FIT_SCHEMA')
  predictions<-list()
  for(m in names(fitted)) {
    f<-fitted[[m]]
    .br_assert(identical(f$backend_class,backend)&&identical(f$training_contract_sha256,.br_sha(contract)),
               'V20_TUNING_CONTRACT_CHANGED')
    .br_assert(identical(f$sample_subject_ids,reference$subject_id[index]),'V20_PAIRED_SAMPLE_CHANGED')
    .br_assert(!is.null(f$model)&&!is.null(f$preprocessing),'V20_MODEL_PROVENANCE_MISSING')
    predictions[[m]]<-.br_align(f$predictions,reference,m)
  }
  metrics<-.v13_development_metrics(reference,predictions,count)
  list(fitted=fitted,predictions=predictions,metrics=metrics)
}

v13_run_synthetic_resumable_development <- function(reference,directory,variant,fit_pair,
    iterations=3L,min_valid=2L,data_class=NULL,backend='TEST_DOUBLE_NOT_FITTED',
    stop_after_commits=Inf,after_commit=function(path)NULL) {
  .br_runtime()
  .br_assert(identical(data_class,'INVENTED_MECHANISM_FIXTURE_ONLY'),'DEV_PRODUCTION_NOT_AUTHORIZED')
  .br_assert(variant %in% c('PRIMARY','COMPLETE_CASE','RELAXED_OBSERVATION')&&length(variant)==1L,'DEV_VARIANT')
  .br_assert(backend %in% c('TEST_DOUBLE_NOT_FITTED','ACTUAL_SYNTHETIC_FULL_GRID')&&length(backend)==1L,'DEV_BACKEND')
  .br_assert(.br_whole(iterations,2L)&&length(iterations)==1L&&iterations<=5L&&
    .br_whole(min_valid,2L)&&length(min_valid)==1L&&min_valid<=iterations,'DEV_SYNTHETIC_COUNTS_ONLY')
  .br_assert(length(stop_after_commits)==1L&&!is.na(stop_after_commits)&&stop_after_commits>=1&&
    (is.infinite(stop_after_commits)||.br_whole(stop_after_commits,1L)),'DEV_PAUSE_COUNT')
  reference<-.br_keys(reference,'development reference');n<-nrow(reference)
  .br_assert(all(startsWith(reference$subject_id,'SYN_'))&&all(startsWith(reference$stay_id,'SYN_')),
             'DEV_SYNTHETIC_KEYS')
  .br_assert(is.numeric(reference$incident_aki)&&!anyNA(reference$incident_aki)&&
    all(reference$incident_aki %in% 0:1)&&all(table(factor(reference$incident_aki,levels=0:1))>=5),'DEV_OUTCOME_CLASSES')
  .br_assert(dir.exists(directory)&&is.function(fit_pair)&&is.function(after_commit),'DEV_DIRECTORY_OR_CALLBACK')
  lock<-file.path(directory,'.development_lock')
  .br_assert(dir.create(lock,showWarnings=FALSE),'DEV_RUN_LOCKED')
  owned_lock<-normalizePath(lock,winslash='/',mustWork=TRUE)
  .br_assert(identical(dirname(owned_lock),normalizePath(directory,winslash='/',mustWork=TRUE)),'DEV_LOCK_PATH')
  on.exit({if(dir.exists(owned_lock)&&length(list.files(owned_lock,all.files=TRUE,no..=TRUE))==0L)
    unlink(owned_lock,recursive=TRUE)},add=TRUE)
  
  files<-sort(c(list.files('source/src/analysis/v1_3',pattern='[.]R$',full.names=TRUE),
       'source/src/analysis/run_restricted_mimic_model_development_v1_0.R'))
  contract<-v13_model_development_contract();plan<-v13_bootstrap_attempt_plan(iterations)
  apparent_seed<-data.frame(iteration=0L,attempt=1L,resample_seed=20260903L,
                             lasso_tuning_seed=20260903L,xgboost_tuning_seed=20261903L)
  manifest<-list(schema='SYNTHETIC_DEVELOPMENT_CHECKPOINT_V1',variant=variant,backend=backend,
    data_class=data_class,reference_sha256=.br_sha(reference),contract=contract,plan=plan,
    apparent_seeds=apparent_seed,iterations=iterations,min_valid=min_valid,
    code_sha256=tools::sha256sum(files),callback_definition_sha256=.br_sha(list(formals(fit_pair),body(fit_pair))),
    r_version=as.character(getRversion()),
    package_versions=if(backend=='ACTUAL_SYNTHETIC_FULL_GRID')
      vapply(c('glmnet','xgboost','Matrix'),function(p)as.character(packageVersion(p)),character(1)) else NULL)
  identity<-.br_sha(manifest);mp<-file.path(directory,'manifest.rds');ap<-file.path(directory,'apparent.rds')
  existing<-setdiff(list.files(directory,all.files=TRUE,no..=TRUE),basename(lock))
  .br_assert(all(existing %in% c('manifest.rds','apparent.rds')|
    grepl('^attempt_[0-9]{6}_[0-9]{2}[.]rds$',existing)),'DEV_UNKNOWN_OR_PARTIAL_ARTIFACT')
  if(file.exists(mp)) .br_assert(identical(.v13_checkpoint_read(mp),manifest),'DEV_IDENTITY_CHANGED')
  else {
    .br_assert(length(existing)==0L,'DEV_MISSING_MANIFEST')
    .v13_checkpoint_write(manifest,mp)
  }
  attempt_paths<-sort(list.files(directory,pattern='^attempt_[0-9]{6}_[0-9]{2}[.]rds$',full.names=TRUE))
  .br_assert(!length(attempt_paths)||file.exists(ap),'DEV_MISSING_APPARENT')
  
  bundles<-list();ei<-1L;ea<-1L
  for(p in attempt_paths) {
    b<-.v13_checkpoint_read(p)
    .br_assert(identical(b$identity,identity)&&b$iteration==ei&&b$attempt==ea&&ei<=iterations&&
      basename(p)==sprintf('attempt_%06d_%02d.rds',ei,ea),'DEV_CHECKPOINT_SEQUENCE')
    seeds<-plan[plan$iteration==ei&plan$attempt==ea,,drop=FALSE]
    ii<-.v20_seeded(seeds$resample_seed,function()sample.int(n,n,TRUE))
    .br_assert(identical(b$seeds,seeds)&&identical(b$sample_sha256,.br_sha(reference$subject_id[ii])),
      'DEV_SAMPLE_CHANGED')
    .br_assert(b$status %in% c('SUCCESS','FAILED')&&length(b$status)==1L,'DEV_CHECKPOINT_STATUS')
    if(b$status=='SUCCESS') {
      .br_validate_record(b$record);rd<-b$record$body$data
      .br_assert(identical(rd$subject_id,reference$subject_id)&&identical(rd$stay_id,reference$stay_id)&&
         identical(rd$incident_aki,as.integer(reference$incident_aki))&&
         identical(rd$inbag_multiplicity,tabulate(ii,nbins=n)), 'DEV_REFERENCE_CHANGED')
      .br_assert(b$record$body$metadata$analysis_matrix_sha256==manifest$reference_sha256&&
        b$record$body$metadata$analysis_variant==variant&&b$record$body$metadata$iteration==ei&&
        b$record$body$metadata$attempt==ea,'DEV_RECORD_IDENTITY')
      preds<-list(LASSO=data.frame(reference[c('subject_id','stay_id')],probability=rd$lasso_probability),
                   XGBoost=data.frame(reference[c('subject_id','stay_id')],probability=rd$xgboost_probability))
      .br_assert(identical(b$metrics,.v13_development_metrics(reference,preds,tabulate(ii,nbins=n))),'DEV_METRICS_CHANGED')
      for(m in c('LASSO','XGBoost')) {
        f<-b$fitted[[m]];tag<-if(m=='LASSO')'lasso' else 'xgboost'
        .br_assert(identical(.br_sha(f$model),b$record$body$metadata[[paste0(tag,'_model_sha256')]])&&
          identical(.br_sha(f$preprocessing),b$record$body$metadata[[paste0(tag,'_preprocessing_sha256')]])&&
          identical(f$sample_subject_ids,reference$subject_id[ii])&&
          identical(.br_align(f$predictions,reference,m)$probability,preds[[m]]$probability),'DEV_FITTED_PROVENANCE')
      }
      ei<-ei+1L;ea<-1L
    } else if(ea==3L){ei<-ei+1L;ea<-1L}else ea<-ea+1L
    bundles[[basename(p)]]<-b
  }
  if(file.exists(ap)) {
    apparent<-.v13_checkpoint_read(ap)
    .br_assert(identical(apparent$identity,identity),'DEV_APPARENT_IDENTITY')
    .br_assert(identical(apparent$result$metrics,
      .v13_development_metrics(reference,apparent$result$predictions,rep(1,n))),'DEV_APPARENT_METRICS')
  } else {
    
    result<-.v13_development_fit(reference,seq_len(n),apparent_seed,fit_pair,contract,backend)
    apparent<-list(identity=identity,result=result)
    .v13_checkpoint_write(apparent,ap)
  }
  added<-0L;failed<-consecutive<-0L
  for(i in seq_len(iterations)) {
    success<-FALSE
    for(a in 1:3) {
      key<-sprintf('attempt_%06d_%02d.rds',i,a)
      b<-bundles[[key]]
      if(is.null(b)) {
        seeds<-plan[plan$iteration==i&plan$attempt==a,,drop=FALSE]
        ii<-.v20_seeded(seeds$resample_seed,function()sample.int(n,n,TRUE))
        candidate<-tryCatch(.v13_development_fit(reference,ii,seeds,fit_pair,contract,backend),
          error=function(e)list(error_code=if(grepl('^V20_[A-Z_]+$',conditionMessage(e)))conditionMessage(e)
                                        else 'V20_PAIRED_FIT_OR_METRIC_FAILURE'))
        b<-list(identity=identity,iteration=i,attempt=a,seeds=seeds,
          sample_sha256=.br_sha(reference$subject_id[ii]),
          status=if(is.null(candidate$error_code))'SUCCESS' else 'FAILED',error_code=candidate$error_code)
        if(b$status=='SUCCESS') {
          f<-candidate$fitted
          meta<-list(run_id=paste0('SYN_DEVELOPMENT_',variant),analysis_variant=variant,iteration=i,attempt=a,
            expected_iterations=as.integer(iterations),expected_sample_size=n,resample_seed=seeds$resample_seed,
            lasso_tuning_seed=seeds$lasso_tuning_seed,xgboost_tuning_seed=seeds$xgboost_tuning_seed,
            analysis_matrix_sha256=manifest$reference_sha256,code_sha256=.br_sha(manifest$code_sha256),
            lasso_model_sha256=.br_sha(f$LASSO$model),xgboost_model_sha256=.br_sha(f$XGBoost$model),
            lasso_preprocessing_sha256=.br_sha(f$LASSO$preprocessing),
            xgboost_preprocessing_sha256=.br_sha(f$XGBoost$preprocessing),lasso_status='PASS',xgboost_status='PASS')
          b$record<-build_bootstrap_prediction_record(reference,candidate$predictions$LASSO,
            candidate$predictions$XGBoost,reference$subject_id[ii],reference$subject_id[ii],meta)
          b$metrics<-candidate$metrics;b$fitted<-candidate$fitted
        }
        
        
        path<-file.path(directory,key);.v13_checkpoint_write(b,path)
        bundles[[key]]<-b;added<-added+1L
        after_commit(path)
        if(added>=stop_after_commits)return(list(status='PAUSED_SYNTHETIC_CHECKPOINT',added=added,identity=identity))
      }
      if(b$status=='SUCCESS'){success<-TRUE;break}
    }
    if(success)consecutive<-0L else {failed<-failed+1L;consecutive<-consecutive+1L}
    boundary<-.v20_failure_boundary(failed,consecutive)
    if(!is.null(boundary))return(list(status='SIGNED_FAILURE_BOUNDARY',reason=boundary))
  }
  models<-c('LASSO','XGBoost');metrics<-names(apparent$result$metrics$original$LASSO$metrics)
  train<-original<-array(NA_real_,c(iterations,2L,length(metrics)),
    dimnames=list(as.character(seq_len(iterations)),models,metrics))
  ledger<-do.call(rbind,lapply(bundles,function(b)data.frame(iteration=as.integer(b$iteration),
      attempt=as.integer(b$attempt),status=b$status,error_code=if(is.null(b$error_code))'' else b$error_code)))
  for(b in bundles)if(b$status=='SUCCESS')for(m in models) {
    train[b$iteration,m,]<-b$metrics$train[[m]]$metrics
    original[b$iteration,m,]<-b$metrics$original[[m]]$metrics
  }
  app<-do.call(rbind,lapply(models,function(m)apparent$result$metrics$original[[m]]$metrics));rownames(app)<-models
  ci<-v13_location_shifted_ci(app,train,original,iterations,min_valid)
  list(status='PASS_SYNTHETIC_RESUMABLE_DEVELOPMENT_NOT_FORMAL',identity=identity,ledger=ledger,
       apparent=app,train=train,original=original,ci=ci,added_this_call=added,
       actual_models_fitted=backend=='ACTUAL_SYNTHETIC_FULL_GRID',production_ready=FALSE)
}
