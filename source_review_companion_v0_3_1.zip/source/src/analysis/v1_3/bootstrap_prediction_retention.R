# SOURCE-ONLY LOCAL CANDIDATE. NOT RELEASED OR EXECUTION-AUTHORIZED.
# Original source is preserved; derived-source configuration changes are separately logged.
# No data, fitted artifacts, run outputs or credentials accompany this file.
# Optional/sensitivity branches are not evidence those analyses were performed.





.br_stop <- function(message) stop(message, call. = FALSE)
.br_assert <- function(ok, message) {
  if (!isTRUE(ok)) .br_stop(message)
}
.br_runtime <- function() {
  .br_assert(as.character(getRversion()) == "4.6.1", "R 4.6.1 is required")
}
.br_sha <- function(value) {
  unname(tools::sha256sum(bytes = serialize(value, NULL, version = 3L)))
}
.br_scalar_text <- function(x) {
  is.character(x) && length(x) == 1L && !is.na(x) && nzchar(x)
}
.br_whole <- function(x, minimum = 0L) {
  is.numeric(x) && length(x) > 0L && !anyNA(x) &&
    all(is.finite(x) & x >= minimum & x == floor(x) & x <= .Machine$integer.max)
}
.br_keys <- function(x, name) {
  .br_assert(is.data.frame(x) && nrow(x) > 0L &&
               all(c("subject_id", "stay_id") %in% names(x)),
             paste0(name, " must contain patient and stay keys"))
  for (key in c("subject_id", "stay_id")) {
    .br_assert(is.character(x[[key]]) || is.numeric(x[[key]]),
               paste0(name, " has an unsupported key type"))
    x[[key]] <- as.character(x[[key]])
    .br_assert(!anyNA(x[[key]]) && all(nzchar(x[[key]])) &&
                 !anyDuplicated(x[[key]]),
               paste0(name, " has missing or duplicate patient/stay keys"))
  }
  x
}
.br_align <- function(x, reference, name) {
  x <- .br_keys(x, name)
  .br_assert(nrow(x) == nrow(reference), paste0(name, " has the wrong row count"))
  index <- match(reference$stay_id, x$stay_id)
  .br_assert(!anyNA(index), paste0(name, " has different reference keys"))
  x <- x[index, , drop = FALSE]
  .br_assert(identical(x$subject_id, reference$subject_id),
             paste0(name, " has a different patient-to-stay mapping"))
  rownames(x) <- NULL
  x
}
.br_metadata <- function(metadata, expected_n) {
  required <- c("run_id", "analysis_variant", "iteration", "attempt",
                "expected_iterations", "expected_sample_size", "resample_seed",
                "lasso_tuning_seed", "xgboost_tuning_seed", "analysis_matrix_sha256",
                "code_sha256", "lasso_model_sha256", "xgboost_model_sha256",
                "lasso_preprocessing_sha256", "xgboost_preprocessing_sha256",
                "lasso_status", "xgboost_status")
  .br_assert(is.list(metadata) && identical(sort(names(metadata)), sort(required)),
             "Metadata must contain exactly the documented required fields")
  .br_assert(.br_scalar_text(metadata$run_id) &&
               grepl("^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$", metadata$run_id),
             "Invalid run identifier")
  .br_assert(.br_scalar_text(metadata$analysis_variant), "Missing analysis variant")
  for (key in c("iteration", "attempt", "expected_iterations", "expected_sample_size")) {
    .br_assert(length(metadata[[key]]) == 1L && .br_whole(metadata[[key]], 1L),
               paste0("Invalid integer metadata: ", key))
    metadata[[key]] <- as.integer(metadata[[key]])
  }
  .br_assert(metadata$iteration <= metadata$expected_iterations,
             "Iteration exceeds the declared run count")
  .br_assert(metadata$expected_sample_size == expected_n,
             "This component requires an n-of-n patient bootstrap")
  for (key in c("resample_seed", "lasso_tuning_seed", "xgboost_tuning_seed")) {
    .br_assert(length(metadata[[key]]) == 1L && .br_whole(metadata[[key]]),
               paste0("Invalid seed metadata: ", key))
    metadata[[key]] <- as.integer(metadata[[key]])
  }
  for (key in required[endsWith(required, "_sha256")]) {
    .br_assert(.br_scalar_text(metadata[[key]]) &&
                 grepl("^[A-Fa-f0-9]{64}$", metadata[[key]]),
               paste0("Invalid SHA-256 metadata: ", key))
    metadata[[key]] <- tolower(metadata[[key]])
  }
  .br_assert(identical(metadata$lasso_status, "PASS") &&
               identical(metadata$xgboost_status, "PASS"),
             "Both fitted models must have succeeded before predictions are committed")
  metadata[required]
}





build_bootstrap_prediction_record <- function(reference, lasso_predictions,
                                               xgboost_predictions,
                                               lasso_sample_subject_ids,
                                               xgboost_sample_subject_ids,
                                               metadata) {
  .br_runtime()
  reference <- .br_keys(reference, "Reference cohort")
  .br_assert("incident_aki" %in% names(reference) &&
               is.numeric(reference$incident_aki) &&
               !anyNA(reference$incident_aki) &&
               all(reference$incident_aki %in% c(0, 1)),
             "Reference outcome must be numeric binary incident_aki")
  reference <- reference[c("subject_id", "stay_id", "incident_aki")]
  reference$incident_aki <- as.integer(reference$incident_aki)
  rownames(reference) <- NULL
  metadata <- .br_metadata(metadata, nrow(reference))
  lasso <- .br_align(lasso_predictions, reference, "LASSO predictions")
  xgb <- .br_align(xgboost_predictions, reference, "XGBoost predictions")
  for (pred in list(lasso, xgb)) {
    .br_assert("probability" %in% names(pred) && is.numeric(pred$probability) &&
                 !anyNA(pred$probability) &&
                 all(is.finite(pred$probability) & pred$probability >= 0 &
                       pred$probability <= 1),
               "Model predictions must be finite numeric probabilities in [0, 1]")
  }
  counts <- lapply(list(lasso_sample_subject_ids, xgboost_sample_subject_ids), function(ids) {
    .br_assert(is.character(ids) || is.numeric(ids), "Invalid bootstrap sample key type")
    ids <- as.character(ids)
    .br_assert(length(ids) == metadata$expected_sample_size && !anyNA(ids),
               "A model has the wrong bootstrap sample size")
    index <- match(ids, reference$subject_id)
    .br_assert(!anyNA(index), "A bootstrap sample contains a non-reference patient")
    tabulate(index, nbins = nrow(reference))
  })
  .br_assert(identical(counts[[1L]], counts[[2L]]),
             "The two fitted models used different bootstrap samples")
  .br_assert(length(unique(reference$incident_aki[counts[[1L]] > 0L])) == 2L,
             "A successful binary-model bootstrap must contain both outcome classes")
  data <- data.frame(run_id = metadata$run_id, iteration = metadata$iteration,
                     attempt = metadata$attempt, reference,
                     inbag_multiplicity = counts[[1L]],
                     lasso_probability = lasso$probability,
                     xgboost_probability = xgb$probability,
                     stringsAsFactors = FALSE, check.names = FALSE)
  body <- list(schema_version = "bootstrap_patient_predictions_wide_v1_0",
               data = data, metadata = metadata,
               reference_sha256 = .br_sha(reference),
               sample_sha256 = .br_sha(reference$subject_id[rep(seq_len(nrow(reference)),
                                                              counts[[1L]])]),
               positive_class = "incident_aki = 1",
               training_weight = "inbag_multiplicity; do not duplicate rows as well",
               original_test_weight = "one for every row, including zero inbag multiplicity",
               success_status = "BOTH_MODELS_PASS_PREDICTIONS_COMPLETE")
  structure(list(body = body, payload_sha256 = .br_sha(body)),
            class = "bootstrap_prediction_record")
}

.br_validate_record <- function(record) {
  .br_assert(inherits(record, "bootstrap_prediction_record") &&
               identical(names(record), c("body", "payload_sha256")),
             "Invalid prediction record schema")
  .br_assert(identical(.br_sha(record$body), record$payload_sha256),
             "Prediction record payload hash does not match")
  body <- record$body
  .br_assert(is.list(body) && is.data.frame(body$data), "Invalid prediction record body")
  d <- body$data
  .br_assert("inbag_multiplicity" %in% names(d) && .br_whole(d$inbag_multiplicity),
             "Invalid stored bootstrap multiplicity")
  .br_assert(sum(d$inbag_multiplicity) == body$metadata$expected_sample_size,
             "Stored bootstrap sample size does not reconcile")
  .br_assert(all(d$run_id == body$metadata$run_id) &&
               all(d$iteration == body$metadata$iteration) &&
               all(d$attempt == body$metadata$attempt), "Stored row identity does not reconcile")
  ids <- rep(d$subject_id, d$inbag_multiplicity)
  expected <- build_bootstrap_prediction_record(
    d[c("subject_id", "stay_id", "incident_aki")],
    data.frame(d[c("subject_id", "stay_id")], probability = d$lasso_probability),
    data.frame(d[c("subject_id", "stay_id")], probability = d$xgboost_probability),
    ids, ids, body$metadata)
  .br_assert(identical(expected, record), "Prediction record content violates its schema")
  invisible(record)
}

.br_identity <- function(record) {
  m <- record$body$metadata
  list(run_id = m$run_id, analysis_variant = m$analysis_variant,
       expected_iterations = m$expected_iterations,
       expected_sample_size = m$expected_sample_size,
       analysis_matrix_sha256 = m$analysis_matrix_sha256, code_sha256 = m$code_sha256,
       reference_sha256 = record$body$reference_sha256,
       schema_version = record$body$schema_version)
}



.br_production_directory <- function(run_directory) {
  .br_runtime()
  .br_assert(.Platform$OS.type == "windows", "Production retention requires the restricted Windows host")
  candidate_root <- Sys.getenv("CANDIDATE_RESTRICTED_ROOT", unset = "")
  .br_assert(.br_scalar_text(run_directory) && nzchar(candidate_root),
             "HOLD_CANDIDATE_RESTRICTED_ROOT_REQUIRED")
  .br_assert(dir.exists(run_directory), "Restricted run directory must already exist")
  root <- normalizePath(candidate_root, winslash = "/", mustWork = TRUE)
  resolved <- normalizePath(run_directory, winslash = "/", mustWork = TRUE)
  .br_assert(startsWith(tolower(resolved), paste0(tolower(root), "/")) &&
               !identical(tolower(resolved), tolower(root)),
             "Resolved run directory is outside the restricted data root")
  
  
  
  powershell <- file.path(Sys.getenv("SystemRoot"), "System32", "WindowsPowerShell",
                         "v1.0", "powershell.exe")
  .br_assert(file.exists(powershell), "Windows directory-boundary verifier is unavailable")
  literal <- gsub("'", "''", resolved, fixed = TRUE)
  command <- paste0("$ErrorActionPreference='Stop'; try { ",
                    "$retentionDirectory = [IO.DirectoryInfo]::new('", literal, "'); ",
                    "while ($null -ne $retentionDirectory) { ",
                    "if (($retentionDirectory.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { exit 9 }; ",
                    "$retentionDirectory = $retentionDirectory.Parent }; exit 0 ",
                    "} catch { exit 10 }")
  verification <- suppressWarnings(system2(powershell,
    c("-NoProfile", "-NonInteractive", "-Command", shQuote(command)),
    stdout = TRUE, stderr = TRUE))
  status <- attr(verification, "status")
  .br_assert(is.null(status) || identical(as.integer(status), 0L),
             "Restricted directory ancestry contains a reparse point or cannot be verified")
  resolved
}

.br_atomic_new_rds <- function(value, destination) {
  .br_assert(!file.exists(destination), "Refusing to replace an existing artifact")
  temporary <- tempfile(pattern = ".pending_prediction_", tmpdir = dirname(destination))
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  saveRDS(value, temporary, compress = "gzip", version = 3L)
  .br_assert(identical(readRDS(temporary), value), "Temporary artifact failed read-back verification")
  .br_assert(!file.exists(destination), "Destination appeared while writing")
  .br_assert(file.rename(temporary, destination), "Atomic artifact rename failed")
  invisible(destination)
}

.br_read_record <- function(path) {
  record <- tryCatch(readRDS(path), error = function(e) .br_stop("Cannot read committed prediction artifact"))
  .br_validate_record(record)
  record
}



.br_write_record <- function(record, directory) {
  .br_validate_record(record)
  .br_assert(dir.exists(directory), "Retention directory does not exist")
  lock <- file.path(directory, ".prediction_retention_write_lock")
  .br_assert(dir.create(lock, showWarnings = FALSE),
             "Retention directory is locked; investigate an interrupted writer before retrying")
  on.exit({
    
    if (dir.exists(lock) && length(list.files(lock, all.files = TRUE, no.. = TRUE)) == 0L &&
        identical(dirname(normalizePath(lock, winslash = "/", mustWork = TRUE)),
                  normalizePath(directory, winslash = "/", mustWork = TRUE))) {
      unlink(lock, recursive = TRUE)
    }
  }, add = TRUE)
  identity <- .br_identity(record)
  manifest_path <- file.path(directory, "bootstrap_prediction_run_manifest.rds")
  if (file.exists(manifest_path)) {
    manifest <- tryCatch(readRDS(manifest_path), error = function(e) .br_stop("Cannot read retention run manifest"))
    .br_assert(identical(manifest, identity),
               "Retention run identity differs; use a new run directory")
  } else {
    
    
    existing <- list.files(directory, pattern = "^bootstrap_predictions_iteration_[0-9]+[.]rds$",
                           ignore.case = TRUE)
    .br_assert(length(existing) == 0L, "Prediction artifacts exist without a run manifest")
    .br_atomic_new_rds(identity, manifest_path)
  }
  path <- file.path(directory, sprintf("bootstrap_predictions_iteration_%06d.rds",
                                      record$body$metadata$iteration))
  if (file.exists(path)) {
    prior <- .br_read_record(path)
    .br_assert(identical(prior, record),
               "Committed iteration differs; existing predictions were not overwritten")
    return(invisible(list(status = "ALREADY_COMMITTED_IDENTICAL", path = path,
                          file_sha256 = unname(tools::sha256sum(path)),
                          payload_sha256 = record$payload_sha256)))
  }
  .br_atomic_new_rds(record, path)
  .br_assert(identical(.br_read_record(path), record), "Committed prediction verification failed")
  invisible(list(status = "COMMITTED", path = path,
                 file_sha256 = unname(tools::sha256sum(path)),
                 payload_sha256 = record$payload_sha256))
}

write_restricted_bootstrap_predictions <- function(record, run_directory) {
  directory <- .br_production_directory(run_directory)
  .br_write_record(record, directory)
}

.br_check_run <- function(directory, expected_identity) {
  manifest_path <- file.path(directory, "bootstrap_prediction_run_manifest.rds")
  .br_assert(file.exists(manifest_path), "Retention run manifest is missing")
  manifest <- readRDS(manifest_path)
  .br_assert(identical(manifest, expected_identity), "Unexpected retention run identity")
  iterations <- seq_len(manifest$expected_iterations)
  files <- sprintf("bootstrap_predictions_iteration_%06d.rds", iterations)
  committed <- list.files(directory, pattern = "^bootstrap_predictions_iteration_[0-9]+[.]rds$",
                          ignore.case = TRUE)
  .br_assert(setequal(files, committed), "Committed iteration coverage is incomplete or contains unexpected files")
  for (i in iterations) {
    record <- .br_read_record(file.path(directory, files[[i]]))
    .br_assert(identical(.br_identity(record), expected_identity) &&
                 identical(record$body$metadata$iteration, as.integer(i)),
               "Committed file has unexpected run or iteration metadata")
  }
  invisible(list(status = "ALL_EXPECTED_PREDICTIONS_VERIFIED",
                 iterations = length(iterations),
                 patient_level_egress_allowed = FALSE))
}

check_restricted_bootstrap_prediction_run <- function(run_directory, expected_identity) {
  directory <- .br_production_directory(run_directory)
  .br_check_run(directory, expected_identity)
}
