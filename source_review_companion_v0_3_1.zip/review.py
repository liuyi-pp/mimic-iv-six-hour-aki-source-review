"""Offline inventory/assembly-plan review only; never runs scientific entrypoints."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import stat
import sys


class ReviewError(ValueError):
    pass


def require(condition, code):
    if not condition:
        raise ReviewError(code)


def no_link(path):
    meta = path.lstat()
    require(not stat.S_ISLNK(meta.st_mode), "LINK_NOT_ALLOWED")
    require(not (getattr(meta, "st_file_attributes", 0) & 0x400), "REPARSE_NOT_ALLOWED")
    require(not (stat.S_ISREG(meta.st_mode) and meta.st_nlink > 1), "HARDLINK_NOT_ALLOWED")


def safe_name(value):
    require(isinstance(value, str) and bool(value), "INVALID_MEMBER")
    parts = value.split("/")
    require(not any(x in ("", ".", "..") for x in parts), "INVALID_MEMBER")
    require("\\" not in value and ":" not in value, "INVALID_MEMBER")
    require(not PurePosixPath(value).is_absolute(), "INVALID_MEMBER")
    return value


def verify(root):
    # Inspect ancestors before resolving: do not follow a link/reparse into data.
    root = Path(root).absolute()
    for part in reversed((root, *root.parents)):
        no_link(part)
    require(root.is_dir(), "NOT_A_DIRECTORY")
    manifest_path = root / "CANDIDATE_MANIFEST.json"
    no_link(manifest_path)
    require(manifest_path.is_file(), "MANIFEST_NOT_FILE")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(isinstance(manifest, dict), "MANIFEST_TYPE")
    require(manifest.get("version") == "0.3.1", "UNEXPECTED_VERSION")
    require(manifest.get("clinical_execution_authorized") is False, "CLINICAL_AUTHORIZATION_CHANGED")
    require(manifest.get("clinical_execution_supported") is False, "EXECUTION_STATUS_CHANGED")
    require(manifest.get("full_pipeline_execution_verified") is False, "PIPELINE_VERIFICATION_CHANGED")
    require(isinstance(manifest.get("files"), list), "MEMBER_LIST_TYPE")
    expected = {}
    for row in manifest["files"]:
        require(isinstance(row, dict), "MEMBER_TYPE")
        name = safe_name(row["relative_path"])
        require(name != "CANDIDATE_MANIFEST.json", "SELF_HASH_UNSUPPORTED")
        require(name.casefold() not in {n.casefold() for n in expected}, "DUPLICATE_MEMBER")
        digest = row["sha256"]
        require(isinstance(digest, str) and len(digest) == 64 and
                all(c in "0123456789abcdef" for c in digest), "INVALID_DIGEST")
        expected[name] = digest
    actual = set()

    def walk(directory):
        for child in directory.iterdir():
            no_link(child)
            if child.is_dir():
                walk(child)
            else:
                require(child.is_file(), "SPECIAL_FILE_NOT_ALLOWED")
                actual.add(child.relative_to(root).as_posix())
    walk(root)
    require(actual == set(expected) | {"CANDIDATE_MANIFEST.json"}, "ALLOWLIST_MISMATCH")
    for name, digest in expected.items():
        require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, "HASH_MISMATCH")
    return manifest


def validate_mapping_header(header, schema):
    # A new offline structural check, not validation of historical mapping contents.
    require(isinstance(header, list), "HEADER_TYPE")
    require(header == schema["ordered_columns"], "HEADER_ORDER_MISMATCH")
    return True


def plan(root):
    value = json.loads((Path(root) / "docs" / "assembly_plan.json").read_text(encoding="utf-8"))
    require(value["execution_supported"] is False, "EXECUTION_NOT_SUPPORTED")
    require(value["clinical_order"] == ["15b", "19", "16a", "16b", "16c", "16d", "17"], "ORDER_CHANGED")
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("check", "plan"))
    args = parser.parse_args(argv)
    root = Path(__file__).absolute().parent
    try:
        manifest = verify(root)
        if args.command == "plan":
            print(json.dumps(plan(root), ensure_ascii=True, indent=2))
        else:
            print(json.dumps({"status": "PASS_OFFLINE_MANIFEST_CHECK",
                              "checked_files": len(manifest["files"]),
                              "clinical_execution_authorized": False,
                              "clinical_execution_supported": False,
                              "full_pipeline_execution_verified": False}))
        return 0
    except (ReviewError, OSError, ValueError, KeyError, TypeError):
        # No file contents, sensitive path, or raw traceback in a failed check.
        print("FAIL_OFFLINE_REVIEW", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
